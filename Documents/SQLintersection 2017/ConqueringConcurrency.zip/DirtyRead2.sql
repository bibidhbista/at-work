USE AdventureWorks
GO


SELECT *
FROM Sales.SalesOrderDetail s
WHERE ProductID = 897



SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

SELECT *
FROM Sales.SalesOrderDetail s
WHERE ProductID = 897
