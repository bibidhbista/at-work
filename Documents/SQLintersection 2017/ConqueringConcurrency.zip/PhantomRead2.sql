insert into users (value)
select  9