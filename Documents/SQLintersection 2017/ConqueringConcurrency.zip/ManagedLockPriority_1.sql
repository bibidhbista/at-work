USE AdventureWorks2016
GO
IF OBJECT_ID('NewSalesForTest') IS NOT NULL
DROP TABLE NewSalesForTest
GO

SELECT *
INTO NewSalesForTest
FROM Sales.SalesOrderDetail
GO
CREATE CLUSTERED INDEX cix_NewSalesForTest 
ON NewSalesForTest(SalesOrderID, SalesOrderDetailID)
WITH(ONLINE=ON)
GO

BEGIN TRANSACTION
SELECT *
FROM NewSalesForTest WITH(HOLDLOCK)

COMMIT TRANSACTION