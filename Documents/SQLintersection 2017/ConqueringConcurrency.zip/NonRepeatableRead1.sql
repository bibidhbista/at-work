USE AdventureWorks
GO

BEGIN TRANSACTION

SELECT *
FROM Sales.SalesOrderDetail s
WHERE ProductID = 897

WAITFOR DELAY '0:0:10'

SELECT *
FROM Sales.SalesOrderDetail s
WHERE ProductID = 897