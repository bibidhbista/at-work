drop table users
go
create table users(userid int identity, value int)
go

insert into users (value)
select  Number
from master..spt_values
where type='P' and number > 0 and number < 100
go 30
go

set transaction isolation level repeatable read
go
begin tran
select * from users
where value between 1 and 10

commit
