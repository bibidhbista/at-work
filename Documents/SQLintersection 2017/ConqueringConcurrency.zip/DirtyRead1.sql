USE AdventureWorks
GO

BEGIN TRANSACTION

UPDATE s
SET ModifiedDate = DATEADD(DAY, 1, ModifiedDate)
FROM Sales.SalesOrderDetail s
WHERE ProductID = 897


SELECT *
FROM sys.dm_tran_locks
WHERE request_session_id = @@spid

--COMMIT TRANSACTION