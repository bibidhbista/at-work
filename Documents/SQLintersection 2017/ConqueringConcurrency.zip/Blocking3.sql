
SELECT *
FROM sys.dm_tran_active_transactions


SELECT *
FROM sys.dm_tran_locks


sp_lock

select * from sys.dm_exec_requests



;WITH Processes
AS
(
	SELECT
		s.spid, BlockingSPID = s.blocked, DatabaseName = DB_NAME(s.dbid),
		s.program_name, s.loginame, ObjectName = OBJECT_NAME(objectid, s.dbid), 
		Definition = CAST(text AS VARCHAR(MAX))
	FROM sys.sysprocesses s
	CROSS APPLY sys.dm_exec_sql_text (sql_handle)
	WHERE
	s.spid > 50
),
Blocking(SPID, BlockingSPID, BlockingStatement, RowNo, LevelRow)
 AS
 (
      SELECT
       s.SPID, s.BlockingSPID, s.Definition,
       ROW_NUMBER() OVER(ORDER BY s.SPID),
       0 AS LevelRow
     FROM
       Processes s
       JOIN Processes s1 ON s.SPID = s1.BlockingSPID
     WHERE
       s.BlockingSPID = 0
     UNION ALL
     SELECT
       r.SPID,  r.BlockingSPID, r.Definition,
       d.RowNo,
       d.LevelRow + 1
     FROM
       Processes r
      JOIN Blocking d ON r.BlockingSPID = d.SPID
     WHERE
       r.BlockingSPID > 0
 )
 SELECT * FROM Blocking
 ORDER BY RowNo, LevelRow

/*
FILE
<file_id>

OBJECT
<object_id>
 
PAGE
<file_id>:<page_in_file>

KEY
<hash_value>

EXTENT
<file_id>:<page_in_files>

RID
<file_id>:<page_in_file>:<row_on_page>
 
APPLICATION
<DbPrincipalId>:<upto 32 characters>:(<hash_value>)
*/