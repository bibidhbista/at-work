USE BlockingDB
GO

SELECT *
FROM Sales