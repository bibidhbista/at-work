USE tempdb
GO
-- 3) Run in second connection
BEGIN TRAN
UPDATE dbo.DeadlockTable2 
SET Column1 = 1

UPDATE dbo.DeadlockTable1 
SET Column1 = 1

COMMIT TRAN