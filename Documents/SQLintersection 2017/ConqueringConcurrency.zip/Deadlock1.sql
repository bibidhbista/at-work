--turn on trace flag so we can see output in error log
DBCC TRACEON(1222,-1)
GO

-- 1) Create Objects for Deadlock Example
USE TEMPDB

IF OBJECT_ID('tempdb.dbo.DeadlockTable1') IS NOT NULL
DROP TABLE DeadlockTable1
GO
IF OBJECT_ID('tempdb.dbo.DeadlockTable2') IS NOT NULL
DROP TABLE DeadlockTable2
GO
CREATE TABLE DeadlockTable1 (Column1 INT)
INSERT dbo.DeadlockTable1 
VALUES(1)

CREATE TABLE dbo.DeadlockTable2 (Column1 INT)
INSERT dbo.DeadlockTable2 
VALUES(2)

-- 2) Run in first connection
BEGIN TRAN
UPDATE dbo.DeadlockTable1 
SET Column1 = 1



-- 4) Run in first connection
UPDATE dbo.DeadlockTable2 
SET Column1 = 1
COMMIT TRAN

--look at the deadlock graph in profiler and in XML



