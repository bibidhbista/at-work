IF DB_ID('BlockingDB') IS NOT NULL
BEGIN
	ALTER DATABASE BlockingDB
	SET SINGLE_USER WITH ROLLBACK IMMEDIATE

	DROP DATABASE BlockingDB
END
GO
CREATE DATABASE BlockingDB ON  PRIMARY 
( NAME = N'BlockingDB_Data', FILENAME = N'C:\SQL\BlockingDB_Data.mdf' , 
SIZE = 2048MB , MAXSIZE = UNLIMITED, FILEGROWTH = 50MB )
 LOG ON 
( NAME = N'BlockingDB_Log', FILENAME = N'C:\SQL\BlockingDB_log.LDF' , 
SIZE = 50MB , MAXSIZE = 1024MB, FILEGROWTH = 50MB)
GO

USE BlockingDB
GO

IF OBJECT_ID('dbo.Sales') IS NOT NULL
DROP TABLE dbo.Sales
GO

CREATE TABLE dbo.Sales
(
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal]  AS (isnull(([UnitPrice]*((1.0)-[UnitPriceDiscount]))*[OrderQty],(0.0))),
	[ModifiedDate] [datetime] NOT NULL, 
	IDCol INT IDENTITY(1,1)
) ON [PRIMARY]
-------------------------------------------------------------------------------

INSERT INTO dbo.Sales
(
    SalesOrderID,
    SalesOrderDetailID,
    CarrierTrackingNumber,
    OrderQty,
    ProductID,
    SpecialOfferID,
    UnitPrice,
    UnitPriceDiscount,
    ModifiedDate
)
SELECT TOP(1000)
    SalesOrderID,
    SalesOrderDetailID,
    CarrierTrackingNumber,
    OrderQty,
    ProductID,
    SpecialOfferID,
    UnitPrice,
    UnitPriceDiscount,
    ModifiedDate
FROM
    AdventureWorks2012.Sales.SalesOrderDetail
WHERE ProductID = 870
-------------------------------------------------------------------------------

BEGIN TRANSACTION

UPDATE s
SET ModifiedDate = GETDATE()
FROM Sales s
WHERE IDCol < 100