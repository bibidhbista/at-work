USE AdventureWorks
GO

BEGIN TRANSACTION

UPDATE s
SET UnitPrice = 500
FROM Sales.SalesOrderDetail s
WHERE ProductID = 897

COMMIT TRANSACTION


