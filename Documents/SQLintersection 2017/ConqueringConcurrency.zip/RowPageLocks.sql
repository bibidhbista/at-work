

USE AdventureWorks2016
GO
IF OBJECT_ID('SODPageLock') IS NOT NULL
DROP TABLE SODPageLock
go
SELECT *
INTO SODPageLock
FROM Sales.SalesOrderDetail
GO

CREATE CLUSTERED INDEX cix_SODPageLock ON SODPageLock(SalesOrderDetailID)
WITH(ALLOW_PAGE_LOCKS=OFF, ALLOW_ROW_LOCKS = OFF)
GO
BEGIN TRAN
UPDATE S
SET ModifiedDate = GETDATE()
FROM SODPageLock s
WHERE SalesOrderDetailID = 1


--in second window look at 
select *
from sys.dm_tran_locks