--reset the demo
USE AdventureWorks2016;
GO

-- In-Memory 
:!! "C:\Program Files\RMLUtils\ostress.exe" �n100 �r500 -S.\SQL2017 -E -dAdventureWorks2016 -q -i"D:\SQLDemos\In-MemOLTP\Memory-optimized Inserts.sql"

-- Disk Based
:!! "C:\Program Files\RMLUtils\ostress.exe" �n100 �r500 -S.\SQL2017 -E -dAdventureWorks2016 -q -i"D:\SQLDemos\In-MemOLTP\Disk-based Inserts.sql"
