/* ***********************************************
   Determine minimum memory required for a table
** **********************************************/

CREATE TABLE T1 
(  
  col1 int NOT NULL  PRIMARY KEY NONCLUSTERED,  
  col2 int NOT NULL  INDEX t1c2_index   
      HASH WITH (bucket_count = 2000000),  
  col3 int NOT NULL  INDEX t1c3_index   
      HASH WITH (bucket_count = 2000000),  
  col4 int NOT NULL  INDEX t1c4_index NONCLUSTERED,  
  col5 char(15) NOT NULL,
  col6 char(25) NOT NULL,
  col7 char(30) NOT NULL,
  col8 char(15) NOT NULL 
)
WITH (memory_optimized = on);
GO

-- Memory for the table - 3 parts:
--	1. Timestamps: Row header/timestamps = 24 bytes
--	2. Index Pointers: 8-byte address pointer per row per hash index
--		this table has 2 hash indexes, so 2 x 8 = 16 bytes
--	3. Data: sum of the data type size per column
--		4 4-byte integers, 2 15-byte char, 1 25-byte char, & 1 30-byte char
--		so, (4 x 4) + (2 x 15) + 25 + 30 = 16 + 30 + 55 = 101 bytes.
--  Total for table: 24 + 16 + 101 = 141 bytes / row
--  For 2 million rows: 2,000,000 x 141 = 282/1024/,000,000 bytes or approx. 269 MB

-- Memory for indexes
--  hash indexes = 8 byte address pointer x bucket count rounded up to the closest power of 2
--	  for our example, 2,000,000 rounded up to next power of 2 = 2,097,152 * 8 bytes = 16,777,216 bytes or 16 MB
--    16 MB * 2 hash indexes = 32 MB
--  non-clustered indexes = (pointer size + sum(key Column Data type sizes) * rows with unique keys
--    for our example, col1: (8 + 4) * 2,000,000 = 24,000,000 bytes = 22 MB
--                     col4: (8 + 4) * est. 300,000 unique values = 3.4 MB
-- Index totals = 16 + 22 + 3.4 = approx 41 MB

-- Memory for row versioning: start with 2 x (table memory + index memory)
--   for our example, 2 x (284 + 41) = 650 MB

-- Memory for table variables: (memory for table variables is not released until they go out of scope)
--   need to know your code for this estimate. We'll just say 16 MB for our example

--  Memory for growth: Depends on your situation. Have you been tracking data growth over time?
--    for our example we'll anticipate 40% growth over the next 2 years.

-- So, our total is: (269 + 41 + 650 + 16) * 1.4 = 1.33 GB for one table!

