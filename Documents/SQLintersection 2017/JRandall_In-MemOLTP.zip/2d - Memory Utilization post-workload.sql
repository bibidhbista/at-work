-- =========================================================
-- Memory utilization for the memory-optimized tables
-- =========================================================
-- Overall utilization of the database
USE AdventureWorks2016;
SELECT 
	type, 
	pages_kb/1024 AS pages_MB 
FROM sys.dm_os_memory_clerks 
WHERE name = 'DB_ID_13'
  and type LIKE '%xtp%';

-- Memory utilization per table
SELECT 
	object_name(t.object_id) AS [Table Name],
    memory_allocated_for_table_kb,
	memory_used_by_table_kb,
    memory_allocated_for_indexes_kb,
	memory_used_by_indexes_kb
FROM sys.dm_db_xtp_table_memory_stats dms JOIN sys.tables t 
ON dms.object_id=t.object_id
WHERE t.type='U';

-- =========================================================
-- Disk utilization for the memory-optimized tables
-- =========================================================

-- Initial state
/* When the sample filegroup and sample memory-optimized tables are created initially, 
   a number of checkpoint files are pre-created and the system starts filling the files � 
   the number of checkpoint files pre-created depends on the number of logical processors 
   in the system. As the sample is initially very small, the pre-created files will be 
   mostly empty after initial create.

The following shows the initial on-disk size for the sample on a machine with 16 logical processors: */

SELECT SUM(df.size) * 8 / 1024 AS [On-disk size in MB]
FROM sys.filegroups f JOIN sys.database_files df 
   ON f.data_space_id=df.data_space_id
WHERE f.type=N'FX';

/* Looking closer at where the disk-space utilization comes from, you can use the following query. 
   The size on disk returned by this query is approximate for files with state in 5 
   (REQUIRED FOR BACKUP/HA), 6 (IN TRANSITION TO TOMBSTONE), or 7 (TOMBSTONE).*/

SELECT 
	state_desc,
    file_type_desc,
    COUNT(*) AS [count],
    SUM(CASE
            WHEN state = 5 AND file_type=0 THEN 128*1024*1024
            WHEN state = 5 AND file_type=1 THEN 8*1024*1024
            WHEN state IN (6,7) THEN 68*1024*1024
            ELSE file_size_in_bytes
          END) / 1024 / 1024 AS [on-disk size MB] 
FROM sys.dm_db_xtp_checkpoint_files
GROUP BY state, state_desc, file_type, file_type_desc
ORDER BY state, file_type;

