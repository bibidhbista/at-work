/* *******************************************************
   Demo insert speed differences between disk-based table,
   In-memory table using interpreted tsql, and
   In-memory table using native compiled procedure
** ******************************************************/

USE InMemDemo;
 GO 
-- Drop tables if they exist.
DROP PROCEDURE IF EXISTS spNativeComp;  
DROP TABLE IF EXISTS DiskBased;  
DROP TABLE IF EXISTS InMem_Interpreted;  
DROP TABLE IF EXISTS InMem_Compiled;

-- Create three tables with same column structure
-- 1. Disk-based table
CREATE TABLE [dbo].[DiskBased] (  
  col1 INT NOT NULL PRIMARY KEY,  
  col2 NCHAR(32) NOT NULL  
  );

-- 2. memory optimized tables, same structure
--    second will be populated using native compiled procedure
CREATE TABLE [dbo].[InMem_Interpreted] (  
  col1 INT NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT=1000000),  
  col2 NCHAR(32) NOT NULL  
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY = SCHEMA_AND_DATA);

CREATE TABLE [dbo].[InMem_Compiled] (  
  col1 INT NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT=1000000),  
  col2 NCHAR(32) NOT NULL  
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY = SCHEMA_AND_DATA);
GO

-- natively compiled procedure  
CREATE PROCEDURE spNativeComp  
    @rowcount INT,  
    @c NCHAR(32)  
  WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER  
  AS   
  BEGIN ATOMIC   
  WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')  
  DECLARE @i INT = 1;  
  WHILE @i <= @rowcount  
  BEGIN;  
    INSERT INTO [dbo].[InMem_Compiled] VALUES (@i, @c);  
    SET @i += 1;  
  END;  
END;
GO

SET STATISTICS TIME OFF;  
SET NOCOUNT ON;  

DECLARE @starttime DATETIME2 = sysdatetime();  
DECLARE @timems INT;  
DECLARE @i INT = 1;  
DECLARE @rowcount INT = 500000;  
DECLARE @c NCHAR(32) = N'SQLServer2016InMemoryTablesRock!';  

-- ----------------------------------------------------------------  
-- Insert into Hard drive-based table and interpreted Transact-SQL
-- ----------------------------------------------------------------   
BEGIN TRAN;  
  WHILE @i <= @rowcount  
  BEGIN;  
    INSERT INTO [dbo].[DiskBased] VALUES (@i, @c);  
    SET @i += 1;  
  END;  
COMMIT;  

-- Get duration  
SET @timems = datediff(ms, @starttime, sysdatetime());  
SELECT 'A: Disk-based table and interpreted Transact-SQL: '  
    + cast(@timems AS VARCHAR(10)) + ' ms';  

-- -----------------------------------------------  
-- In-Memory Table - insert with interpreted tsql
-- -----------------------------------------------  
SET @i = 1;  
SET @starttime = sysdatetime();  
  
BEGIN TRAN;  
  WHILE @i <= @rowcount  
    BEGIN;  
      INSERT INTO [dbo].[InMem_Interpreted] VALUES (@i, @c);  
      SET @i += 1;  
    END;  
COMMIT;  

-- Get Duration
SET @timems = datediff(ms, @starttime, sysdatetime());  
SELECT 'B: memory-optimized table with hash index and interpreted Transact-SQL: '  
    + cast(@timems as VARCHAR(10)) + ' ms';  

-- -------------------------------------------------------
-- In-Memory Table - insert with native compiled procedure
-- -------------------------------------------------------  
SET @starttime = sysdatetime();  
  
EXECUTE spNativeComp @rowcount, @c;  
 
 -- Get Duration 
SET @timems = datediff(ms, @starttime, sysdatetime());  
SELECT 'C: memory-optimized table with hash index and native SP:'  
    + cast(@timems as varchar(10)) + ' ms';  

-- ---------------------------------------------------------
-- Drop all created objects
-- ---------------------------------------------------------
DROP TABLE dbo.DiskBased;
DROP TABLE dbo.InMem_Interpreted;
DROP PROCEDURE dbo.spNativeComp;
DROP TABLE dbo.InMem_Compiled;  
