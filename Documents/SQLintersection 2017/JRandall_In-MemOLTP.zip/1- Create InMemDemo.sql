USE master;

-- make sure you are on the correct server and instance
DECLARE @ServerName sql_variant
SELECT @ServerName = SERVERPROPERTY('SERVERNAME')
IF @ServerName <> 'LHP23-0616-C0C3\SQL2017'
	PRINT 'Wrong Server! Change connection to LHP23-0616-C0C3\SQL2017'
ELSE PRINT 'Good to Go';

-- =========================================
-- Create our database
-- =========================================
USE master;

IF NOT EXISTS (SELECT [Name] from sys.databases where [name] = 'InMemDemo')
  BEGIN
	CREATE DATABASE InMemDemo
	ON (NAME = InMemDemo_data, 
		FILENAME = 'C:\SQL_Data\Demo\InMemDemo_data.mdf',
		SIZE = 1GB, MAXSIZE = 200GB, FILEGROWTH = 200MB)
	LOG ON (NAME = InMemDemo_log, FILENAME = 'D:\SQL_Logs\Demo\InMemDemo_log.ldf',
		SIZE = 250MB, MAXSIZE = 50GB, FILEGROWTH = 100MB);	
	ALTER AUTHORIZATION ON DATABASE::InMemDemo to DBOwner;
	--Set to Simple Recovery Model
	ALTER DATABASE [InMemDemo] SET RECOVERY SIMPLE WITH NO_WAIT;
	PRINT 'DATABASE InMemDemo Created';
  END
ELSE 
BEGIN
	--DROP Database
	ALTER DATABASE [InMemDemo] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [InMemDemo];
	--CREATE Database
	CREATE DATABASE InMemDemo
	ON (NAME = InMemDemo_data, 
		FILENAME = 'C:\SQL_Data\Demo\InMemDemo_data.mdf',
		SIZE = 1GB, MAXSIZE = 200GB, FILEGROWTH = 200MB)
	LOG ON (NAME = InMemDemo_log, FILENAME = 'D:\SQL_Logs\Demo\InMemDemo_log.ldf',
		SIZE = 250MB, MAXSIZE = 50GB, FILEGROWTH = 100MB);	
	--Set Database Owner
	ALTER AUTHORIZATION ON DATABASE::InMemDemo to DBOwner;
	--Set to Simple Recovery Model
	ALTER DATABASE [InMemDemo] SET RECOVERY SIMPLE WITH NO_WAIT;
	PRINT 'DATABASE InMemDemo Dropped and Re-created';
END
GO

-- ===================================================================
--Check that the database meets requirements for memory-optimized tables
-- ===================================================================
-- The below scipt enables the use of In-Memory OLTP in the current database, 
--   provided it is supported in the edition / pricing tier of the database.
-- It does the following:
-- 1. Validate that In-Memory OLTP is supported. 
-- 2. In SQL Server, it will add a MEMORY_OPTIMIZED_DATA filegroup to the database
--    and create a container within the filegroup in the default data folder.
-- 3. Change the database compatibility level to 140 (needed for parallel queries
--    and auto-update of statistics).
-- 4. Enables the database option MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT to avoid the 
--    need to use the WITH (SNAPSHOT) hint for ad hoc queries accessing memory-optimized
--    tables.
--
-- Applies To: SQL Server 2016 (or higher); Azure SQL Database
-- Author: Jos de Bruijn (Microsoft)
-- Last Updated: 2016-05-02

USE InMemDemo;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

-- 1. validate that In-Memory OLTP is supported
IF SERVERPROPERTY(N'IsXTPSupported') = 0 
BEGIN                                    
    PRINT N'Error: In-Memory OLTP is not supported for this server edition or database pricing tier.';
END 
IF DB_ID() < 5
BEGIN                                    
    PRINT N'Error: In-Memory OLTP is not supported in system databases. Connect to a user database.';
END 
ELSE 
BEGIN 
	BEGIN TRY;
-- 2. add MEMORY_OPTIMIZED_DATA filegroup when not using Azure SQL DB
	IF SERVERPROPERTY('EngineEdition') != 5 
	BEGIN
		--Set variables for filegroup file and path
		DECLARE @SQLDataFolder nvarchar(max) = cast(SERVERPROPERTY('InstanceDefaultDataPath') as nvarchar(max)) +'Demo\'
		DECLARE @MODName nvarchar(max) = DB_NAME() + N'_mod';
		DECLARE @MemoryOptimizedFilegroupFolder nvarchar(max) = @SQLDataFolder + @MODName;
		DECLARE @SQL nvarchar(max) = N'';

		-- add filegroup for in memory tables
		IF NOT EXISTS (SELECT 1 FROM sys.filegroups WHERE type = N'FX')
		BEGIN
			SET @SQL = N'ALTER DATABASE CURRENT ADD FILEGROUP ' + QUOTENAME(@MODName) + N' CONTAINS MEMORY_OPTIMIZED_DATA;';
			EXECUTE (@SQL);
		END;

		-- add container in the filegroup
		IF NOT EXISTS (SELECT * FROM sys.database_files WHERE data_space_id IN 
							(SELECT data_space_id FROM sys.filegroups WHERE type = N'FX'))
		BEGIN
			SET @SQL = N'ALTER DATABASE CURRENT ADD FILE (name = N''' + @MODName + ''', filename = '''
						+ @MemoryOptimizedFilegroupFolder + N''') TO FILEGROUP ' + QUOTENAME(@MODName);
			EXECUTE (@SQL);
		END
	END

-- 3. set compatibility level to 140 if it is lower
	IF (SELECT compatibility_level FROM sys.databases WHERE database_id=DB_ID()) < 140
		ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 140 

-- 4. elevate the isolation level for memory-optimized tables to SNAPSHOT
-- for every cross-container transaction with lower isolation level 
	ALTER DATABASE CURRENT SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON;

    END TRY
    BEGIN CATCH
        PRINT N'Error enabling In-Memory OLTP';
		IF XACT_STATE() != 0
			ROLLBACK;
        THROW;
    END CATCH;
END;

-- ========================================================
-- Create Memory-Optimized tables
-- ========================================================
USE InMemDemo;
GO

 -- In-memory table syntax
DROP TABLE IF EXISTS SupportTicket;
GO
  
CREATE TABLE SupportTicket  ( 
	TicketId		int           not null   identity(1,1)  
		PRIMARY KEY NONCLUSTERED,  
	StartDateTime   datetime2     not null,  
	CustomerName    nvarchar(16)  not null,  
	EngineerName	nvarchar(16)  null,  
	Priority        int           null,  
	Description     nvarchar(64)  null  
	)  
  WITH ( MEMORY_OPTIMIZED = ON,  DURABILITY = SCHEMA_AND_DATA); -- Define as Memory-Optimized and Durability
  
ALTER TABLE SupportTicket  
  ADD CONSTRAINT constraintUnique_SDT_CN  
    UNIQUE NONCLUSTERED (StartDateTime DESC, CustomerName);

ALTER TABLE SupportTicket  
  ADD INDEX idx_hash_EngineerName  
    HASH (EngineerName) WITH (BUCKET_COUNT = 64);  -- Nonunique.
 
  
