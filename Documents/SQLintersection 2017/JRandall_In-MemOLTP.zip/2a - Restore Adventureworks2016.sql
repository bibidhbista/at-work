-- make sure you are on the correct server and instance
USE master;
DECLARE @ServerName sql_variant
SELECT @ServerName = SERVERPROPERTY('SERVERNAME')
IF @ServerName <> 'LHP23-0616-C0C3\SQL2017'
PRINT 'Wrong Server! Change connection to LHP23-0616-C0C3\SQL2017'


USE [master]
RESTORE DATABASE [AdventureWorks2016] 
FROM  DISK = N'D:\SQL_Bkup\AdventureWorks2016.bak' 
WITH  FILE = 1,  
	MOVE N'AdventureWorks2016CTP3_Data' TO N'C:\SQL_Data\AdventureWorks2016_Data.mdf',  
	MOVE N'AdventureWorks2016CTP3_mod' TO N'C:\SQL_Data\AdventureWorks2016_mod',  
	NOUNLOAD,  REPLACE,  STATS = 5

GO
PRINT 'Database Restore Complete'

-- Backup Adventureworks2016
USE master;
BACKUP DATABASE [AdventureWorks2016] 
	TO  DISK = N'D:\SQL_Bkup\AdventureWorks2016_2017-10-30.bak' 
	WITH NOFORMAT, NOINIT,  NAME = N'AdventureWorks2016-Full Database Backup', 
	SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  STATS = 10
GO
declare @backupSetId as int
select @backupSetId = position from msdb..backupset 
where database_name=N'AdventureWorks2016' 
  and backup_set_id=(select max(backup_set_id) from msdb..backupset where database_name=N'AdventureWorks2016' )
if @backupSetId is null 
  begin 
	raiserror(N'Verify failed. Backup information for database ''AdventureWorks2016'' not found.', 16, 1) 
  end
RESTORE VERIFYONLY FROM  DISK = N'D:\SQL_Bkup\AdventureWorks2016.bak' 
WITH  FILE = @backupSetId,  NOUNLOAD,  NOREWIND
GO


--select * from sys.databases