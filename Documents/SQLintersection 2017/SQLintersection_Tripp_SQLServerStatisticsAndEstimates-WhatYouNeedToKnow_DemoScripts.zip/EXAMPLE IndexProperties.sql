SELECT 
	OBJECT_NAME([s].[object_id]) 	AS [TableName]
	, CASE 
		WHEN [s].[stats_id] = 0 then 'Heap'
		WHEN [s].[stats_id] = 1 then 'CL'
		WHEN INDEXPROPERTY ( [s].[object_id], [s].[name], 'IsAutoStatistics') = 1 THEN 'Stats-Auto'
		WHEN INDEXPROPERTY ( [s].[object_id], [s].[name], 'IsHypothetical') = 1 THEN 'Stats-HIND'
		WHEN INDEXPROPERTY ( [s].[object_id], [s].[name], 'IsStatistics') = 1 THEN 'Stats-User'
		WHEN [s].[stats_id] BETWEEN 2 AND 31005 -- and, it's not a statistic
			THEN 'NC ' + RIGHT('0000' 
                + convert(varchar, [s].[stats_id]), 5)
		ELSE 'Text/Image'
	  END 							AS [IndexType]
	, [s].[name] 					AS [IndexName]
	, [s].[stats_id]				AS [IndexID]
	, CASE
		WHEN STATS_DATE ([s].[object_id], [s].[stats_id]) 
            < DATEADD(m, -1, getdate()) 
			THEN '!! More than a month OLD !!'
		WHEN STATS_DATE ([s].[object_id], [s].[stats_id]) 
            < DATEADD(wk, -1, getdate()) 
			THEN '! Within the past month !'
		ELSE 'Stats recent'
	  END 							AS [Warning]
	, STATS_DATE ([s].[object_id], [s].[stats_id]) 	
        AS [Last Stats Update]
	, CASE 
		WHEN no_recompute = 0 THEN 'YES'
		ELSE 'NO'
	  END AS 'AutoUpdate'
FROM [sys].[stats] AS [s]
WHERE OBJECTPROPERTY([s].[object_id], 'IsUserTable') = 1
--	AND (INDEXPROPERTY ( si.[object_id], si.[name], 'IsAutoStatistics') = 1 
--			OR INDEXPROPERTY ( si.[object_id], si.[name], 'IsHypothetical') = 1 
--			OR INDEXPROPERTY ( si.[object_id], si.[name], 'IsStatistics') = 1)
--ORDER BY [Last Stats Update] DESC
ORDER BY [TableName], [s].[stats_id];