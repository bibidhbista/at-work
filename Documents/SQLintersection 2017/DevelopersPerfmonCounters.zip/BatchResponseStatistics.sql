IF OBJECT_ID('tempdb..#BatchResponses') IS NOT NULL
DROP TABLE #BatchResponses
GO
SELECT *
INTO #BatchResponses
FROM sys.dm_os_performance_counters
WHERE object_name LIKE '%Batch Resp Statistics%'
AND instance_name IN('Elapsed Time:Requests','Elapsed Time:Total(ms)')      
GO                                                                                                                      
                                                                                                       
SELECT 
     AvgRunTimeMS = CASE WHEN bcount.cntr_value = 0 THEN 0 ELSE btime.cntr_value/bcount.cntr_value END , 
     StatementCount = CAST(bcount.cntr_value AS BIGINT),bcount.counter_name, TotalElapsedTimeMS = btime.cntr_value, 
     ExecutionTimePercent = CAST((100.0 * btime.cntr_value/SUM (btime.cntr_value) OVER()) AS DECIMAL(5,2)), 
     ExecutionCountPercent = CAST((100.0 * bcount.cntr_value/SUM (bcount.cntr_value) OVER()) AS DECIMAL(5,2))
FROM 
(
     SELECT *
     FROM #BatchResponses
     WHERE instance_name = 'Elapsed Time:Requests'
) bcount
JOIN
(
     SELECT *
     FROM #BatchResponses
     WHERE instance_name = 'Elapsed Time:Total(ms)'
) btime ON bcount.counter_name = btime.counter_name
ORDER BY bcount.counter_name ASC    
