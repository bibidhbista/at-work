﻿#load the necessary assemblies
$assemblylist =   
"Microsoft.SqlServer.Management.Common",  
"Microsoft.SqlServer.Smo",  
"Microsoft.SqlServer.Dmf ",
"Microsoft.SqlServer.SqlWmiManagement "
  
foreach ($asm in $assemblylist)  
{  
    $asm = [Reflection.Assembly]::LoadWithPartialName($asm)  
}  

function grab-perfmon
{
param
(
    [string] $instancename = $env:COMPUTERNAME, 

    [ValidateSet("start", "stop", IgnoreCase = $true)]
    [string] $operation = "start" ,  

    [string] $path
)

if(!(test-path -path $path))
{
write-error "Invalid path"
}

$os = get-ciminstance win32_operatingsystem
$MemoryGB = Get-WmiObject -Class Win32_PhysicalMemory | measure-object -Sum Capacity |%{$_.sum/1GB}

#create hash table with all the necessary details for later analysis
$PhysicalDetails = @{}
$PhysicalDetails.add("PhysicalMemoryGB",$MemoryGB)
$PhysicalDetails.add("FreeMemoryGB",$os.FreePhysicalMemory/1MB)
$PhysicalDetails.add("VisibleMemoryGB",$os.TotalVisibleMemorySize/1MB)
$PhysicalDetails.add("LastBootDate",$os.LastBootUpTime)
$PhysicalDetails.add("BuildNumber",$os.BuildNumber)
$PhysicalDetails.add("Caption",$os.Caption)
$PhysicalDetails.add("MachineName",$os.CSName)


logman stop SQLPerf
logman delete SqlPerf

if($operation -eq "start")
{

    $server = new-object ('Microsoft.SqlServer.Management.Smo.Server') $instancename
    
    if ($server.InstanceName -eq "") 
    {
	    $sqlcntr = 'SQLServer'
    }
    else 
    {
	    $sqlcntr = 'MSSQL$' + $server.InstanceName
    }

    $box = $server.Name

    #grab the perf counters we need
    $cfg = "\Processor(_Total)\% Processor Time",
    "\Memory\Available MBytes",
    "\LogicalDisk(_Total)\Avg. Disk sec/Read",
    "\LogicalDisk(_Total)\Avg. Disk sec/Write",
    "\$($sqlcntr):Buffer Manager\Page life expectancy",
    "\$($sqlcntr):SQL Statistics\Batch Requests/sec",
    "\$($sqlcntr):Buffer Manager\Lazy writes/sec",
    "\$($sqlcntr):Buffer Manager\Database pages",
    "\$($sqlcntr):Buffer Manager\Page reads/sec",                                                                                                                 
    "\$($sqlcntr):Buffer Manager\Page writes/sec",
    "\$($sqlcntr):Memory Manager\External benefit of memory",                                                                                                      
    "\$($sqlcntr):Memory Manager\Connection Memory (KB)",                                                                                                          
    "\$($sqlcntr):Memory Manager\Database Cache Memory (KB)",                                                                                                      
    "\$($sqlcntr):Memory Manager\Free Memory (KB)",                                                                                                                
    "\$($sqlcntr):Memory Manager\Granted Workspace Memory (KB)",                                                                                                   
    "\$($sqlcntr):Memory Manager\Lock Memory (KB)",                                                                                                                                                                                                                             
    "\$($sqlcntr):Memory Manager\Maximum Workspace Memory (KB)",                                                                                                   
    "\$($sqlcntr):Memory Manager\Memory Grants Outstanding",                                                                                                       
    "\$($sqlcntr):Memory Manager\Memory Grants Pending",                                                                                                           
    "\$($sqlcntr):Memory Manager\Optimizer Memory (KB)",                                                                                                           
    "\$($sqlcntr):Memory Manager\Reserved Server Memory (KB)",                                                                                                     
    "\$($sqlcntr):Memory Manager\SQL Cache Memory (KB)",                                                                                                           
    "\$($sqlcntr):Memory Manager\Stolen Server Memory (KB)",                                                                                                       
    "\$($sqlcntr):Memory Manager\Log Pool Memory (KB)",                                                                                                            
    "\$($sqlcntr):Memory Manager\Target Server Memory (KB)",                                                                                                       
    "\$($sqlcntr):Memory Manager\Total Server Memory (KB)"

    #filename in the form of machine-instance_date 
    #I will create a new folder w/ the same name as $filename below                                                                                                                                                                                                              
    $filename = ($box -replace "\\","_") + "_" + (Get-Date -format yyyyMMdd_hhmm).ToString()
    
    $newfolder = join-path -Path $path -ChildPath $filename
    
    if(!(test-path -path $newfolder))
    {
        new-item -Path $newfolder -ItemType directory

    }

    $path = $newfolder
    
    #generate the configuration path for perfmon
    $configpath = join-path -path $path -ChildPath "$filename.config"

    #generate the xml path for exporting the machine details
    $DetailsExport = join-path -path $path -ChildPath "$filename.xml"
    
    #export the physical details.  Will load them in a seperate process when analyzing perfmon
    $PhysicalDetails | Export-Clixml $DetailsExport

    if(test-path -Path $configpath)
    {
    remove-item $configpath
    }

    $cfg | out-file $configpath -encoding ASCII

    #generate path for perfmon binary log file
    $blgpath = join-path -path $path -ChildPath "$filename.blg"
    
    if(test-path -Path $blgpath)
    {
    remove-item $blgpath
    }
    #need to overwrite files
    logman create counter SQLPerf -f bincirc -max 100 -si 5 -o $blgpath -cf $configpath -rf "0:1:00"
    logman start SQLPerf
}


}

grab-perfmon -instancename "." -operation "start" -path "c:\sql"





$instancename = "." 
$operation = "start" 
$path = "c:\sql"