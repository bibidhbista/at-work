USE AdventureWorksDW2014
GO

IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO
CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

-- Insert some data
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)
GO

ALTER table FactResellerSalesPart_Big
ADD IDCol INT IDENTITY primary key clustered
go
alter table 
drop constraint 
go
alter index [PK__FactRese__91A98A6291B919F0] on  FactResellerSalesPart_Big
rebuild
with (data_compression=page)

create index idxfrs on FactResellerSalesPart_Big (ProductKey)
WITH(data_compression=page, drop_existing = on)

create nonclustered columnstore index ncix_frsp 
on FactResellerSalesPart_Big
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, 
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, 
SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, 
OrderQuantity, UnitPrice, ExtENDedAmount, UnitPriceDiscountPct, 
DiscountAmount, ProductStANDardCost, TotalProductCost, SalesAmount, 
TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber, IDCol
)
select * from sys.partitions
where object_id = object_id('FactResellerSalesPart_Big')