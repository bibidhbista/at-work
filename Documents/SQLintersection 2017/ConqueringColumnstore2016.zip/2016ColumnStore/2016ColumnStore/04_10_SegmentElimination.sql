USE ColumnstoreDB
GO
/* already in ColumnstoreDB
DROP TABLE SegmentElimination
GO
CREATE TABLE SegmentElimination(c1 INT, c2 varchar(20))
GO

SET NOCOUNT ON

INSERT SegmentElimination 
SELECT *
FROM AdventureWorksDW2016..Numbers


CREATE CLUSTERED COLUMNSTORE INDEX cciSE on SegmentElimination
GO

*/

select count(*) from SegmentElimination

select * from sys.column_store_segments s
join sys.partitions p on s.partition_id = p.partition_id
where p.OBJECT_ID = OBJECT_ID('SegmentElimination')

-- Review the structure of 'SegmentElimination' TABLE
-- one INT column AND another varchar column

-- CREATE event session to track segment elimination

CREATE EVENT SESSION [TrackSegmentElimination] ON SERVER 
ADD EVENT sqlserver.column_store_segment_eliminate
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

-- start session (xEvent)

-- run following query (Segment Elimination will occur)
SET		STATISTICS IO ON
SELECT c1 FROM SegmentElimination WHERE c1=3001000
SELECT * FROM SegmentElimination WHERE c1=3001000
GO
SELECT c1 FROM SegmentElimination
WHERE c1 bETWEEN 47597	AND 71148

-- Watch Live Data (xEvent)
-- Make sure Segment Elimination occurs

-- Than, run following query (Segment Elimination will not occur)
dbcc freeproccache
SELECT * FROM SegmentElimination WHERE c2='3001000'
GO

-- Watch Live Data for a WHILE ...(xEvent)
-- Make sure Segment Elimination doesn't occur

-- Review max AND min value of c1 column
--look at the number of segments returned for the INT column
SELECT * FROM sys.column_store_segments c
inner JOIN sys.partitions p
on c.partition_id=p.partition_id
WHERE p.OBJECT_ID=OBJECT_ID('SegmentElimination')
AND c.column_id=1
AND 3001000 BETWEEN min_data_id and max_data_id
GO

-- Review max AND min value of c2 column
SELECT * FROM sys.column_store_segments c
inner JOIN sys.partitions p
on c.partition_id=p.partition_id
WHERE p.OBJECT_ID=OBJECT_ID('SegmentElimination')
AND c.column_id=2
GO
