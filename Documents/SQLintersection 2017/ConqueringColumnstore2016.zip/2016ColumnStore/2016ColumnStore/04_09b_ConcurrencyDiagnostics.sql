--Check the lock request status
USE ColumnstoreDB
GO
SELECT 
	lck.request_session_id,
	lck.request_mode,
	lck.request_status,
	lck.resource_type,
	lck.resource_description,
	CASE
		WHEN resource_type = 'object'
			THEN OBJECT_NAME(lck.resource_associated_entity_id)
		ELSE OBJECT_NAME(p.OBJECT_ID)
	END AS ObjectName,
	i.name AS index_name,
	lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.PARTITION_ID = lck.resource_associated_entity_id AND resource_database_id = DB_ID()
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
ORDER BY request_session_id, resource_associated_entity_id 

--Check blocked requests
SELECT session_id, commAND, wait_type, blocking_session_id, * 
FROM sys.dm_EXEC_requests 
WHERE blocking_session_id > 0


SELECT * FROM t2 
WHERE c2 = 110306


SET transaction isolation level snapshot
SELECT * FROM t2