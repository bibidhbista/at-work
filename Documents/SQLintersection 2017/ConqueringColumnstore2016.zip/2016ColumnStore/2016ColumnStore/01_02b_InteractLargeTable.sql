USE AdventureWorksDW2016
GO
SET STATISTICS IO ON


DROP INDEX ncix_FRSH ON FactResellerSales_Huge
GO
--CREATE an NC CS index
CREATE NONCLUSTERED COLUMNSTORE INDEX ncix_FRSH ON FactResellerSales_Huge
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, EmployeeKey, PromotionKey, 
CurrencyKey, SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, 
OrderQuantity, UnitPrice, ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, 
Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate, IDCol
) ON UserFGNCCI
GO

SELECT rows,*
FROM sys.partitions
WHERE OBJECT_ID = OBJECT_ID('FactResellerSales_Huge')
GO

--are the CS stats up to date?
--more on this later
DBCC SHOW_STATISTICS(FactResellerSales_Huge, 'ncix_FRSH')
GO

--look at segments per column
SELECT *
FROM sys.column_store_segments s
JOIN sys.partitions p on s.partition_id = p.partition_id
WHERE p.OBJECT_ID = OBJECT_ID('FactResellerSales_Huge')
ORDER BY column_id ASC




