Use AdventureWorksDW2016
GO
-- Is there any stats for t5?
SELECT * FROM sys.stats WHERE OBJECT_ID=OBJECT_ID('FactResellerSalesPart_Big')
GO


-- No Statistics
Dbcc show_statistics('FactResellerSalesPart_Big',CCI)


-- What about auto CREATEd -- run the query below should CREATE an autostats.
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey < 12;
GO

-- Now view stats on promotionKey 
EXECUTE sp_helpstats 'FactResellerSalesPart_Big'
GO
Dbcc show_statistics('FactResellerSalesPart_Big',_WA_Sys_00000007_662B2B3B)

-- Update Statistics on Clustered?
Update statistics FactResellerSalesPart_Big  -- with fullscan
GO


-- No Statistics
Dbcc show_statistics('FactResellerSalesPart_Big',CCI)


-- Creating multi column statistics for correlated data
CREATE statistics StatsOrderDateKey_shipDateKey on FactResellerSalesPart_Big(OrderDateKey,ShipDateKey)