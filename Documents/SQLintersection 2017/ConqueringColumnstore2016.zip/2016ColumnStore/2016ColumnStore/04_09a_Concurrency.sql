USE ColumnstoreDB
GO
-- CREATE TABLE
IF OBJECT_ID('t2') IS NOT NULL
DROP TABLE t2
GO
CREATE TABLE t2 (c1 INT, c2 INT)
GO
-- CREATE CCI
CREATE CLUSTERED COLUMNSTORE INDEX t2CCI ON t2
GO

-- INSERT 1 row within a transaction
-- Note this is a delta store not the columnstore
BEGIN TRANSACTION
INSERT t2 VALUES(1,99)
GO

-- IF you see unit of locking WHILE in delta store is the row group
SELECT lck.request_session_id,
lck.request_mode,
lck.request_status,
lck.resource_type,
lck.resource_description,
CASE
    WHEN resource_type = 'object'
        THEN OBJECT_NAME(lck.resource_associated_entity_id)
    ELSE OBJECT_NAME(p.OBJECT_ID)
END AS ObjectName,
i.name AS index_name,
lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.hobt_id = lck.resource_associated_entity_id
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
WHERE resource_associated_entity_id > 0 AND resource_database_id = DB_ID()
ORDER BY request_session_id, resource_associated_entity_id 



-- Execute FROM another windows
-- This will be blocked
SELECT sys.fn_physlocformatter(%%physloc%%),* FROM t2 -- this should get blockedw IF EXECUTEuted FROM another connection

SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO
commit
-- Review Diagnostics ( FROM 04_9b_ConcurrencyDiagnostics.sql script)
-- Should see blocking



SELECT *   
FROM sys.dm_db_column_store_row_group_physical_stats   
WHERE OBJECT_ID  = OBJECT_ID('t2')  
ORDER BY row_group_id;  

-- Commit the transaction
COMMIT

begin tran
update t2
set c2 = 96
where c1 = 1

-- INSERT 1+ million rows
SET NOCOUNT ON

INSERT t2(c1,c2)
SELECT
	x+((x+1)%1000), x
FROM
(
	SELECT x = c1 
	FROM AdventureWorksDW2016..Numbers
	WHERE c1 <= 1000000
) a

-- Shoud dhave a OPEN AND a COMPRESSED rowgroup.
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO

-- Now do an opeartion
BEGIN TRAN
INSERT T2 VALUES(1,99)
GO

-- Look at the Resource_associated_entityID
-- That is the segment that is being locked.
SELECT lck.request_session_id,
       lck.request_mode,
	   lck.request_status,
       lck.resource_type,
       lck.resource_description,
	    CASE
           WHEN resource_type = 'object'
               THEN OBJECT_NAME(lck.resource_associated_entity_id)
           ELSE OBJECT_NAME(p.OBJECT_ID)
       END AS ObjectName,
	   i.name AS index_name,
       lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.hobt_id = lck.resource_associated_entity_id
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
WHERE resource_associated_entity_id > 0 AND resource_database_id = DB_ID()
ORDER BY request_session_id, resource_associated_entity_id 
GO

-- Update is on the rowstore not the Comlumnstore
-- Look at associated_entity_id
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO

-- Is that the right hobt for the segment?
-- This should match the resource_associated_entity_id FROM query above.
SELECT * FROM sys.column_store_segments cs
JOIN sys.partitions p on p.partition_id = cs.partition_id
WHERE OBJECT_ID = OBJECT_ID('t2')
--AND column_id = 1



--commit
commit

-- Force the Tuple Moveover
ALTER INDEX t2CCI ON t2 REORGANIZE  ;

-- The State of the rowgroup can be OPEN, COMPRESSED or CLOSED
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO


-- WHat happens IF I update a row now?
-- This is updating a row in the Columnstore ( not the rowstore)
-- An update is a Logical delete followed by an INSERT. You see the locks on both the rowgroups.
BEGIN tran
update t2 
SET c1 = 102
WHERE c2 = 110306

-- Lock at the resource_description
-- You will see an X Lock on the rowstore.
SELECT lck.request_session_id,
       lck.request_mode,
	   lck.request_status,
       lck.resource_type,
       lck.resource_description,
	    CASE
           WHEN resource_type = 'object'
               THEN OBJECT_NAME(lck.resource_associated_entity_id)
           ELSE OBJECT_NAME(p.OBJECT_ID)
       END AS ObjectName,
	   i.name AS index_name,
       lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.hobt_id = lck.resource_associated_entity_id AND resource_database_id = DB_ID()
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
ORDER BY request_session_id, resource_associated_entity_id 
GO
-- rollback
rollback
GO


-- WHat IF you update a row in the Rowstore?
-- THen need only an X Lock granted
INSERT INTo t2 values ( -1,10)
GO
BEGIN tran
update t2 
SET c2 = 102
WHERE c1 = -1

-- Lock at the resource_description
-- You will see an X Lock on the rowstore.
SELECT lck.request_session_id,
       lck.request_mode,
	   lck.request_status,
       lck.resource_type,
       lck.resource_description,
	    CASE
           WHEN resource_type = 'object'
               THEN OBJECT_NAME(lck.resource_associated_entity_id)
           ELSE OBJECT_NAME(p.OBJECT_ID)
       END AS ObjectName,
	   i.name AS index_name,
       lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.hobt_id = lck.resource_associated_entity_id
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
WHERE resource_associated_entity_id > 0 AND resource_database_id = DB_ID()
ORDER BY request_session_id, resource_associated_entity_id 
GO
-- rollback
rollback
GO




-- How does a Delete behave?
-- delete FROM columnstore has Lock only on the columnstore Rowgroup to change the Delete bitmap.
BEGIN tran
Delete t2
WHERE c2 = 110306
-- PrINT locks
SELECT lck.request_session_id,
       lck.request_mode,
	   lck.request_status,
       lck.resource_type,
       lck.resource_description,
	    CASE
           WHEN resource_type = 'object'
               THEN OBJECT_NAME(lck.resource_associated_entity_id)
           ELSE OBJECT_NAME(p.OBJECT_ID)
       END AS ObjectName,
	   i.name AS index_name,
       lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.hobt_id = lck.resource_associated_entity_id
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
WHERE resource_associated_entity_id > 0 AND resource_database_id = DB_ID()
ORDER BY request_session_id, resource_associated_entity_id 
GO
rollback
GO


-- Can we do snapshot isolation?
SET TRANSACTION ISOLATION LEVEL SNAPSHOT

ALTER DATABASE ColumnstoreDB
SET ALLOW_SNAPSHOT_ISOLATION OFF

SELECT * FROM t2
GO
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
ALTER DATABASE ColumnstoreDB
SET ALLOW_SNAPSHOT_ISOLATION OFF