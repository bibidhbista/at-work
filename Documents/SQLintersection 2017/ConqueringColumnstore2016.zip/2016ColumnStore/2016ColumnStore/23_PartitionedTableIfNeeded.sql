Use Demodb
GO

--SELECT max(orderdatekey) FROM AdventureworksDW2012..FactResellerSalesPart_Big
SELECT orderdatekey,count(*) FROM AdventureworksDW2012..FactResellerSalesPart_Big
WHERE orderdatekey >= 20070401 AND orderdatekey < 20070501

-- CREATE Partition functions
DROP TABLE FactResellerSalesPart_Big_Partitioned
GO
DROP partition scheme [ByOrderDateMonthRange]
GO
DROP partition function [ByOrderDateMonthPF]
GO
CREATE PARTITION FUNCTION [ByOrderDateMonthPF](INT) AS RANGE RIGHT 
FOR VALUES (20050701, 20050801, 20050901, 20051001, 20051101, 20051201, 20060101, 20060201, 20060301, 20060401, 20060501, 20060601,
	 20060701, 20060801, 20060901, 20061001, 20061101, 20061201, 20070101, 20070201, 20070301, 20070401, 20070501, 20070601, 20070701
	 ,20070801, 20070901, 20071001, 20071101, 20071201,  20080101)
GO

CREATE PARTITION SCHEME [ByOrderDateMonthRange] AS PARTITION [ByOrderDateMonthPF] 
ALL TO ([PRIMARY] )
GO

CREATE TABLE [dbo].FactResellerSalesPart_Big_Partitioned(
       [ProductKey] [INT] NOT NULL,
       [OrderDateKey] [INT] NOT NULL,
       [DueDateKey] [INT] NOT NULL,
       [ShipDateKey] [INT] NOT NULL,
       [ResellerKey] [INT] NOT NULL,
       [EmployeeKey] [INT] NOT NULL,
       [PromotionKey] [INT] NOT NULL,
       [CurrencyKey] [INT] NOT NULL,
       [SalesTerritoryKey] [INT] NOT NULL,
       [SalesOrderNumber] [nvarchar](20) NOT NULL,
       [SalesOrderLineNumber] [tinyINT] NOT NULL,
       [RevisionNumber] [tinyINT] NULL,
       [OrderQuantity] [smallINT] NULL,
       [UnitPrice] [money] NULL,
       [ExtENDedAmount] [money] NULL,
       [UnitPriceDiscountPct] [float] NULL,
       [DiscountAmount] [float] NULL,
       [ProductStANDardCost] [money] NULL,
       [TotalProductCost] [money] NULL,
       [SalesAmount] [money] NULL,
       [TaxAmt] [money] NULL,
       [Freight] [money] NULL,
       [CarrierTrackingNumber] [nvarchar](25) NULL,
       [CustomerPONumber] [nvarchar](25) NULL
) ON ByOrderDateMonthRange (OrderDateKey);
GO

CREATE CLUSTERED COLUMNSTORE INDEX CCI ON FactResellerSalesPart_Big_Partitioned;

-- Insert Data
-- Takes longer ( closer to 5-6 mins.)
-- Takes forever as Data is not by partition in the input file So sorting is done to INSERT
-- Can be quicker to input INTo staging TABLEs AND swap in for a data load.
-- Can show estimated plan, also IF it takes long cancel that.
-
BULK INSERT  FactResellerSalesPart_Big_Partitioned
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)

-- If Data is sorted AND belongs to a particular partition it is quicker 
-- Also can do that in parallel when loading.
BULK INSERT  FactResellerSalesPart_Big_Partitioned
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSales_Partitioned_2007_04_01.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)


-- Check the row groups by partition
SELECT *
FROM sys.column_store_row_groups
WHERE object_id = object_id('[FactResellerSalesPart_Big_Partitioned]')
GO

-- Are these rows partitioned?
-- how many rows are there in each non-empty partition?
SELECT $partition.[ByOrderDateMonthPF](OrderDateKey),  count(*) FROM FactResellerSalesPart_Big_Partitioned 
group by $partition.[ByOrderDateMonthPF](OrderDateKey) 
ORDER BY 1;

--
SELECT OrderDateKey,count(*)
FROM FactResellerSalesPart_Big_Partitioned
group by OrderDateKey
ORDER BY count(*) desc

