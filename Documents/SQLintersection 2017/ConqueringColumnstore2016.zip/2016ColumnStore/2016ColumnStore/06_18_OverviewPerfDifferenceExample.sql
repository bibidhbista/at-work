Use AdventureWorks2016
GO
ALTER DATABASE AdventureWorks2016 
SET RECOVERY SIMPLE
GO
IF OBJECT_ID('SalesOrderDetailBloated') is not null
DROP TABLE SalesOrderDetailBloated
GO
CREATE TABLE SalesOrderDetailBloated(
       [SalesOrderID] [INT]   NOT NULL,
       [SalesOrderDetailID] [INT]   IDENTITY(1,1) NOT NULL,
       [CarrierTrackingNumber] [nvarchar](25) NULL,
       [OrderQty] [smallINT]   NOT NULL,
       [ProductID] [INT] NOT NULL,
       [SpecialOfferID] [INT]   NOT NULL,
       [UnitPrice] [money]   NOT NULL,
       [UnitPriceDiscount] [money]   NOT NULL,
       [LineTotal] [money],
       [rowguid] [uniqueidentIFier]   ROWGUIDCOL  NOT    NULL,
       [ModIFiedDate] [datetime]   NOT NULL,
 CONSTRAINT [PK_SalesOrderDetailBloated]   
PRIMARY KEY CLUSTERED 
(
       [SalesOrderID] ASC,
       [SalesOrderDetailID] ASC
)) ON [PRIMARY]
GO

-- Populate data
-- Will take 2-3 mins
SET NOCOUNT ON
GO 
INSERT INTO SalesOrderDetailBloated
SELECT SalesOrderID, CarrierTrackingNumber,   OrderQty, ProductID, 
SpecialOfferID, UnitPrice, UnitPriceDiscount, LineTotal, rowguid, ModIFiedDate
FROM [AdventureWorks2016].Sales.[SalesOrderDetail]
GO 15

ALTER INDEX ALL ON SalesOrderDetailBloated
REBUILD
GO
 
-- CREATE Non clustered columnstore index take about 20 seconds
CREATE NONCLUSTERED COLUMNSTORE INDEX IDX_ColumnStore 
on dbo.SalesOrderDetailBloated
(	
[SalesOrderID],
[SalesOrderDetailID],
[CarrierTrackingNumber],
[OrderQty],
[ProductID],
[SpecialOfferID],
[UnitPrice],
[UnitPriceDiscount],
[LineTotal],
[ModIFiedDate]
)

-- see dIFference in performance
SET STATISTICS TIME ON
GO
-- Cold Cache
DBCC DROPCLEANBUFFERS
GO

/*
SQL Server Execution Times:
   CPU time = 500 ms,  elapsed time = 1227 ms.
*/
-- Get the plan WHILE looking at this
-- You will note the Scan since there is no supporting index for the group by
-- ALso note the Time taken in the message tab
-- Note the OPTION claUSE ignores the columnstore index.

SELECT ProductID, SUM(LineTotal) AS 'ProductSales'  , 
Avg(UnitPrice) As AvgUnitPrice,
Avg([UnitPriceDiscount]) as AvgDiscountOnUnitPrice
FROM SalesOrderDetailBloated
GROUP BY ProductID
ORDER BY SUM(LineTotal) desc
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);


-- Lets CREATE a covering index, include columns
-- DROP index SalesOrderDetailBloated.[SalesOrderDetailBloated_ind1]
CREATE NONCLUSTERED   INDEX [SalesOrderDetailBloated_ind1]
ON SalesOrderDetailBloated(ProductID, LineTotal)  Include(UnitPrice,[UnitPriceDiscount])
GO


DBCC DROPCLEANBUFFERS
GO
-- Did that improve performance?
-- Definitely was much quicker
/*
 SQL Server Execution Times:
   CPU time = 1125 ms,  elapsed time = 1032 ms.
*/
-- Get the Plan
SELECT ProductID, SUM(LineTotal) AS 'ProductSales' ,  
Avg(UnitPrice) As AvgUnitPrice,
Avg([UnitPriceDiscount]) as AvgDiscountOnUnitPrice
FROM SalesOrderDetailBloated
GROUP BY ProductID
ORDER BY SUM(LineTotal) desc
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);

-- DROPCleanbuffers to be fair
DBCC DROPCLEANBUFFERS
GO
/*
 SQL Server Execution Times:
   CPU time = 110 ms,  elapsed time = 220 ms.
*/
SELECT ProductID, SUM(LineTotal) AS 'ProductSales' ,  
Avg(UnitPrice) As AvgUnitPrice,
Avg([UnitPriceDiscount]) as AvgDiscountOnUnitPrice
FROM SalesOrderDetailBloated
GROUP BY ProductID
ORDER BY SUM(LineTotal) desc



DBCC DROPCLEANBUFFERS
GO
-- What IF we get even more creative AND do a dIFferen group by?
-- Prior covering index is USEless.
-- Can't CREATE indexes to cover the whole TABLE can we?
/*
 SQL Server Execution Times:
   CPU time = 1078 ms,  elapsed time = 3323 ms.
   */
SELECT ProductID, SpecialOfferID,SUM(LineTotal) AS 'Products-SpecialOfferSale'   
FROM 
SalesOrderDetailBloated
GROUP BY ProductID,SpecialOfferID
ORDER BY SUM(LineTotal) desc
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);
GO

-- How about with Columnstore?
/*
 SQL Server Execution Times:
   CPU time = 78 ms,  elapsed time = 79 ms.
*/
DBCC DROPCLEANBUFFERS
GO
SELECT ProductID, SpecialOfferID,SUM(LineTotal) AS 'Products-SpecialOfferSale'   
FROM 
SalesOrderDetailBloated
GROUP BY ProductID,SpecialOfferID
ORDER BY SUM(LineTotal) desc
GO

SET STATISTICS TIME OFF
GO




/*
Run the following queries individually.  Examine the EXECUTEution plans AND poINT 
out the EXECUTEution time FROM the statistics time output on Messages tab for each query.  
Compare the results between the queries.
/******** Query1: Complex Query on Multiple TABLEs without a Columnstore index ***********/
*/
USE AdventureWorks2016
DBCC DROPCLEANBUFFERS
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SET STATISTICS XML ON
GO

SELECT ( ISNull(P.FirstName,'') + ' ' + ISNull(P.MiddleName,'') 
		+ ' ' + IsNull(P.LastName,'')) As CustomerName,
	SOH.OrderDate, SOH.DueDate, SOH.ShipDate,SOH.TotalDue,
	sum(TWC.OrderQty) As TotalOrderQuantity,
	avg(TWC.UnitPrice) As AvgUnitPrice,
	Avg(TWC.UnitPriceDiscount) as AvgDiscountOnUnitPrice
FROM [dbo].SalesOrderDetailBloated TWC 
	JOIN Sales.SalesOrderHeader SOH on TWC.SalesOrderID =
SOH.SalesOrderID
	JOIN Sales.Customer C on SOH.CustomerID = C.CustomerID
	JOIN Person.Person P on P.BusinessEntityID = C.PersonID
WHERE TWC.UnitPriceDiscount <> 0 
group by ( ISNull(P.FirstName,'') + ' ' + ISNull(P.MiddleName,'') 
+ ' ' + IsNull(P.LastName,'')),
	SOH.OrderDate, SOH.DueDate, SOH.ShipDate,SOH.TotalDue
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);
SET statistics time off
GO
SET statistics profile off
GO


/**** Query2: Complex Query on Multiple TABLEs with a Columnstore index ********/
USE AdventureWorks2016
DBCC DROPCLEANBUFFERS
GO

SET STATISTICS TIME ON
SET STATISTICS IO ON
SET STATISTICS XML ON
GO
SELECT ( ISNull(P.FirstName,'') + ' ' + ISNull(P.MiddleName,'') 
		+ ' ' + IsNull(P.LastName,'')) As CustomerName,
	SOH.OrderDate, SOH.DueDate, SOH.ShipDate,SOH.TotalDue,
	sum(TWC.OrderQty) As TotalOrderQuantity,
avg(TWC.UnitPrice) As AvgUnitPrice,
	Avg(TWC.UnitPriceDiscount) as AvgDiscountOnUnitPrice
FROM [dbo].SalesOrderDetailBloated TWC 
	JOIN Sales.SalesOrderHeader SOH on TWC.SalesOrderID = 
						SOH.SalesOrderID
	JOIN Sales.Customer C on SOH.CustomerID = C.CustomerID
	JOIN Person.Person P on P.BusinessEntityID = C.PersonID
WHERE TWC.UnitPriceDiscount <> 0 --AND TWC.OrderQty > 500
group by ( ISNull(P.FirstName,'') + ' ' + ISNull(P.MiddleName,'') 
		+ ' ' + IsNull(P.LastName,'')),
	SOH.OrderDate, SOH.DueDate, SOH.ShipDate,SOH.TotalDue
	GO
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
SET STATISTICS XML OFF
GO



