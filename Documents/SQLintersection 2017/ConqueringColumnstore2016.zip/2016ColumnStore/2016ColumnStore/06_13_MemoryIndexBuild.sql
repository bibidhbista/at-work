Use ColumnstoreDB
GO


IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO
CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

	
-- Insert some data
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)
GO 

BEGIN TRY
DROP EVENT SESSION [ColumnStoreIndexBuild] ON SERVER
END TRY
BEGIN CATCH
END CATCH
GO
CREATE EVENT SESSION [ColumnStoreIndexBuild] ON SERVER 
ADD EVENT sqlserver.column_store_index_build_low_memory,
ADD EVENT sqlserver.column_store_index_build_process_segment,
ADD EVENT sqlserver.column_store_index_build_throttle
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
ALTER EVENT SESSION [ColumnStoreIndexBuild] ON SERVER STATE=START
GO

SELECT * FROM sys.system_objects where name like '%memory%'

SELECT MemoryGB = total_physical_memory_kb/1024.0/1024.0,* 
FROM sys.dm_os_sys_memory

EXECUTE sp_configure 'max server memory', 3072
RECONFIGURE


-- Watch Live Data on XE that was CREATEd.
-- Lower the Memory Grant Percent to simulate memory pressure
ALTER WORKLOAD GROUP [Default] WITH (REQUEST_MAX_MEMORY_GRANT_PERCENT = 1)
ALTER RESOURCE GOVERNOR RECONFIGURE
GO

-- ENable Query Plan
-- View EffectiveDOP
-- Also view Serial phase ( Primary dictionary) AND Parallel phase (Segment building)
CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big]
WITH(DROP_EXISTING=ON)
GO

-- view the LiveData you were watching
-- Apply INdexBuild ViewSETtings file IF necessary.


/*******************
MUST CHANGE BACK MEMORY GRANT
************/
ALTER WORKLOAD GROUP [Default] WITH (REQUEST_MAX_MEMORY_GRANT_PERCENT = 50)
ALTER RESOURCE GOVERNOR RECONFIGURE
GO
EXECUTE sp_configure 'max server memory', 2147483647
RECONFIGURE