-- Clerks
SELECT pages_kb,* 
FROM sys.dm_os_memory_clerks 
WHERE type = 'CACHESTORE_COLUMNSTOREOBJECTPOOL'


-- Look at Memory Brokers
-- One for Cache in particular is one we care about.
-- Default Pool_id =2
SELECT * 
FROM sys.dm_os_memory_brokers


-- Ring Buffer for Columstore Broker
SELECT
*,
Record.value('(//Record/MemoryBrokerClerk/Name)[1]','varchar(100)') as BrokerName
FROM
(
SELECT cast(record as XML) as Record 
FROM sys.dm_os_ring_buffers
WHERE ring_buffer_type = 'RING_BUFFER_MEMORY_BROKER_CLERKS'
) as T

-- Cache Stores
SELECT * FROM sys.dm_os_memory_cache_clock_hands
WHERE type ='CACHESTORE_COLUMNSTOREOBJECTPOOL'

sp_server_diagnostics



SELECT * FROM sys.dm_os_memory_cache_entries
WHERE type like 'CACHESTORE_COLUMNSTOREOBJECTPOOL'

BEGIN TRY
	DROP EVENT SESSION ColumnstoreMemSession ON SERVER 
END TRY
BEGIN CATCH
END CATCH
GO
-- ExtENDed Events
CREATE EVENT SESSION ColumnstoreMemSession ON SERVER 
ADD EVENT sqlos.large_cache_caching_decision(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlos.large_cache_entry_value_change(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlos.large_cache_memory_pressure(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlos.large_cache_state_change(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlos.large_cache_sweep(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlserver.batch_hash_JOIN_separate_hash_column(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlserver.column_store_object_pool_hit(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlserver.column_store_object_pool_miss(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlserver.column_store_rowgroup_read_issued(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlserver.column_store_rowgroup_readahead_issued(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)),
ADD EVENT sqlserver.column_store_segment_eliminate(
    ACTION(sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)) 
ADD TARGET package0.ring_buffer
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=10 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=ON,STARTUP_STATE=OFF)
GO


-- CLEAN CACHE ETC
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS;
GO
ALTER EVENT SESSION ColumnstoreMemSession ON SERVER 
STATE = START
GO

-- Watch Live Data

-- Now run this
USE AdventureWorksDW2016
GO
SELECT f.SalesTerritoryKey, t.SalesTerritoryCountry, d.CalENDarQuarter, 
COUNT(*) SalesCount, SUM(f.SalesAmount) SalesAmount
FROM ColumnstoreDB.dbo.FactResellerSalesPart_Big f, dbo.DimSalesTerritory t, DimDate d
WHERE f.SalesTerritoryKey = t.SalesTerritoryKey
AND f.OrderDateKey = d.DateKey
AND d.CalENDarYear = 2007
--AND t.SalesTerritoryCountry <> 'United States'
group by f.SalesTerritoryKey, t.SalesTerritoryCountry, d.CalENDarQuarter
ORDER BY d.CalendarQuarter asc, SUM(f.SalesAmount) desc, 
t.SalesTerritoryCountry asc;
GO

ALTER EVENT SESSION ColumnstoreMemSession ON SERVER 
STATE = STOP
GO



SELECT CONVERT (varchar(30), GETDATE(), 121) as [RunTime],
dateadd (ms, rbf.[timestamp] - tme.ms_ticks, GETDATE()) as [NotIFication_Time],
CAST(record AS XML).value('(//SPID)[1]', 'bigINT') as SPID,
CAST(record AS XML).value('(//operation/@action)[1]', 'varchar(255)') AS [operation],
CAST(record AS XML).value('(//xdes/@id)[1]', 'varchar(255)') AS xdesId, 
CAST(record AS XML).value('(//rowgroup/@lop_type)[1]', 'varchar(255)') AS lop_type, 
 
CAST(record AS XML).value('(//rowgroup/@rowgroupid)[1]', 'varchar(255)') AS rowgroupid, 
CAST(record AS XML).value('(//rowgroup/@version)[1]', 'varchar(255)') AS version, 
CAST(record AS XML).value('(//rowgroup/@status)[1]', 'varchar(255)') AS status, 
CAST(record AS XML).value('(//rowgroup/@deltastoreid)[1]', 'varchar(255)') AS deltastoreid, 
 
CAST(record AS XML).value('(//Record/@id)[1]', 'bigINT') AS [Record Id],
CAST(record AS XML).value('(//Record/@type)[1]', 'varchar(30)') AS [Type], 
CAST(record AS XML).value('(//Record/@time)[1]', 'bigINT') AS [Record Time],
CAST(record AS XML).value('(//Record/@LOP)[1]', 'varchar(255)') AS [Status],
 
tme.ms_ticks as [Current Time]
FROM sys.dm_os_ring_buffers rbf
cross JOIN sys.dm_os_sys_info tme
 WHERE rbf.ring_buffer_type = 'RING_BUFFER_HOBT_SCHEMAMGR'  
 AND CAST(record AS XML).value('(//operation/@action)[1]', 'varchar(255)') like '%ROWGROUP%'
ORDER BY rbf.timestamp ASC
