USE ColumnstoreDB
GO
-- CREATE TABLE AND index
DROP TABLE StatsTable 
GO
CREATE TABLE StatsTable (c1 INT, c2 nvarchar(20))
GO
CREATE CLUSTERED COLUMNSTORE INDEX StatsTableCCI on StatsTable
GO
-- Load data
INSERT StatsTable 
SELECT c1, c2
FROM AdventureWorksDW2016..Numbers
GO

-- Is there any stats for StatsTable?
SELECT * FROM sys.stats WHERE object_id=object_id('StatsTable')
GO

-- Review default stats
dbcc show_statistics(StatsTable, StatsTableCCI)
GO

-- run SELECT statement
SELECT count(*) FROM StatsTable WHERE c2='1111'
GO

-- check stats for StatsTable again 
SELECT * FROM sys.stats WHERE object_id=object_id('StatsTable')
GO

-- review newer stats
dbcc show_statistics(StatsTable, _WA_Sys_00000002_2E1BDC42)
GO


