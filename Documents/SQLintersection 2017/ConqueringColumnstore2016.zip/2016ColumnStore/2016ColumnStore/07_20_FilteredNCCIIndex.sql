Use AdventureWorksDW2016
GO
ALTER DATABASE AdventureWorksDW2016 
SET RECOVERY SIMPLE
GO
IF OBJECT_ID('FactResellerSalesPart_Big1') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big1
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big1](
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big1];
GO


-- Insert some data
-- Takes a WHILE on my system ( 2.2 mins) - 4.3 million rows.
-- WHILE INSERTing talk about fact that IF the input in bulk INSERT is sorted, segments are better formed.
BULK INSERT  AdventureWorksDW2016.dbo.[FactResellerSalesPart_Big1]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)

ALTER TABLE FactResellerSalesPart_Big1
ADD IDCol INT IDENTITY(1,1) --PRIMARY KEY CLUSTERED
GO

IF COLUMNPROPERTY(OBJECT_ID('FactResellerSalesPart_Big1'), 'ArchiveDate', 'ColumnID') IS NOT NULL
ALTER TABLE FactResellerSalesPart_Big1
DROP COLUMN ArchiveDate
GO

ALTER TABLE FactResellerSalesPart_Big1 
ADD ArchiveDate DATETIME NULL
GO

DECLARE @Mod INT, @MinDate DATETIME = '1/1/2009'
SELECT @Mod = CAST(GETDATE() AS INT) - CAST(@MinDate AS INT)

UPDATE TOP(95) PERCENT FactResellerSalesPart_Big1
SET ArchiveDate = (IDCol % @Mod)+ CAST(@MinDate AS INT)
GO

CREATE NONCLUSTERED INDEX idx_FRSP_ArchiveDate 
ON FactResellerSalesPart_Big1(ArchiveDate)
WHERE ArchiveDate IS NOT NULL

with(DROP_EXISTING=ON)
GO

DROP INDEX NCCI_SODCS 
ON FactResellerSalesPart_Big1
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, 
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, 
SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, 
ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, 
CustomerPONumber, ArchiveDate, IDCol
)
WHERE ArchiveDate IS NOT NULL

SET ANSI_NULLS OFF

DECLARE @X DATETIME


SELECT COUNT(ArchiveDate)
FROM FactResellerSalesPart_Big1
WHERE ArchiveDate < @X

option(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)


SELECT COUNT(UnitPriceDiscountPct)
FROM FactResellerSalesPart_Big1
WHERE ArchiveDate IS NULL
option(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)






