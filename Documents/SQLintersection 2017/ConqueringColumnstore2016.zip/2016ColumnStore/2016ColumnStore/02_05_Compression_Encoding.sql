USE AdventureWorksDW2016
GO

IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO
CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

	
-- Insert some data
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)
GO

-- Space used?
-- Size:  597832 KB
EXECUTE sp_spaceused 'FactResellerSalesPart_Big'
GO

CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big]
GO
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('FactResellerSalesPart_Big')

--add page compression later 

--look at execution plan
set statistics io on
dbcc dropcleanbuffers
SELECT COUNT(*) 
FROM [FactResellerSalesPart_Big]
GO

-- Space used? 
-- Size:  3808 KB
EXECUTE sp_spaceused 'FactResellerSalesPart_Big'



ALTER INDEX CCI ON [FactResellerSalesPart_Big] 
REBUILD WITH (DATA_COMPRESSION=COLUMNSTORE_ARCHIVE)

-- review size again
-- Space used? 
-- Size:  1320 KB
EXECUTE sp_spaceused [FactResellerSalesPart_Big]
GO


-- Check Metadata.
SELECT  
	partition_number,cs.column_id,cols.name as ColName,
	segment_id,row_count,on_disk_size,data_compression_desc,*
FROM 
	sys.column_store_segments cs
	JOIN sys.partitions p ON cs.hobt_id=p.hobt_id
	JOIN sys.columns cols ON p.OBJECT_ID = cols.OBJECT_ID
		AND cs.column_id = cols.column_id
WHERE 
	p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
GO    





-- Check Dictionaries
-- Will see multiple dictionaries for the same column in many cases.
-- Note dictionaries depend on whether primary or secondary are one/partition AND or many per segment.
/*
type:
	SUPPORTS_COMPRESSED = 0x1,
	SUPPORTS_NULL		= 0x2,
*/

SELECT d.* 
FROM sys.column_store_dictionaries d

SELECT d.*, object_name(p.OBJECT_ID) as TABLEName, cols.name FROM sys.column_store_dictionaries d
JOIN sys.partitions p on d.hobt_id=p.hobt_id
JOIN sys.columns cols on p.OBJECT_ID = cols.OBJECT_ID AND d.column_id = cols.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
ORDER BY column_id



-- Encoding
/* encoding_type
	VALUE_BASED 				= 1,
	VALUE_HASH_BASED			= 2,
	STRING_HASH_BASED			= 3,
	STORE_BY_VALUE_BASED		= 4,
	STRING_STORE_BY_VALUE_BASED = 5
*/
-- Encoding 
SELECT 
TableName = object_name(p.OBJECT_ID) , cols.name, 
encoding_type,segment_id,row_count,on_disk_size,css.* 
FROM sys.column_store_segments css
JOIN sys.partitions p on css.hobt_id=p.hobt_id
JOIN sys.columns cols on p.OBJECT_ID = cols.OBJECT_ID
AND css.column_id = cols.column_id
WHERE p.OBJECT_ID=OBJECT_ID('FactResellerSalesPart_Big')
ORDER BY css.on_disk_size desc

--rebuild to remove archive compression
--easier to see sizes
CREATE CLUSTERED COLUMNSTORE INDEX CCI 
ON [FactResellerSalesPart_Big]
WITH(DROP_EXISTING=ON, DATA_COMPRESSION=COLUMNSTORE)
GO


-- Basic space query
SELECT SUM(s.used_page_count) / 128.0 on_disk_size_MB 
FROM sys.indexes AS i 
JOIN sys.dm_db_partition_stats AS S 
    ON i.OBJECT_ID = S.OBJECT_ID 
    AND I.index_id = S.index_id 
WHERE i.OBJECT_ID = OBJECT_ID('FactResellerSalesPart_Big') 
AND i.type_desc = 'CLUSTERED COLUMNSTORE' 

sp_spaceused 'FactResellerSalesPart_Big'

-- Space Usage QUeries
-- total size 
with total_segment_size as 
( 
	SELECT 
	SUM (css.on_disk_size)/1024/1024 AS segment_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_segments AS css 
	ON p.hobt_id = css.hobt_id 
), 
total_dictionary_size as 
( 
	SELECT SUM (csd.on_disk_size)/1024 AS dictionary_size_kb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_dictionaries AS csd 
	ON p.partition_id = csd.partition_id 
) 
SELECT 
segment_size_mb, 
dictionary_size_kb
FROM total_segment_size, total_dictionary_size 
GO 


-- size per index 
with segment_size_by_index AS 
( 
	SELECT 
	p.OBJECT_ID as table_id, 
	p.index_id as index_id, 
	SUM (css.on_disk_size)/1024/1024 AS segment_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_segments AS css 
	ON p.hobt_id = css.hobt_id 
	group by p.OBJECT_ID, p.index_id 
) , 
dictionary_size_by_index AS 
( 
	SELECT 
	p.OBJECT_ID as table_id, 
	p.index_id as index_id, 
	SUM (csd.on_disk_size)/1024/1024 AS dictionary_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_dictionaries AS csd 
	ON p.hobt_id = csd.hobt_id 
	group by p.OBJECT_ID, p.index_id 
) 
SELECT 
object_name(s.table_id) table_name, 
i.name as index_name, 
s.segment_size_mb, 
d.dictionary_size_mb, 
s.segment_size_mb + isnull(d.dictionary_size_mb, 0) as total_size_mb 
FROM segment_size_by_index s 
JOIN sys.indexes AS i 
ON i.OBJECT_ID = s.table_id 
AND i.index_id = s.index_id 
LEFT OUTER JOIN dictionary_size_by_index d 
on s.table_id = s.table_id 
AND s.index_id = d.index_id 
ORDER BY total_size_mb desc 
GO 
-- size per TABLE 
with segment_size_by_TABLE AS 
( 
	SELECT 
	p.OBJECT_ID as table_id, 
	SUM (css.on_disk_size)/1024/1024 AS segment_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_segments AS css 
	ON p.hobt_id = css.hobt_id 
	group by p.OBJECT_ID 
) , 
dictionary_size_by_TABLE AS 
( 
	SELECT 
	p.OBJECT_ID AS table_id, 
	SUM (csd.on_disk_size)/1024/1024 AS dictionary_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_dictionaries AS csd 
	ON p.hobt_id = csd.hobt_id 
	group by p.OBJECT_ID 
) 
SELECT 
t.name AS table_name, 
s.segment_size_mb, 
d.dictionary_size_mb, 
s.segment_size_mb + isnull(d.dictionary_size_mb, 0) as total_size_mb 
FROM dictionary_size_by_TABLE d 
JOIN sys.TABLEs AS t 
ON t.OBJECT_ID = d.table_id 
LEFT OUTER JOIN segment_size_by_TABLE s 
on d.table_id = s.table_id 
ORDER BY total_size_mb desc 
GO 
-- size per column 
with segment_size_by_column as 
( 
	SELECT 
	p.OBJECT_ID as table_id, 
	css.column_id, 
	SUM (css.on_disk_size)/1024/1024.0 AS segment_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_segments AS css 
	ON p.hobt_id = css.hobt_id 
	GROUP BY p.OBJECT_ID, css.column_id 
), 
dictionary_size_by_column as 
( 
	SELECT 
	p.OBJECT_ID as table_id, 
	csd.column_id, 
	SUM (csd.on_disk_size)/1024/1024.0 AS dictionary_size_mb 
	FROM sys.partitions AS p 
	JOIN sys.column_store_dictionaries AS csd 
	ON p.hobt_id = csd.hobt_id 
	GROUP BY p.OBJECT_ID, csd.column_id 
) 
