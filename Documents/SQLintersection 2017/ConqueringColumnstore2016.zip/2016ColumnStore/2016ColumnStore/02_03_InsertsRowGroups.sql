USE ColumnstoreDB
GO

IF OBJECT_ID('t2') IS NOT NULL
DROP TABLE t2
GO
CREATE TABLE t2 (c1 INT, c2 INT)
GO

-- CREATE CCI
CREATE CLUSTERED COLUMNSTORE INDEX t2CCI ON t2
GO
-- review row group information
SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO
-- no rows

-- INSERT 1 row
INSERT t2 values(1,99)
GO
DELETE TOP(1) FROM t2

-- review row group information
-- 1 OPEN row group in delta store
-- Note the Delta_store_hobt_id
SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO



-- INSERT 1 million rows 
SET NOCOUNT ON

INSERT t2(c1,c2)
SELECT
x+((x+1)%1000), x
FROM
(
SELECT x = c1
FROM AdventureWorksDW2016..Numbers
WHERE c1 <= 200000
) a

-- review row group information
-- You will see new Rowgroup is "open" in the Delta store.
-- ALso see that the delta_store_hobt_id is dIFferent for each rowgroup.
-- The State of the rowgroup can be OPEN, COMPRESSED or CLOSED

SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO


-- Force the Tuple Moveover
ALTER INDEX t2CCI ON t2 REORGANIZE-- with (compress_all_open_row_groups) ;


-- What is the State of the rowgroup after the tuple Moveover?
-- Should be COMPRESSED AND the delta_store_hobt_id is NULL AND size is populated.
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO

ALTER INDEX t2CCI ON t2 REBUILD  ;
GO
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO
--enter some more data
INSERT t2(c1,c2)
SELECT
x+((x+1)%1000), x
FROM
(
SELECT x = c1
FROM AdventureWorksDW2016..Numbers
WHERE c1 <= 1000000
) a

/*
OPEN � A read/write row group that is accepting new records. An open row 
group is still in rowstore format and has not been compressed to columnstore format.

CLOSED � A row group that has been filled, but not yet compressed by the 
tuple mover process.

COMPRESSED � A row group that has filled and compressed.

TOMBSTONE - A row group that was formerly in the deltastore and is no longer used
*/

-- Rowgroup Has one rowgroup in each state
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO


-- WHat IF we delete some data?
DELETE FROM t2 WHERE c1 < 100000


-- You will see the deleted_rows count increase
-- Deletes are logical so the Delete bitmap indicates they are marked as deleted.
-- size_in_bytes won't change though
-- Also note the number of rowgroups
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO

ALTER INDEX t2CCI ON t2 REORGANIZE
GO
-- What when you rebuild the index?
-- Will number of rowgroups change?
ALTER INDEX t2CCI ON t2 REBUILD  ;
GO

--do the same thing, but reorg this time

DELETE FROM t2 WHERE c1 < 200000


-- You will see the deleted_rows count increase
-- Deletes are logical so the Delete bitmap indicates they are marked as deleted.
-- size_in_bytes won't change though
-- Also note the number of rowgroups
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO
ALTER INDEX t2CCI ON t2 REORGANIZE  ;
GO
--The TOMBSTONE rowgroups will be removed by the system
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO
checkpoint
