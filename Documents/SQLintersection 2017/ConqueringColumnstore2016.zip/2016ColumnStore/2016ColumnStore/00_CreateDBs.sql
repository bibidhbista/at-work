USE [master]
GO

IF DB_ID('ColumnstoreDB') IS NOT NULL
BEGIN
ALTER DATABASE ColumnstoreDB
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

DROP DATABASE [ColumnstoreDB]
END
GO

CREATE DATABASE [ColumnstoreDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'ColumnstoreDB', FILENAME = N'C:\Data\ColumnstoreDB.mdf' , SIZE = 5120KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'ColumnstoreDB_log', FILENAME = N'C:\Data\ColumnstoreDB_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

ALTER DATABASE [ColumnstoreDB] SET COMPATIBILITY_LEVEL = 130
GO


-- Restore AdventureWorks2016 IF not exist
USE master
GO
IF DB_ID('AdventureWorks2016') IS NOT NULL
BEGIN
ALTER DATABASE AdventureWorks2016
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

DROP DATABASE AdventureWorks2016

RESTORE DATABASE [AdventureWorks2016] 
FROM  DISK = N'C:\AWDataFile\AdventureWorks2014.bak' WITH  FILE = 1,  
MOVE N'AdventureWorks2014_Data' TO N'c:\DATA\2017\AdventureWorks2016_Data.mdf',  
MOVE N'AdventureWorks2014_Log' TO N'c:\DATA\2017\AdventureWorks2016_log.ldf', 
STATS = 5
END
ALTER DATABASE AdventureWorks2016 SET COMPATIBILITY_LEVEL = 130
GO
-------------------------------
USE master
GO
IF DB_ID('AdventureWorksDW2016') IS NOT NULL
BEGIN
ALTER DATABASE AdventureWorksDW2016
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

DROP DATABASE AdventureWorksDW2016

--restore filelistonly from disk= N'C:\Data\AdventureWorksDW2016.bak'
RESTORE DATABASE AdventureWorksDW2016 
FROM  DISK = N'C:\Data\AdventureWorksDW2014.bak' WITH  FILE = 1,  
MOVE N'AdventureWorksDW2014_Data' TO N'c:\DATA\AdventureWorksDW2016_Data.mdf',  
MOVE N'AdventureWorksDW2014_Log' TO N'c:\DATA\AdventureWorksDW2016_Log.ldf', 
STATS = 5
END
GO
ALTER DATABASE AdventureWorksDW2016 SET COMPATIBILITY_LEVEL = 130
GO
USE AdventureWorksDW2016
GO
CREATE TABLE Numbers(c1 INT, c2 varchar(20))
GO

SET NOCOUNT ON

INSERT Numbers 
SELECT TOP(4000000) x, CONVERT(VARCHAR(20), x)
FROM
(
SELECT x = row_number() over(order by a.number)
FROM master..spt_values a, 
master..spt_values b
WHERE 
	a.type = 'P' and b.type = 'P'
) a
GO
CREATE CLUSTERED INDEX CIXNumbersTable ON Numbers(c1)
GO