-- SETup 
Use ColumnstoreDB
GO
ALTER DATABASE ColumnstoreDB 
SET RECOVERY SIMPLE
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO
CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big] ;
GO


-- Bulk INSERT 50K Rows
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\50KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'
)
GO

-- Bulk Insert < 100K
-- CREATEs a Delta Store
SELECT COUNT(*) 
FROM FactResellerSalesPart_Big
GO
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('[FactResellerSalesPart_Big]')
GO



-- DROP AND ReCREATE TABLE again
--Bulk Insert > 100K
-- Empty TABLE so DROP AND reCREATE

IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO
CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big] ;
GO
-- INsert 105K rows.
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\105KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'

)

-- No Deltastore, directly optimized INTo Columnstore
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('[FactResellerSalesPart_Big]')
GO

-- Add a singleton row
INSERT INTO FactResellerSalesPart_Big
SELECT TOP 1 * FROM FactResellerSalesPart_Big

-- Now should have an open Deltastore
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('[FactResellerSalesPart_Big]')
GO

--Bulk Insert > 100K
-- Existing TABLE TABLE
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\105KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'

)

-- CREATEd a New Rowstore group AND INSERTed INTo that columstore group directly.
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('[FactResellerSalesPart_Big]')
GO

-- How about another INSERT?
--Bulk Insert > 100K
-- Existing TABLE TABLE
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\105KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'

)
-- Yet another Rowgroup
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('[FactResellerSalesPart_Big]')
GO

ALTER INDEX CCI ON FactResellerSalesPart_Big REORGANIZE

-- Can we ever reduce the rowgroups?
ALTER INDEX CCI ON FactResellerSalesPart_Big REBUILD  ;

-- RowGroups Consolidated.
SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('[FactResellerSalesPart_Big]')
GO
