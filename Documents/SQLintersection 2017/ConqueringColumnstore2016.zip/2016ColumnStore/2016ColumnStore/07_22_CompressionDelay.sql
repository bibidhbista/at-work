USE ColumnstoreDB
GO

DROP TABLE IF EXISTS staging
GO

-- CREATE staging TABLE
CREATE TABLE staging 
(
accountkey INT not null,
accountdescription nvarchar(50),
accounttype nvarchar(50),
AccountCodeAlternatekey INT
)


SET NOCOUNT ON
GO

	
INSERT staging
(
	accountkey,
	accountdescription,
	accounttype,
	AccountCodeAlternatekey
)
SELECT 
	x,
	'accountdesc ' + CONVERT(VARCHAR(20), X),
	'accounttype ' + CONVERT(VARCHAR(20), X),
	CAST (RAND()*10000000 AS INT)		
FROM
(
	SELECT x = c1
	FROM AdventureWorksDW2016..Numbers
	WHERE c1 <= 100000
) a
GO


SELECT COUNT(*) FROM staging
GO

DROP TABLE IF EXISTS ncci_target, ncci_target_delay
GO

CREATE TABLE ncci_target 
(
accountkey INT not null,
accountdescription nvarchar(50),
accounttype nvarchar(50),
AccountCodeAlternatekey INT
)
GO
CREATE CLUSTERED INDEX idx_ci_ncci_target 
ON ncci_target (accountkey)
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX idxncci_ncci_target 
on ncci_target 
(
accountkey, accountdescription, accounttype, accountcodealternatekey
) WITH (COMPRESSION_DELAY= 0)
GO


-- CREATE another TABLE with the delay of 5 minutes
CREATE TABLE ncci_target_delay
(
accountkey INT not null,
accountdescription nvarchar(50),
accounttype nvarchar(50),
AccountCodeAlternatekey INT
)
GO

CREATE CLUSTERED INDEX idx_ci_ncci_target_delay on  ncci_target_delay (accountkey)
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX idxncci_ncci_target_delay 
ON ncci_target_delay (accountkey, accountdescription, accounttype, accountcodealternatekey)
WITH (COMPRESSION_DELAY= 5)
GO

--look at catalog view
SELECT object_name(OBJECT_ID),  name, type_desc, has_filter, compression_delay
FROM sys.indexes 
WHERE OBJECT_ID = OBJECT_ID ('ncci_target') or OBJECT_ID=OBJECT_ID('ncci_target_delay')
GO
--load data INTo NCCI
-- takes around 2 minute
INSERT INTO ncci_target 
SELECT * FROM staging

INSERT INTo ncci_target_delay 
SELECT * FROM staging
GO 12

SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID ('ncci_target') or OBJECT_ID=OBJECT_ID('ncci_target_delay')
GO
-- look at rowgroups
SELECT object_name(OBJECT_ID), * 
FROM sys.dm_db_column_store_row_group_physical_stats 
WHERE OBJECT_ID = OBJECT_ID ('ncci_target') or OBJECT_ID=OBJECT_ID('ncci_target_delay')
GO
-- manual
ALTER INDEX idxncci_ncci_target on ncci_target 
REORGANIZE WITH (COMPRESS_ALL_ROW_GROUPS = ON)

ALTER INDEX idxncci_ncci_target on ncci_target 
REORGANIZE 

-- Note, you can change compression delay just as a metadata operation
ALTER INDEX idxncci_ncci_target on ncci_target SET (COMPRESSION_DELAY=5)

