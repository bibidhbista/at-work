USE ColumnstoreDB
GO
-- CREATE TABLE
IF OBJECT_ID('t2') IS NOT NULL
DROP TABLE t2
GO
CREATE TABLE t2 (c1 INT, c2 INT)
GO
-- CREATE CCI
CREATE CLUSTERED COLUMNSTORE INDEX t2CCI on t2
GO
-- review row group information
SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO
-- no rows

-- INSERT 1 row
INSERT t2 values(1,99)
GO

-- LEts CREATE an extENDed Event Session as we will USE this to see the tuple Moveover later
BEGIN try
DROP Event Session [TupleMover] on SERVER
END try
BEGIN catch
END catch
GO
:!! del C:\data\ColumnStore*.xel
GO
CREATE EVENT SESSION [TupleMover] ON SERVER 
ADD EVENT sqlserver.clustered_columnstore_index_rebuild(
    ACTION(sqlserver.session_id)),
ADD EVENT sqlserver.column_store_index_build_process_segment(
    ACTION(sqlserver.session_id)),
ADD EVENT sqlserver.columnstore_tuple_mover_BEGIN_compress(
    ACTION(package0.event_sequence,package0.last_error,sqlos.task_time,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.transaction_id)),
ADD EVENT sqlserver.columnstore_tuple_mover_END_compress(
    ACTION(package0.event_sequence,package0.last_error,sqlos.task_time,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.transaction_id))
ADD TARGET package0.event_file(SET filename=N'C:\data\ColumnStore.xel')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO


-- INSERT 1+ million rows  
SET nocount on

INSERT t2
SELECT
x+((x+1)%1000), x
FROM
(
SELECT x = c1
FROM AdventureWorksDW2016..Numbers
WHERE c1 <= 100000
) a
go 2

-- review row group information
-- 1 OPEN row group in delta store
-- Note the Delta_store_hobt_id
SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t2')
GO


-- Force the Tuple Moveover
ALTER EVENT SESSION TupleMover ON SERVER 
STATE=START;
GO
ALTER INDEX t2CCI ON t2 REORGANIZE  ;
GO
ALTER EVENT SESSION TupleMover ON SERVER 
STATE=STOP;
GO

SELECT *   
FROM sys.dm_db_column_store_row_group_physical_stats   
WHERE OBJECT_ID  = OBJECT_ID('t2')  
ORDER BY row_group_id;  