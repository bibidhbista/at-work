USE AdventureWorksDW2016
GO
ALTER DATABASE AdventureWorksDW2016 
SET RECOVERY SIMPLE
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big];
GO


-- Insert some data
-- Takes a WHILE on my system ( 2.2 mins) - 4.3 million rows.
-- WHILE INSERTing talk about fact that IF the input in bulk INSERT is sorted, segments are better formed.
BULK INSERT  dbo.[FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)
GO

-- View metadata on segments
SELECT partition_number,cs.column_id,c.name,segment_id,row_count,min_data_id,
max_data_id,on_disk_size,data_compression_desc, *
FROM sys.column_store_segments cs
JOIN sys.partitions p on cs.hobt_id=p.hobt_id
INNER JOIN sys.columns c on c.OBJECT_ID = p.OBJECT_ID AND c.column_id = cs.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
GO  


-- CREATE XE to track this
-- Watch Live data
CREATE EVENT SESSION [TrackSegmentElimination] ON SERVER 
ADD EVENT sqlserver.column_store_segment_eliminate(
    ACTION(sqlserver.sql_text))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
ALTER EVENT SESSION [TrackSegmentElimination] ON SERVER STATE = START
GO

SET STATISTICS IO ON;


-- You have most promotionkey values of less than 12.
-- From a metadata perspective can we derive what segments will be eliminated IF any?
SET STATISTICS IO ON
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey < 12;


-- How about for this query? How many segments are eliminated?
-- Segment elimination done AND we are in Row mode.
-- May take a bit to appear in the XE watch live data, GO on with the next couple queries.
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey > 13;


-- Metadata for OrderDateKey

SELECT partition_number,cs.column_id,c.name,segment_id,row_count,min_data_id,max_data_id,on_disk_size,data_compression_desc, *
FROM sys.column_store_segments cs
JOIN sys.partitions p on cs.hobt_id=p.hobt_id
INNER JOIN sys.columns c on c.OBJECT_ID = p.OBJECT_ID AND c.column_id = cs.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
AND c.name = 'OrderDateKey'
GO  

-- DOes this data even exist?
-- Look at exec plan also
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  OrderDateKey < 20010101;

-- How about this any segments elimated?
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  OrderDateKey < 20060901;

-- Changing OrderDate again
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  OrderDateKey = 20070901;



-- Character columns do not support segment elimination
-- though only one segment qualIFies here
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big] 
WHERE  SalesOrderNumber = 'SO50748'
GO

-- View metadata on segments
SELECT partition_number,cs.column_id,c.name,segment_id,row_count,min_data_id,max_data_id,on_disk_size,data_compression_desc, *
FROM sys.column_store_segments cs
JOIN sys.partitions p on cs.hobt_id=p.hobt_id
INNER JOIN sys.columns c on c.OBJECT_ID = p.OBJECT_ID AND c.column_id = cs.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
AND c.name = 'SalesOrderNumber'
GO  

/*
Dictionary type:
1 � Hash dictionary containing INT values
2 � Not USEd
3 � Hash dictionary containing string values
4 � Hash dictionary containing float values
For more information about dictionaries, see Columnstore Indexes.
 
 */
SELECT * FROM sys.column_store_dictionaries
WHERE column_id =10



-- Data correlation is potentially also taken care off 
-- Look at the Metadata between OrderDate AND Ship Date
SELECT partition_number,cs.column_id,c.name,segment_id,row_count,min_data_id,max_data_id,on_disk_size,data_compression_desc, *
FROM sys.column_store_segments cs
JOIN sys.partitions p on cs.hobt_id=p.hobt_id
INNER JOIN sys.columns c on c.OBJECT_ID = p.OBJECT_ID AND c.column_id = cs.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
AND c.name in( 'OrderDateKey','ShipDateKey')
GO

