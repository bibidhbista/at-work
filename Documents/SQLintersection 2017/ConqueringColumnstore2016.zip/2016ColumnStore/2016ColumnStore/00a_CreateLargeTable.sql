USE AdventureWorksDW2016
GO
DROP TABLE IF EXISTS [dbo].[FactResellerSales_Huge] 
GO 
USE [AdventureWorksDW2016]
GO
ALTER DATABASE [AdventureWorksDW2016]  REMOVE FILE [AdventureUserFGNCCI1_Data]
GO
ALTER DATABASE [AdventureWorksDW2016] REMOVE FILEGROUP UserFGNCCI
GO
ALTER DATABASE AdventureWorksDW2016 ADD FILEGROUP UserFGNCCI;
GO
ALTER DATABASE AdventureWorksDW2016 ADD FILE (NAME = AdventureUserFGNCCI1_Data,
	FILENAME = 'C:\DATA\AdventureUserFGNCCI1_Data.ndf',SIZE = 250MB)  
TO FILEGROUP UserFGNCCI ; 
GO

CREATE TABLE [dbo].[FactResellerSales_Huge]
(
	[ProductKey] [INT] NOT NULL,
	[OrderDateKey] [INT] NOT NULL,
	[DueDateKey] [INT] NOT NULL,
	[ShipDateKey] [INT] NOT NULL,
	[ResellerKey] [INT] NOT NULL,
	[EmployeeKey] [INT] NOT NULL,
	[PromotionKey] [INT] NOT NULL,
	[CurrencyKey] [INT] NOT NULL,
	[SalesTerritoryKey] [INT] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [tinyINT] NOT NULL,
	[RevisionNumber] [tinyINT] NULL,
	[OrderQuantity] [smallINT] NULL,
	[UnitPrice] [money] NULL,
	[ExtENDedAmount] [money] NULL,
	[UnitPriceDiscountPct] [float] NULL,
	[DiscountAmount] [float] NULL,
	[ProductStANDardCost] [money] NULL,
	[TotalProductCost] [money] NULL,
	[SalesAmount] [money] NULL,
	[TaxAmt] [money] NULL,
	[Freight] [money] NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[CustomerPONumber] [nvarchar](25) NULL,
	[OrderDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[ShipDate] [datetime] NULL,
	IDCol INT IDENTITY(1,1),
 CONSTRAINT [PK_FactResellerSalesHuge_SalesOrderNumber_SalesOrderLineNumber] PRIMARY KEY CLUSTERED 
(
	[SalesOrderNumber] ASC,
	[SalesOrderLineNumber] ASC,
	IDCol
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO FactResellerSales_Huge
SELECT *
FROM [dbo].[FactResellerSales]
GO


INSERT INTO FactResellerSales_Huge
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, EmployeeKey, PromotionKey, 
CurrencyKey, SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, 
OrderQuantity, UnitPrice, ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, 
Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate
)
SELECT 
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, EmployeeKey, PromotionKey, 
CurrencyKey, SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, 
OrderQuantity, UnitPrice, ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, 
Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate
FROM FactResellerSales_Huge
GO 5







