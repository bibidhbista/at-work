USE master
GO
IF DB_ID('LoadDB') IS NOT NULL
BEGIN
ALTER DATABASE LoadDB
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

DROP DATABASE LoadDB

END
GO
CREATE DATABASE LoadDB
GO
ALTER DATABASE LoadDB
SET RECOVERY SIMPLE
GO

USE LoadDB
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big](
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

-- Insert some data
-- Takes a WHILE on my system ( 2.2 mins) - 3 million rows.
-- WHILE INSERTing talk about fact that IF the input in bulk INSERT is sorted, segments are better formed.
BULK INSERT dbo.[FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)
GO


ALTER TABLE [dbo].[FactResellerSalesPart_Big]
ADD IDCol INT IDENTITY(1,1) PRIMARY KEY CLUSTERED
GO

CREATE COLUMNSTORE INDEX ncci_FRSPB ON [dbo].[FactResellerSalesPart_Big]
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, 
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, 
SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, 
ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber
)
GO

ALTER DATABASE LoadDB
SET READ_COMMITTED_SNAPSHOT ON
GO