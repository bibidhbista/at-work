-- SETup 
Use ColumnstoreDB
GO
ALTER DATABASE ColumnstoreDB 
SET RECOVERY SIMPLE
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)
GO


-- Bulk INSERT 50K Rows
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\105KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'
)
GO
ALTER TABLE [FactResellerSalesPart_Big]
ADD IDCol INT IDENTITY PRIMARY KEY CLUSTERED

GO

CREATE COLUMNSTORE INDEX nCCI ON [FactResellerSalesPart_Big]
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, EmployeeKey, 
PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, 
RevisionNumber, OrderQuantity, UnitPrice, ExtENDedAmount, UnitPriceDiscountPct, 
DiscountAmount, ProductStANDardCost, TotalProductCost, SalesAmount, TaxAmt, 
Freight, CarrierTrackingNumber, CustomerPONumber, IDCol
)
GO
select *
from sys.indexes 
where OBJECT_ID = OBJECT_ID('FactResellerSalesPart_Big')

SELECT *
FROM sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('FactResellerSalesPart_Big'), 2, null, null)


DBCC TRACEON(3604)
DBCC PAGE(ColumnstoreDB, 1, 27888, 2) 
