-- SETup 
USE AdventureWorksDW2016
GO
ALTER DATABASE AdventureWorksDW2016 SET RECOVERY SIMPLE
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big](
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

CREATE CLUSTERED INDEX CI ON [FactResellerSalesPart_Big] (OrderDateKey);
GO

	
-- Insert some data
BULK INSERT dbo.[FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)

-- Now check the Space USEd
/*
[FactResellerSalesPart_Big]	3067092             	617096 KB	613424 KB	3512 KB	160 KB
*/
sp_spaceused '[FactResellerSalesPart_Big]'


-- Now CREATE a NC columnstore
CREATE COLUMNSTORE INDEX NCCI 
on FactResellerSalesPart_Big (
[ProductKey],[OrderDateKey],[DueDateKey],
[ShipDateKey],  [ResellerKey],
[EmployeeKey],   [PromotionKey],
[CurrencyKey], [SalesTerritoryKey],
[SalesOrderNumber],[SalesOrderLineNumber],
[RevisionNumber], [OrderQuantity],
[UnitPrice], [ExtENDedAmount],
[UnitPriceDiscountPct], [DiscountAmount],
[ProductStANDardCost], [TotalProductCost] ,
[SalesAmount] ,
[TaxAmt],
[Freight],
[CarrierTrackingNumber] ,
[CustomerPONumber] 
)  
GO

-- Size. THis is additional storage for NC Column store in addition to regular clustered index
/*
[FactResellerSalesPart_Big]	3067092             	629520 KB	613424 KB	15736 KB	360 KB
*/

sp_spaceused '[FactResellerSalesPart_Big]'

-- DROP the NC Columnstore index
DROP INDEX FactResellerSalesPart_Big.NCCI

-- CREATE Clustered columnstore index
-- Have to USE DROP_existing to convert current Clustered index
-- Taks about 50 seconds
CREATE CLUSTERED COLUMNSTORE INDEX CI ON [FactResellerSalesPart_Big]
WITH (DROP_EXISTING=ON)
GO

-- See space
-- This time around Data is compressed not a COPY of data compressed.
/*
FactResellerSalesPart_Big	1397838             	200336 KB	200296 KB	0 KB	40 KB
*/
sp_spaceused '[FactResellerSalesPart_Big]'


-- What do we see FROM a RowGroup perspective.
-- We will discuss the State of the rowgroup later AND some other details.
-- RIght now you can see the rows in dIFferent rowgroups, group new group CREATEd after 1048576 rows IF bulk INSERTing
USE [AdventureWorksDW2016]
SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
ORDER BY partition_number, row_group_id;
GO



-- What about Segments
-- Segments is all about individual colums for a rowgroup
-- Looking closely you see Colum_id 1 has 3 segments

SELECT partition_number,column_id,segment_id,row_count,on_disk_size,data_compression_desc, *
FROM sys.column_store_segments cs
JOIN sys.partitions p on
cs.hobt_id=p.hobt_id
WHERE OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
GO    


--archive compression
CREATE CLUSTERED COLUMNSTORE INDEX CI ON [FactResellerSalesPart_Big]
WITH (DROP_EXISTING=ON, DATA_COMPRESSION = COLUMNSTORE_ARCHIVE)
GO

sp_spaceused '[FactResellerSalesPart_Big]'

