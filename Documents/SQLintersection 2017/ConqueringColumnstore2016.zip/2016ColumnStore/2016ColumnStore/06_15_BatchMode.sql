-- SETup ( IF required

Use AdventureWorksDW2016
GO
ALTER DATABASE AdventureWorksDW2016 SET recovery simple
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big](
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big];
GO


-- Insert some data
-- Takes a WHILE on my system 
-- WHILE INSERTing talk about fact that IF the input in bulk INSERT is sorted, segments are better formed.
BULK INSERT  AdventureWorksDW2016.dbo.[FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)
GO
select count(*) from FactResellerSalesPart_Big
GO
-- View metadata on segments
SELECT partition_number,cs.column_id,c.name,segment_id,row_count,min_data_id,
max_data_id,on_disk_size,data_compression_desc,*
FROM sys.column_store_segments cs
JOIN sys.partitions p on cs.hobt_id=p.hobt_id
INNER JOIN sys.columns c on c.OBJECT_ID = p.OBJECT_ID AND c.column_id = cs.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
ORDER BY c.column_id asc
GO  

SET statistics io on
GO

-- Example of Batch Aggregation most segments have promotionkey values of less than 12.
-- You can see due to in batch mode in the Plan
-- Also see that the rollup to the aggregate is in batch mode
dbcc dropcleanbuffers
SET STATISTICS IO ON

SELECT count(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey > 100


-- In 2012, 2014 if maxdop = 1 then no batch mode
-- If 2016 then batch mode works if dop is 1
USE [master]
GO
ALTER DATABASE [AdventureWorksDW2016] 
SET COMPATIBILITY_LEVEL = 130
GO

USE AdventureWorksDW2016
GO
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey < 12
OPTION(MAXDOP 1)

-- In 2016 if maxdop = 1 then batch mode can be used
USE [master]
GO
ALTER DATABASE [AdventureWorksDW2016] 
SET COMPATIBILITY_LEVEL = 130
GO

USE AdventureWorksDW2016
GO
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey < 12
OPTION(MAXDOP 1)

-- Only Few Segments qualify for this query
-- Segment elimination occurs and we are in Row mode.
SELECT COUNT(*)
FROM   dbo.[FactResellerSalesPart_Big]
WHERE  PromotionKey > 13;


-- Behavior of NOT IN

DROP TABLE IF EXISTS tblCurrencies
GO
CREATE TABLE dbo.tblCurrencies
(
	CurrencyKey INT NOT NULL PRIMARY KEY
)
GO
INSERT INTO dbo.tblCurrencies (CurrencyKey) VALUES (19),(88),(6);
GO

-- In SQL 2012 the NOT IN would cause a Row mode.
-- Would have to USE pre-aggregated data/CTE/Derived TABLEs to work around it OR USE IN clause.
SELECT 
	SalesTerritoryRegion, SalesTerritoryCountry,
	SUM(SalesAmount) as TotalSales, COUNT(SalesOrderNumber) as NumSales
FROM 
[FactResellerSalesPart_Big] fct
INNER JOIN DimSalesTerritory dt  on dt.SalesTerritoryKey = fct.SalesTerritoryKey
WHERE 
	fct.CurrencyKey NOT IN ( SELECT CurrencyKey FROM tblCurrencies)
GROUP BY 
	fct.SalesTerritoryKey,SalesTerritoryRegion ,SalesTerritoryCountry



-- Predicate push down
SELECT 
	SalesTerritoryRegion, SalesTerritoryCountry,
	SUM(SalesAmount) as TotalSales, COUNT(SalesOrderNumber) as NumSales
FROM 
[FactResellerSalesPart_Big] fct
INNER JOIN DimSalesTerritory dt  on dt.SalesTerritoryKey = fct.SalesTerritoryKey
WHERE 
	fct.CurrencyKey IN ( SELECT CurrencyKey FROM tblCurrencies)
GROUP BY 
	fct.SalesTerritoryKey,SalesTerritoryRegion ,SalesTerritoryCountry
GO


SELECT TOP 10 * FROM [FactResellerSalesPart_Big]

