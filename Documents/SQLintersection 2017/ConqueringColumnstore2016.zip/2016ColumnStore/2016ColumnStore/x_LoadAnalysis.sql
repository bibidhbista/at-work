USE LoadDB
GO
SELECT lck.request_session_id,
       lck.request_mode,
	   lck.request_status,
       lck.resource_type,
       lck.resource_description,
	    CASE
           WHEN resource_type = 'object'
               THEN OBJECT_NAME(lck.resource_associated_entity_id)
           ELSE OBJECT_NAME(p.OBJECT_ID)
       END AS ObjectName,
	   i.name AS index_name,
       lck.resource_associated_entity_id
FROM sys.dm_tran_locks lck
LEFT JOIN sys.partitions p ON p.hobt_id = lck.resource_associated_entity_id
JOIN sys.indexes i ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
WHERE resource_associated_entity_id > 0 AND resource_database_id = DB_ID()
ORDER BY request_session_id, resource_associated_entity_id 
GO
-- View metadata on segments
SELECT partition_number,cs.column_id,c.name,segment_id,row_count,min_data_id,
max_data_id,on_disk_size,data_compression_desc,*
FROM sys.column_store_segments cs
JOIN sys.partitions p on cs.hobt_id=p.hobt_id
INNER JOIN sys.columns c on c.OBJECT_ID = p.OBJECT_ID AND c.column_id = cs.column_id
WHERE p.OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')
ORDER BY c.column_id asc
GO  


SELECT *
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('FactResellerSalesPart_Big')
GO
-- look at rowgroups
SELECT object_name(OBJECT_ID), * 
FROM sys.dm_db_column_store_row_group_physical_stats 
WHERE OBJECT_ID = OBJECT_ID ('FactResellerSalesPart_Big')

ALTER INDEX ncci_FRSPB ON FactResellerSalesPart_Big
REBUILD
GO

690232
677753
650531
1048576

SELECT *
FROM sys.allocation_units a
join sys.partitions p on a.container_id = CASE WHEN a.type = 2 THEN p.partition_id ELSE p.hobt_id END
WHERE allocation_unit_id = 72057594041663488

652055
652372
646670
1048576

WITH CTE
AS
(
SELECT TOP(1000) *
FROM FactResellerSalesPart_Big
--ORDER BY IDCol DESC
)
DELETE FROM CTE 


WITH CTE
AS
(
SELECT TOP(10000) *
FROM FactResellerSalesPart_Big
ORDER BY IDCol ASC
)
DELETE FROM CTE 


select * from sys.system_objects where name like '%delta%'

SELECT COUNT(*)
FROM FactResellerSalesPart_Big

2957092

