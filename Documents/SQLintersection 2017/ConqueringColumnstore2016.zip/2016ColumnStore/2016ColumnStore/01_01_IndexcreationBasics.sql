USE ColumnstoreDB
GO

--CREATE TABLE
DROP TABLE IF EXISTS t1
GO
CREATE TABLE t1 (c1 INT, c2 nvarchar(20))
GO

--CREATE clustered columnstore index
CREATE CLUSTERED COLUMNSTORE INDEX t1CCI on t1
GO

-- Will succeed in 2016
ALTER TABLE t1 
ADD CONSTRAINT c1_unique UNIQUE (c1)

select * from t1 
GO

-- Now DROP AND CREATE the TABLE
DROP TABLE t1
GO
CREATE TABLE t1 (c1 INT, c2 nvarchar(20))
GO

-- CREATE a normal clustered index
CREATE CLUSTERED INDEX t1CI on t1(c1)

-- How to move this to clustered columstore?
CREATE CLUSTERED COLUMNSTORE INDEX t1CI on t1
WITH (DROP_EXISTING=ON)
GO


-- Now lets INSERT some rows
-- You can INSERT INTo Clustered Columstore index
INSERT INTO t1 VALUES(1,'Test')
GO
CREATE UNIQUE INDEX u_t1_c1 ON t1(c1)
GO
select * from t1 where c1 = 1
-- DROP index
DROP INDEX t1.t1CI
GO

-- CREATE unique constraINT AGAIN  AND should suceed
ALTER TABLE t1 
ADD CONSTRAINT c1_unique UNIQUE (c1)
GO

--CREATE NON-clustered columnstore index
CREATE NONCLUSTERED COLUMNSTORE INDEX t1CI ON t1(c1,c2)
GO

-- works just fine in SQL 2016
INSERT t1 VALUES(2,'A')
GO
select * from sys.indexes
where object_id = object_id('t1')


-- Do we have any Row groups created?
-- Yes AND the row_group is Open given very few rows exist
SELECT * 
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID('t1')
GO

-- What about Segments
-- One segment per column
SELECT * 
FROM sys.column_store_segments s
join sys.partitions p on s.hobt_id = p.hobt_id
WHERE OBJECT_ID = OBJECT_ID('t1')


