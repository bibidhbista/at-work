USE master
GO
IF DB_ID('InMemoryCS') IS NOT NULL
BEGIN
ALTER DATABASE InMemoryCS
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

DROP DATABASE InMemoryCS


END
GO
CREATE DATABASE InMemoryCS
ON  PRIMARY 
( NAME = N'InMemoryCS_data', FILENAME = N'C:\DATA\InMemoryCS_data.mdf'),  
FILEGROUP [InMemoryCS_InMemory] CONTAINS MEMORY_OPTIMIZED_DATA  
( NAME = N'InMemoryCS_mem', FILENAME = N'C:\DATA\InMemoryCS_Lun1') 
LOG ON ( NAME = N'InMemoryCS_log', FILENAME = N'C:\DATA\InMemoryCS_log.ldf')
GO

-- Add a second path to the filegroup
ALTER DATABASE InMemoryCS
ADD FILE (NAME = InMemoryCS_InMemory, FILENAME = N'C:\Data\InMemoryCS_Lun2')
TO FILEGROUP [InMemoryCS_InMemory]
GO
USE InMemoryCS
GO
SELECT * 
INTO Numbers
FROM AdventureWorksDW2016..Numbers
WHERE c1 <= 2000000
GO


-- CREATE a memopt TABLE
CREATE TABLE dbo.InMemColumnstoreTable 
(
	AccountKey INT not null,
	AccountDescription nvarchar(50),
	AccountType nvarchar(50),
	UnitSold INT,
	CONSTRAINT [pk_InMemColumnstoreTable] PRIMARY KEY NONCLUSTERED HASH (AccountKey) 
	WITH (BUCKET_COUNT = 10000000)
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA)
GO

--does this work?
CREATE INDEX InMemColumnstoreTable_cci
ON InMemColumnstoreTable
(
AccountKey, AccountDescription, AccountType, UnitSold
)
GO


--just insert 1000000 rows at first
INSERT INTO InMemColumnstoreTable
(
	accountkey,
	accountdescription,
	accounttype,
	UnitSold
)
SELECT 
	x,
	'accountdesc ' + CONVERT(VARCHAR(20), X),
	'accounttype ' + CONVERT(VARCHAR(20), X),
	X%50		
FROM
(
	SELECT x = c1
	FROM Numbers
) a

--you can add index after creating HK TABLE (New in SQL 2016)
ALTER TABLE InMemColumnstoreTable 
ADD INDEX InMemColumnstoreTable_cci CLUSTERED COLUMNSTORE
GO

SELECT * 
FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
ORDER BY partition_number, row_group_id;
GO

SELECT object_name(OBJECT_ID), * 
FROM sys.dm_db_column_store_row_group_physical_stats 
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
GO


SELECT object_name(OBJECT_ID),  name, type_desc, has_filter, compression_delay
FROM sys.indexes 
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
GO

SELECT COUNT(*), SUM(UnitSold)
FROM InMemColumnstoreTable
GO


BEGIN TRY
DROP EVENT SESSION [TupleMover] ON SERVER 
END TRY
BEGIN CATCH
END CATCH
GO

GO
CREATE EVENT SESSION [TupleMover] ON SERVER 
ADD EVENT sqlserver.clustered_columnstore_index_rebuild(
    ACTION(sqlserver.session_id)),
ADD EVENT sqlserver.column_store_index_build_process_segment(
    ACTION(sqlserver.session_id)),
ADD EVENT sqlserver.columnstore_tuple_mover_begin_compress(
    ACTION(package0.event_sequence,package0.last_error,sqlos.task_time,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.transaction_id)),
ADD EVENT sqlserver.columnstore_tuple_mover_compression_stats,
ADD EVENT sqlserver.columnstore_tuple_mover_end_compress(
    ACTION(package0.event_sequence,package0.last_error,sqlos.task_time,sqlserver.database_name,sqlserver.session_id,sqlserver.sql_text,sqlserver.transaction_id))
ADD TARGET package0.event_file(SET filename=N'C:\data\ColumnStore.xel')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
ALTER EVENT SESSION [TupleMover] ON SERVER 
STATE = START
GO
--insert 2M rows more
INSERT INTO InMemColumnstoreTable
(
	accountkey,
	accountdescription,
	accounttype,
	UnitSold
)
SELECT 
	x,
	'accountdesc ' + CONVERT(VARCHAR(20), X),
	'accounttype ' + CONVERT(VARCHAR(20), X),
	X%50		
FROM
(
	SELECT x = c1 + 3000000
	FROM Numbers
) a
GO



--whats happening when this CCI is dropped?
ALTER TABLE InMemColumnstoreTable 
DROP INDEX InMemColumnstoreTable_cci 
GO
--try to use a compression_delay of 5
ALTER TABLE InMemColumnstoreTable 
ADD INDEX InMemColumnstoreTable_cci CLUSTERED COLUMNSTORE WITH (COMPRESSION_DELAY=5)
GO
--adjust the compression delay
ALTER TABLE InMemColumnstoreTable 
ADD INDEX InMemColumnstoreTable_cci CLUSTERED COLUMNSTORE WITH (COMPRESSION_DELAY=60)
GO

SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
ORDER BY partition_number, row_group_id;

--try to rebuild the index
ALTER INDEX InMemColumnstoreTable_cci ON InMemColumnstoreTable 
REBUILD
GO

SELECT * FROM sys.column_store_row_groups
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
ORDER BY partition_number, row_group_id;
GO

SELECT object_name(OBJECT_ID), * 
FROM sys.dm_db_column_store_row_group_physical_stats 
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
GO

SELECT object_name(OBJECT_ID),  name, type_desc, has_filter, compression_delay
FROM sys.indexes 
WHERE OBJECT_ID = OBJECT_ID ('InMemColumnstoreTable')
GO