-- SETup 
Use ColumnstoreDB
GO
ALTER DATABASE ColumnstoreDB 
SET RECOVERY SIMPLE
GO
If OBJECT_ID('FactResellerSalesPart_Big') is not null
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big]
(
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO
CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big] ;
GO


-- Bulk INSERT 50K Rows
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\50KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'
)
-- Bulk INSERT 50K Rows
BULK INSERT  [FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\105KRows.txt'
WITH 
(
    FIELDTERMINATOR =',',
	ROWTERMINATOR ='\n'
)
GO 5


SELECT *
FROM sys.column_store_row_groups
WHERE object_id = object_id('FactResellerSalesPart_Big')
GO
-- look at rowgroups
SELECT object_name(object_id), * 
FROM sys.dm_db_column_store_row_group_physical_stats 
WHERE object_id = object_id ('FactResellerSalesPart_Big')


set statistics io on
SELECT COUNT(*)
FROM FactResellerSalesPart_Big
/*
Table 'FactResellerSalesPart_Big'. Scan count 2, logical reads 2507, physical reads 0, read-ahead reads 0, 
lob logical reads 30, lob physical reads 0, lob read-ahead reads 0.
Table 'FactResellerSalesPart_Big'. Segment reads 5, segment skipped 0.
*/

ALTER INDEX CCI ON [FactResellerSalesPart_Big]
REBUILD
GO

/*
Table 'FactResellerSalesPart_Big'. Scan count 1, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 6, lob physical reads 0, lob read-ahead reads 0.
Table 'FactResellerSalesPart_Big'. Segment reads 1, segment skipped 0.
*/