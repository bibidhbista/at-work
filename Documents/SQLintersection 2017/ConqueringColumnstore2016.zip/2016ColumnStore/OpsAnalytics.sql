:SETvar SourceDB AdventureWorks2016
:SETvar InMemDB InMemoryOLTP

USE $(InMemDB)
GO
IF object_id('dbo.SOD_Full') IS NOT NULL
	DROP TABLE dbo.SOD_Full 
GO
SELECT *
INTO dbo.SOD_Full
FROM $(SourceDB).Sales.SalesOrderDetail
GO

--CREATE an In-Memory TABLE with a clustered Columnstore index
IF OBJECT_ID('dbo.SalesOrderDetail_CS') IS NOT NULL
	DROP TABLE dbo.SalesOrderDetail_CS 
GO
CREATE TABLE dbo.SalesOrderDetail_CS(
	SalesOrderID INT NOT NULL INDEX SODCS_SalesOrderID HASH WITH (BUCKET_COUNT=1000),
	SalesOrderDetailID bigINT IDENTITY NOT NULL,
	CarrierTrackingNumber nvarchar(25) NULL,
	OrderQty smallINT NOT NULL,
	ProductID INT NOT NULL INDEX SODCS_ProductID HASH WITH (BUCKET_COUNT=1000),
	SpecialOfferID INT NOT NULL,
	UnitPrice money NOT NULL,
	UnitPriceDiscount money NOT NULL,
	SaleDate datetime NOT NULL ,

	INDEX CCI_SODCS CLUSTERED COLUMNSTORE,
	--INDEX NCCI_SODCS NONCLUSTERED COLUMNSTORE(
	--SalesOrderID,
	--SalesOrderDetailID,
	--CarrierTrackingNumber,
	--OrderQty,
	--ProductID,
	--SpecialOfferID,
	--UnitPrice,
	--UnitPriceDiscount,
	--SaleDate
	--),

	CONSTRAINT SODCS_SalesOrderDetailCS_SalesOrderID_SalesOrderDetailID PRIMARY KEY NONCLUSTERED HASH 
	(	SalesOrderID,
		SalesOrderDetailID
	)WITH (BUCKET_COUNT=2000)
) WITH (MEMORY_OPTIMIZED=ON)
GO


SET IDENTITY_INSERT dbo.SalesOrderDetail_CS ON
INSERT INTO dbo.SalesOrderDetail_CS
(
SalesOrderID,
SalesOrderDetailID,
CarrierTrackingNumber,
OrderQty,
ProductID,
SpecialOfferID,
UnitPrice,
UnitPriceDiscount,
SaleDate
	)
SELECT
	SalesOrderID,
	SalesOrderDetailID,
	CarrierTrackingNumber,
	OrderQty,
	ProductID,
	SpecialOfferID,
	UnitPrice,
	UnitPriceDiscount,
	ModIFiedDate
FROM dbo.SOD_Full
SET IDENTITY_INSERT dbo.SalesOrderDetail_CS OFF
GO

--look at EXECUTE plans

SELECT *
FROM dbo.SalesOrderDetail_CS
WHERE SalesOrderID = 73946

SELECT *
FROM dbo.SalesOrderDetail_CS
WHERE SalesOrderID > 75121

----------------------------------------------------
--add a flag to the on-disk TABLE
ALTER TABLE dbo.SOD_Full
ADD Archive BIT 
GO

UPDATE dbo.SOD_Full
SET Archive = CASE WHEN DATEDIFF(MONTH, ModIFiedDate, GETDATE()) > 6 THEN 1 ELSE 0 END
GO

--add a filtered NCCI 
CREATE NONCLUSTERED COLUMNSTORE INDEX NCCI_SODCS ON dbo.SOD_Full
(SalesOrderID,
SalesOrderDetailID,
CarrierTrackingNumber,
OrderQty,
ProductID,
SpecialOfferID,
UnitPrice,
UnitPriceDiscount,
ModIFiedDate)
WHERE Archive = 1

SELECT SalesOrderID,
SalesOrderDetailID,
CarrierTrackingNumber,
OrderQty,
ProductID,
SpecialOfferID,
UnitPrice,
UnitPriceDiscount,
ModIFiedDate
FROM dbo.SOD_Full
WHERE Archive = 1

SELECT *
FROM dbo.SOD_Full
WHERE Archive = 1

SELECT SalesOrderID,
SalesOrderDetailID,
CarrierTrackingNumber,
OrderQty,
ProductID,
SpecialOfferID,
UnitPrice,
UnitPriceDiscount,
ModIFiedDate
FROM dbo.SOD_Full
WHERE Archive = 0
