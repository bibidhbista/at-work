Use AdventureWorksDW2014
GO
ALTER DATABASE AdventureWorksDW2014 
SET RECOVERY SIMPLE
GO
IF OBJECT_ID('FactResellerSalesPart_Big') IS NOT NULL
DROP TABLE FactResellerSalesPart_Big
GO

CREATE TABLE [dbo].[FactResellerSalesPart_Big](
[ProductKey] [INT] NOT NULL,
[OrderDateKey] [INT] NOT NULL,
[DueDateKey] [INT] NOT NULL,
[ShipDateKey] [INT] NOT NULL,
[ResellerKey] [INT] NOT NULL,
[EmployeeKey] [INT] NOT NULL,
[PromotionKey] [INT] NOT NULL,
[CurrencyKey] [INT] NOT NULL,
[SalesTerritoryKey] [INT] NOT NULL,
[SalesOrderNumber] [nvarchar](20) NOT NULL,
[SalesOrderLineNumber] [tinyINT] NOT NULL,
[RevisionNumber] [tinyINT] NULL,
[OrderQuantity] [smallINT] NULL,
[UnitPrice] [money] NULL,
[ExtENDedAmount] [money] NULL,
[UnitPriceDiscountPct] [float] NULL,
[DiscountAmount] [float] NULL,
[ProductStANDardCost] [money] NULL,
[TotalProductCost] [money] NULL,
[SalesAmount] [money] NULL,
[TaxAmt] [money] NULL,
[Freight] [money] NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[CustomerPONumber] [nvarchar](25) NULL
)  
GO

--CREATE CLUSTERED COLUMNSTORE INDEX CCI ON [FactResellerSalesPart_Big];
--GO


-- Insert some data
-- Takes a WHILE on my system ( 2.2 mins) - 4.3 million rows.
-- WHILE INSERTing talk about fact that IF the input in bulk INSERT is sorted, segments are better formed.
BULK INSERT  AdventureWorksDW2014.dbo.[FactResellerSalesPart_Big]
FROM 'C:\Workshop\ColumnStoreDemos\FactResellerSalesPart.txt'
WITH 
(
    FIELDTERMINATOR ='\t',
	ROWTERMINATOR ='\n'

)

ALTER TABLE FactResellerSalesPart_Big
ADD IDCol INT IDENTITY(1,1) PRIMARY KEY CLUSTERED
GO

IF COLUMNPROPERTY(OBJECT_ID('FactResellerSalesPart_Big'), 'ArchiveDate', 'ColumnID') IS NOT NULL
ALTER TABLE FactResellerSalesPart_Big
DROP COLUMN ArchiveDate
GO

ALTER TABLE FactResellerSalesPart_Big 
ADD ArchiveDate DATETIME NULL
GO

DECLARE @Mod INT, @MinDate DATETIME = '1/1/2009'
SELECT @Mod = CAST(GETDATE() AS INT) - CAST(@MinDate AS INT)

UPDATE FactResellerSalesPart_Big
SET ArchiveDate = (IDCol % @Mod)+ CAST(@MinDate AS INT)
GO

CREATE NONCLUSTERED INDEX idx_FRSP_ArchiveDate 
ON FactResellerSalesPart_Big(ArchiveDate)
GO

CREATE NONCLUSTERED COLUMNSTORE INDEX NCCI_SODCS 
ON FactResellerSalesPart_Big
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, 
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, 
SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, 
ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, 
CustomerPONumber, ArchiveDate, IDCol
)
WHERE ArchiveDate < '6/1/2015'

SELECT COUNT(*)
FROM FactResellerSalesPart_Big
WHERE ArchiveDate < '6/1/2015'

SELECT COUNT(*)
FROM FactResellerSalesPart_Big
WHERE ArchiveDate > '6/1/2015'






