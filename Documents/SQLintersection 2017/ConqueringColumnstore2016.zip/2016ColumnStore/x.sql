USE master
GO
/*
!!mkdir D:\SQL\DATA

ALTER DATABASE AdventureWorks2016DW
SET SINGLE_USER WITH ROLLBACK IMMEDIATE

RESTORE DATABASE AdventureWorks2016DW 
FROM DISK = 'C:\SQL\AWDW2016.bak'
WITH 
	MOVE 'AdventureWorksDW2014_Data' TO 'D:\SQL\DATA\AdventureWorksDW2016_Data.mdf', 
	MOVE 'AdventureWorksDW2014_Log' TO 'D:\SQL\DATA\AdventureWorksDW2016_Log.ldf', 
	MOVE 'SalesOrder' TO 'D:\SQL\SalesOrder',
	STATS = 5, REPLACE
GO
*/

USE AdventureWorks2016DW
GO
SET STATISTICS IO ON


-- VerIFy the size of the TABLE
SELECT RowCnt = FORMAT(COUNT(*), 'N', 'en-us') 
FROM FactResellerSalesXL_CCI
GO

EXECUTE sp_helpindex 'FactResellerSalesXL_CCI'

-- CREATE a foreign key
ALTER TABLE [dbo].[FactResellerSalesXL_CCI]  WITH CHECK 
ADD CONSTRAINT [FK_FactResellerSalesXLCCI_DimEmployee] FOREIGN KEY([EmployeeKey])
REFERENCES [dbo].[DimEmployee] ([EmployeeKey])
GO
ALTER TABLE [dbo].[FactResellerSalesXL_CCI] 
CHECK CONSTRAINT [FK_FactResellerSalesXLCCI_DimEmployee]
GO

-- 2. verIFy that foreign key enforces ref. INTegrity: This will produce an error
DECLARE @nonexistentEmployeeKey INT
SELECT @nonexistentEmployeeKey = MAX(EmployeeKey)+1 FROM [DimEmployee]
INSERT INTO FactResellerSalesXL_CCI
([ProductKey],[OrderDateKey],[DueDateKey],[ShipDateKey],
 [ResellerKey],[EmployeeKey],[PromotionKey],[CurrencyKey],
 [SalesTerritoryKey],[SalesOrderNumber],[SalesOrderLineNumber])
VALUES(310,20140101,20140104,20140102,150,@nonexistentEmployeeKey,
1,100,10,'S0101',1)
GO

-- CREATE an additional non-clustered index on the TABLE
--1 Run a simple query without the additional index
--look at the EXECUTEution plan
SET STATISTICS IO ON
GO

SELECT b.ProductKey, OrderDateKey, SalesTerritoryKey, EmployeeKey
FROM FactResellerSalesXL_CCI a 
INNER JOIN DimProduct b ON a.ProductKey = b.ProductKey
WHERE OrderDateKey BETWEEN 20080201 AND 20090801
AND b.ProductKey = 310
GO

-- 3 CREATE a non-clustered index. 
CREATE NONCLUSTERED INDEX idxProductOrderDate
ON dbo.FactResellerSalesXL_CCI (ProductKey, OrderDateKey)
INCLUDE (EmployeeKey, SalesTerritoryKey)
GO

-- 4 re-run the query now that there is an index

GO
SELECT b.ProductKey, OrderDateKey, SalesTerritoryKey, EmployeeKey
FROM FactResellerSalesXL_CCI a 
INNER JOIN DimProduct b ON a.ProductKey = b.ProductKey
WHERE OrderDateKey BETWEEN 20080201 AND 20090801
AND b.ProductKey = 310
GO

-------------------------------------------------------------------------
--try to CREATE multiple CS indexes on the same TABLE
SELECT *
INTO dbo.FactResellerSales_Test
FROM [dbo].[FactResellerSales]
GO
--CREATE a clustered CS index
CREATE CLUSTERED COLUMNSTORE INDEX CCI_FactResellerSales_Test
ON dbo.FactResellerSales_Test
GO
--try to add a NC CS index to the same TABLE
CREATE NONCLUSTERED COLUMNSTORE INDEX NCCI_FactResellerSalesTest 
ON [dbo].FactResellerSales_Test
(
	[ProductKey],
	[OrderDateKey],
	[DueDateKey]
)WITH (DROP_EXISTING = OFF)

GO

-------------------------------------------------------------------------
--Comparing performance with a nonclustered Columnstore index

sp_helpindex 'FactResellerSalesXL_PageCompressed'

-- 1 CREATE a non-clustered columnstore index on a TABLE that already has a clustered index on it. 
CREATE NONCLUSTERED COLUMNSTORE INDEX [Idx_Columnstore] 
ON [dbo].[FactResellerSalesXL_PageCompressed]
(
	[ShipDateKey],
	[SalesTerritoryKey],
	[ProductKey],
	[SalesAmount]
)  ON [PRIMARY]
GO


-- Try to CREATE a second NCCI index
CREATE NONCLUSTERED COLUMNSTORE INDEX [Idx_Columnstore2] 
ON [dbo].[FactResellerSalesXL_PageCompressed]
(
	[ShipDateKey],
	[SalesTerritoryKey],
	[ProductKey],
	[SalesAmount]
)WITH (DROP_EXISTING = OFF) ON [PRIMARY]
GO

-- 2 Run a query, but ignore the index
-- Get the query plan
DBCC DROPCLEANBUFFERS
GO
SELECT AVG(SalesAmount) AS AvgSales, SUM(SalesAmount) AS TotalSales
FROM FactResellerSalesXL_PageCompressed
WHERE ShipDateKey BETWEEN 20080101 AND 20100101
GROUP BY SalesTerritoryKey, ProductKey
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX) --this ignores the index
GO

-- 3 Run the query again, this time with the index
DBCC DROPCLEANBUFFERS
GO
SELECT AVG(SalesAmount) AS AvgSales, SUM(SalesAmount) AS TotalSales
FROM FactResellerSalesXL_PageCompressed
WHERE ShipDateKey BETWEEN 20080101 AND 20100101
GROUP BY SalesTerritoryKey, ProductKey
GO

-- Inserting data to a TABLE with a non-clustered Columnstore index
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
INSERT INTO FactResellerSalesXL_PageCompressed
(ProductKey, OrderDateKey, DueDateKey,
ShipDateKey, ResellerKey, EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey,
SalesOrderNumber, SalesOrderLineNumber, OrderQuantity, UnitPrice, SalesAmount, TaxAmt)
SELECT TOP 2000 ProductKey, OrderDateKey, DueDateKey, 20150601, ResellerKey,
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber+'T', 
SalesOrderLineNumber, OrderQuantity, UnitPrice, SalesAmount, TaxAmt
FROM FactResellerSalesXL_CCI
WHERE ShipDateKey BETWEEN 20121205 AND 20140101;

-- Display the newly INSERTed rows
SELECT * 
FROM FactResellerSalesXL_PageCompressed 
WHERE ShipDateKey = 20150601;


