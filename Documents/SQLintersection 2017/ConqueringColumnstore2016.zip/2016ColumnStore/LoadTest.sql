
--assume 3m rows in table
DECLARE @IDCol INT, @Op CHAR(1)
SET @IDCol = ABS(BINARY_CHECKSUM(NEWID()))%3000000

----SET @Op = CASE @IDCol % 3 
----				WHEN 0 THEN 'I'
----				WHEN 1 THEN 'U'
----				WHEN 2 THEN 'D'  
----			END

----IF @Op = 'I'
----BEGIN


INSERT INTO [dbo].[FactResellerSalesPart_Big]
(
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, 
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, 
SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, 
ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber
)
SELECT
ProductKey, OrderDateKey, DueDateKey, ShipDateKey, ResellerKey, 
EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, 
SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, 
ExtENDedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStANDardCost, 
TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber
FROM [dbo].[FactResellerSalesPart_Big]
WHERE
IDCol BETWEEN @IDCol and @IDCol + 100


END
ELSE IF @Op = 'U'
BEGIN
UPDATE [dbo].[FactResellerSalesPart_Big]
SET
OrderQuantity += 1,
UnitPrice += 2, 
ExtENDedAmount += 3, 
UnitPriceDiscountPct += 1, 
DiscountAmount += 2, 
ProductStANDardCost += 3, 
TotalProductCost += 1, 
SalesAmount += 2, 
TaxAmt += 3, 
Freight += 1
WHERE
	IDCol BETWEEN @IDCol and @IDCol + 100

END
ELSE
BEGIN
	DELETE [dbo].[FactResellerSalesPart_Big]
	WHERE
		IDCol BETWEEN @IDCol and @IDCol + 100
END