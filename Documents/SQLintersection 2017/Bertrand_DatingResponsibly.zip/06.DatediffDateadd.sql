DECLARE @today date = getdate();

-- three (of many) ways to find first day of this month:
SELECT DATEADD(MONTH, DATEDIFF(MONTH, 0, @today), 0),
       DATEADD(DAY, 1 - DAY(@today), @today),
       DATEFROMPARTS(YEAR(@today), MONTH(@today), 1);

-- many people use the first in a WHERE clause, like:
SELECT ... 
WHERE col >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0);
GO

USE [master];
GO
DROP DATABASE IF EXISTS oldCompat;
GO
CREATE DATABASE oldCompat;
GO
ALTER DATABASE oldCompat SET COMPATIBILITY_LEVEL = 110;
GO
USE oldCompat;
GO

-- datediff
DROP TABLE IF EXISTS dbo.DateDiffTest;
GO
CREATE TABLE dbo.DateDiffTest
(
  CreateDate date
);
 
CREATE CLUSTERED INDEX x ON dbo.DateDiffTest(CreateDate);

-- let's insert 15,050 rows 
-- 15,000 from this date:
INSERT dbo.DateDiffTest(CreateDate) 
SELECT TOP (15000) DATEADD(MONTH, 
    DATEDIFF(MONTH, GETDATE(), 0), 0)
FROM sys.all_objects AS s1
CROSS JOIN sys.all_objects AS s2
UNION ALL
-- and 50 rows from this date:
SELECT TOP (50) DATEADD(MONTH, 
    DATEDIFF(MONTH, 0, GETDATE()), 0)
FROM sys.all_objects;

DBCC FREEPROCCACHE;

-- show execution plan
SELECT COUNT(*) FROM dbo.DateDiffTest
  WHERE CreateDate = DATEADD(MONTH, 
    DATEDIFF(MONTH, 0, GETDATE()), 0);

SELECT COUNT(*) FROM dbo.DateDiffTest
  WHERE CreateDate = DATEADD(MONTH, 
    DATEDIFF(MONTH, GETDATE(), 0), 0);
GO

-- dateadd
DROP TABLE IF EXISTS dbo.DateAddTest;
GO
CREATE TABLE dbo.DateAddTest 
(
  SessionId  int IDENTITY(1, 1) NOT NULL PRIMARY KEY,
  CreatedUtc datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
 
CREATE NONCLUSTERED INDEX [IX_User_Session_CreatedUtc]
ON dbo.DateAddTest(CreatedUtc) INCLUDE (SessionId);
GO
 
INSERT dbo.DateAddTest(CreatedUtc)
SELECT dt FROM 
(
  SELECT TOP (35000) dt = DATEADD(HOUR, 
    (s1.[precision]-ROW_NUMBER() OVER 
    (PARTITION BY s1.[object_id] ORDER BY s2.[object_id])) / 15, 
    GETUTCDATE())
  FROM sys.all_columns AS s1 
  CROSS JOIN sys.all_objects AS s2
) AS x;
 
UPDATE STATISTICS dbo.DateAddTest WITH FULLSCAN;
 
-- look at estimate - 1 row! Actual = 35000
SELECT DISTINCT SessionId FROM dbo.DateAddTest 
WHERE CreatedUtc >= DATEADD(DAY, -365, SYSUTCDATETIME());

-- change to GETUTCDATE(), problem solved:
SELECT DISTINCT SessionId FROM dbo.DateAddTest 
WHERE CreatedUtc >= DATEADD(DAY, -365, GETUTCDATE());

-- Can swap the predicate but this is not sargable:
SELECT DISTINCT SessionId FROM dbo.DateAddTest 
WHERE DATEDIFF(DAY, CreatedUtc, SYSUTCDATETIME()) <= 365;

