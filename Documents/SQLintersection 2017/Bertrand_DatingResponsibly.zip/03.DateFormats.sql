-- How many of these dates are in February?
-- SET LANGUAGE us_english;

SELECT CONVERT(datetime, '2017-02-09')
UNION ALL
SELECT CONVERT(datetime, '02/09/2017')
UNION ALL
SELECT CONVERT(datetime, '2017-02-09 12:34:56.789');










-- change lang and do it again:
SET LANGUAGE slovenski;



-- always safe:

SELECT CONVERT(datetime, '20170209')
UNION ALL
SELECT CONVERT(datetime, '2017-02-09T12:34:56.789')
UNION ALL
SELECT CONVERT(datetime, '20170209 12:34:56.789');

-- also always safe, but don't do it:
SELECT CONVERT(date, '2017-02-09');



-- how to test in all languages:
CREATE TABLE #t(lang sysname, m int);

DECLARE @sql nvarchar(max) = N'';

SELECT @sql += N'SET LANGUAGE ' + QUOTENAME(alias) + N';
INSERT #t(lang, m)
SELECT N''' + name + ' ' + QUOTENAME(alias) 
  + ''',MONTH(CONVERT(datetime,@d));'
FROM sys.syslanguages;
PRINT @sql;

EXEC sys.sp_executesql @sql, N'@d char(10)', '2017-02-09';

SELECT *, COUNT(*) OVER (PARTITION BY m)
FROM #t ORDER BY m, lang;
GO
DROP TABLE #t;