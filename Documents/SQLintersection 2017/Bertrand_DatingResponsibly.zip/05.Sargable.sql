USE WideWorldImporters;
GO

DROP TABLE IF EXISTS dbo.MyObjects;

SELECT TOP (25000) MDate = s1.modify_date 
INTO dbo.MyObjects
FROM sys.all_objects AS s1
  CROSS JOIN (SELECT TOP (10) object_id FROM sys.objects) AS s2
  ORDER BY s1.modify_date DESC;

CREATE INDEX d ON dbo.MyObjects(MDate);
GO


DECLARE @d date = '20171030';

-- scan or seek?
SELECT MDate FROM dbo.MyObjects WHERE 
  CONVERT(char(8), MDate, 112) = CONVERT(char(8), @d, 112)
  OPTION (RECOMPILE); 

-- scan or seek?
SELECT MDate FROM dbo.MyObjects WHERE 
  FORMAT(MDate, 'yyyyMMdd') = CONVERT(CHAR(8), @d, 112)
  OPTION (RECOMPILE);

-- scan or seek?
SELECT MDate FROM dbo.MyObjects WHERE 
  DATEDIFF(DAY, 0, MDate) = DATEDIFF(DAY, 0, @d)
  OPTION (RECOMPILE);

-- scan or seek?
SELECT MDate FROM dbo.MyObjects WHERE
  MDate >= @d AND MDate < DATEADD(DAY, 1, @d)
  OPTION (RECOMPILE); 

-- scan or seek?
SELECT MDate FROM dbo.MyObjects WHERE
  CONVERT(date, MDate) = @d;
