DROP TABLE IF EXISTS dbo.Policies_Typical, 
                     dbo.Policies_Optimized;
GO
CREATE TABLE dbo.Policies_Typical
(
  PolicyID int IDENTITY(1,1) PRIMARY KEY,
  /* ... */
  CreationDate   datetime NOT NULL,
  EffectiveStart datetime NOT NULL,
  EffectiveEnd   datetime NULL,
  LastClaim      datetime NULL,
  audit_Created  datetime NOT NULL 
                 DEFAULT SYSUTCDATETIME(),
  audit_Modified datetime NULL
);

CREATE INDEX ExpirationPending 
  ON dbo.Policies_Typical(EffectiveEnd, EffectiveStart);

CREATE INDEX RecentClaims
  ON dbo.Policies_Typical(LastClaim) INCLUDE(EffectiveEnd)
  WHERE LastClaim IS NOT NULL;

CREATE TABLE dbo.Policies_Optimized
(
  PolicyID int IDENTITY(1,1) PRIMARY KEY,
  /* ... */
  CreationDate   date NOT NULL,
  EffectiveStart date NOT NULL,
  EffectiveEnd   date NULL,
  LastClaim      date NULL,
  audit_Created  datetime NOT NULL 
                 DEFAULT SYSUTCDATETIME(),
  audit_Modified smalldatetime NULL
);

CREATE INDEX ExpirationPending 
  ON dbo.Policies_Optimized(EffectiveEnd, EffectiveStart);

CREATE INDEX RecentClaims
  ON dbo.Policies_Optimized(LastClaim) INCLUDE(EffectiveEnd)
  WHERE LastClaim IS NOT NULL;

INSERT dbo.Policies_Typical
(CreationDate,EffectiveStart,EffectiveEnd,LastClaim,
 audit_Created,audit_Modified)
SELECT s1.modify_date,s1.create_date,
  CASE WHEN s1.object_id % 7 = 0 THEN GETDATE() END,
  CASE WHEN s1.object_id % 9 = 0 THEN GETDATE() END,
  s1.create_date,s1.modify_date
FROM sys.all_objects AS s1 
CROSS JOIN 
(SELECT TOP (100) number FROM master.dbo.spt_values) AS x;

INSERT dbo.Policies_Optimized
(CreationDate,EffectiveStart,EffectiveEnd,LastClaim,
 audit_Created,audit_Modified)
 SELECT CreationDate,EffectiveStart,EffectiveEnd,LastClaim,
 audit_Created,audit_Modified
FROM dbo.Policies_Typical;

EXEC sys.sp_spaceused @objname = N'dbo.Policies_Typical';
EXEC sys.sp_spaceused @objname = N'dbo.Policies_Optimized';
GO
SELECT index_id,COUNT(*) FROM sys.dm_db_database_page_allocations
 (DB_ID(), OBJECT_ID(N'dbo.Policies_Typical'), 
 NULL, NULL, N'Limited') GROUP BY index_id;
SELECT index_id,COUNT(*) FROM sys.dm_db_database_page_allocations
 (DB_ID(), OBJECT_ID(N'dbo.Policies_Optimized'), 
 NULL, NULL, N'Limited') GROUP BY index_id;
GO

-- disk space is cheap, but this could be the
-- difference between (not) fitting into memory




-- FORMAT
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
DBCC FREEPROCCACHE WITH NO_INFOMSGS;
GO

SELECT [format]  = FORMAT(GETDATE(), 'yyyy-MM-dd'),
       [convert] = CONVERT(char(10), GETDATE(), 120);

DECLARE @x char(8);
SELECT @x = FORMAT(modify_date, 'yyyy-MM-dd') 
  FROM sys.all_objects;
GO 20
GO

DECLARE @x char(8);
SELECT @x = CONVERT(char(10), modify_date, 120) 
  FROM sys.all_objects;
GO 20

-- compare performance:
SELECT query = CASE WHEN t.[text] LIKE N'%FORMAT(%' 
   THEN 'Format' ELSE 'Convert' END, 
   qs.total_elapsed_time,
   qs.max_elapsed_time,
   qs.max_worker_time
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.plan_handle) AS t
WHERE t.[text] LIKE N'%@'+N'x = %';

