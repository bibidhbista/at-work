DROP TABLE IF EXISTS dbo.SalesOrders;
GO

CREATE TABLE dbo.SalesOrders
(
  OrderDate datetime2(3)
);
GO

INSERT dbo.SalesOrders(OrderDate) VALUES
  ('20170201 00:00'),
  ('20170201 01:00'),
  ('20170219 00:00'),
  ('20170228 04:00'),
  ('20170228 13:27:32.534'),
  ('20170228 23:59:59.998'),
  ('20170301 00:00');
GO

SELECT OrderDate 
  FROM dbo.SalesOrders
  ORDER BY OrderDate;
GO

-- parameters are datetime, using old millisecond tricks:
DECLARE 
  @start datetime = '20170201',
  @end   datetime = DATEADD(MILLISECOND, -3, '20170301');

SELECT OrderDate, @start, @end 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND @end;

  PRINT @start;
  PRINT @end;
GO

-- parameters change to smalldatetime:
DECLARE 
 @start smalldatetime = '20170201',
 @end   smalldatetime = DATEADD(MILLISECOND, -3, '20170301');

SELECT OrderDate, @start, @end 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND @end;

  PRINT @start;
  PRINT @end;
GO

-- parameters change to date:
DECLARE 
  @start date = '20170201',
  @end   date = DATEADD(MILLISECOND, -3, '20170301');

SELECT OrderDate, @start, @end 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND @end;

  PRINT @start;
  PRINT @end;
GO

-- how about EOMONTH()?
DECLARE 
  @start date = '20170201';

SELECT OrderDate, @start, EOMONTH(@start) 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND EOMONTH(@start);

  PRINT @start;
  PRINT @end;
GO

-- Stop using BETWEEN. Open-ended range is safer,
-- and far easier to calculate the "end" of a period
DECLARE 
  @start date = '20170201';

SELECT OrderDate, @start, DATEADD(MONTH, 1, @start)
  FROM dbo.SalesOrders
  WHERE OrderDate >= @start 
    AND OrderDate < DATEADD(MONTH, 1, @start);

  PRINT @start;
  PRINT @end;   -- open end
GO

DROP TABLE dbo.SalesOrders;
GO