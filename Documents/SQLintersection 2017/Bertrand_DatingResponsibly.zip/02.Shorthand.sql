USE tempdb;
SET NOCOUNT ON;
GO

/* Date/time shorthand QUIZ */

-- demo 1 :
DECLARE @d date = GETDATE();

SELECT             'DATEPART( Y )', DATEPART( Y , @d ) 
                    --   (a)  306   (b)  17   (c)  2017

UNION ALL SELECT   'DATEPART( M )', DATEPART( m , @d )    
                    --   (a)  11    (b)  This minute

UNION ALL SELECT   'DATEPART( W )', DATEPART( W , @d )   
                    --   (a)  43    (b)  44   (c)  5








-- demo 2 :

-- this works ok:
DECLARE @dt datetime = SYSDATETIME();
SELECT @dt + 1;
GO

-- these break:
DECLARE @d1 date      = SYSDATETIME(),
        @d2 datetime2 = SYSDATETIME();

SELECT @d1 + 1, @d2 - 1;
GO

-- always use explicit DATEADD