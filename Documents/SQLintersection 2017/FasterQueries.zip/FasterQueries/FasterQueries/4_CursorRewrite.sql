USE AdventureWorks2016
GO
DECLARE @ProductID INT, @ProductName NVARCHAR(50)

DECLARE @SalesDetail TABLE(SalesOrderID INT NOT NULL, ProductID INT NOT NULL, ProductName NVARCHAR(50) NOT NULL)

DECLARE MyCursorName  --create cursor
CURSOR FAST_FORWARD
FOR
	SELECT ProductID, Name   --cursor base SELECT statement
	FROM Production.Product 
	WHERE Name LIKE 'Mountain%'

OPEN MyCursorName
FETCH NEXT FROM MyCursorName
INTO @ProductID, @ProductName

WHILE @@FETCH_STATUS = 0
BEGIN
	INSERT INTO @SalesDetail(SalesOrderID, ProductID, ProductName)
	SELECT SalesOrderID, @ProductID, @ProductName 
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = @ProductID 
	
FETCH NEXT FROM MyCursorName
INTO @ProductID, @ProductName

END

CLOSE MyCursorName
DEALLOCATE MyCursorName

SELECT AccountNumber, ProductName, SUM(TotalDue) AS TotalDue, SUM(Freight) AS TotalFrieght
FROM @SalesDetail sd 
JOIN Sales.SalesOrderHeader h ON sd.SalesOrderID = h.SalesOrderID 
GROUP BY AccountNumber, ProductName 
-----------------------------------------------------------------------------------
SELECT h.AccountNumber, p.Name, SUM(TotalDue) AS TotalDue, SUM(Freight) AS TotalFrieght
FROM 
	Sales.SalesOrderDetail sd 
	JOIN Sales.SalesOrderHeader h ON sd.SalesOrderID = h.SalesOrderID 
	JOIN Production.Product p ON sd.ProductID = p.ProductID 
WHERE p.Name LIKE 'Mountain%'
GROUP BY h.AccountNumber, p.Name

