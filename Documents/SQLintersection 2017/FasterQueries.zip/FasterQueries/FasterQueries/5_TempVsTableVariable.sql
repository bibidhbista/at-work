USE AdventureWorks2016
GO
--table variables always created in tempdb
SELECT * FROM sys.dm_os_performance_counters
WHERE counter_name = 'Active Temp Tables'
GO
DECLARE @TableVariable TABLE(Field1 INT)
INSERT INTO @TableVariable SELECT 1

SELECT * FROM sys.dm_db_task_space_usage
WHERE session_id = @@SPID

SELECT * FROM sys.dm_os_performance_counters
WHERE counter_name = 'Active Temp Tables'

--------------------------------------------------------------------------------------
DBCC FREEPROCCACHE  --clear out plan cache
DBCC DROPCLEANBUFFERS  --send clean buffers out of pool
GO
--create a table variable
DECLARE @Carriers TABLE
(
	CarrierTrackingNumber NVARCHAR(25) PRIMARY KEY CLUSTERED
)
INSERT INTO @Carriers (CarrierTrackingNumber)
SELECT DISTINCT TOP 1000 CarrierTrackingNumber
FROM Sales.SalesOrderDetail 
WHERE CarrierTrackingNumber IS NOT NULL

SELECT d.CarrierTrackingNumber 
FROM Sales.SalesOrderDetail d
JOIN @Carriers c ON d.CarrierTrackingNumber = c.CarrierTrackingNumber 
WHERE d.ProductID = 776
--------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb..#Carriers') IS NOT NULL
DROP TABLE #Carriers
GO
CREATE TABLE #Carriers(CarrierTrackingNumber NVARCHAR(25) PRIMARY KEY CLUSTERED)

INSERT INTO #Carriers(CarrierTrackingNumber)
SELECT DISTINCT TOP 1000 CarrierTrackingNumber
FROM Sales.SalesOrderDetail 
WHERE CarrierTrackingNumber IS NOT NULL

SELECT d.CarrierTrackingNumber 
FROM Sales.SalesOrderDetail d
JOIN #Carriers c ON d.CarrierTrackingNumber = c.CarrierTrackingNumber 
WHERE d.ProductID = 776

GO

SELECT * FROM sys.dm_db_task_space_usage
WHERE session_id = @@SPID

SELECT * FROM sys.dm_os_performance_counters
WHERE counter_name = 'Active Temp Tables'

;WITH Carriers
AS
(
SELECT DISTINCT TOP 1000 CarrierTrackingNumber
FROM Sales.SalesOrderDetail 
WHERE CarrierTrackingNumber IS NOT NULL
)
SELECT d.CarrierTrackingNumber 
FROM Sales.SalesOrderDetail d
JOIN Carriers c ON d.CarrierTrackingNumber = c.CarrierTrackingNumber 
WHERE d.ProductID = 776

SELECT * FROM sys.dm_db_task_space_usage
WHERE session_id = @@SPID

SELECT * FROM sys.dm_os_performance_counters
WHERE counter_name = 'Active Temp Tables'


















--------------------------------------------------------------------------------------
--DECLARE @Carriers TABLE
--(
--	CarrierTrackingNumber NVARCHAR(25) PRIMARY KEY CLUSTERED
--)
--INSERT INTO @Carriers (CarrierTrackingNumber)
--SELECT DISTINCT TOP 1000 CarrierTrackingNumber
--FROM Sales.SalesOrderDetail 
--WHERE CarrierTrackingNumber IS NOT NULL

--SELECT d.CarrierTrackingNumber 
--FROM Sales.SalesOrderDetail d
--JOIN @Carriers c ON d.CarrierTrackingNumber = c.CarrierTrackingNumber 
--WHERE d.ProductID = 776
--OPTION(RECOMPILE)


--------------------------------------------------------------------------------------
--Table variables created in TempDB too...
