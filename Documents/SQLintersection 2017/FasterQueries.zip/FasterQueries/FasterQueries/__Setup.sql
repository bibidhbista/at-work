USE AdventureWorks2016
GO
IF INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'), 'IX_SalesOrderDetail_CarrierTrackingNumber', 'IndexID') IS NOT NULL
DROP INDEX IX_SalesOrderDetail_CarrierTrackingNumber ON Sales.SalesOrderDetail
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_CarrierTrackingNumber 
ON Sales.SalesOrderDetail(CarrierTrackingNumber)
GO
IF INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'), 'IX_SalesOrderDetail_ProductID', 'IndexID') IS NOT NULL
DROP INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_ProductID 
ON Sales.SalesOrderDetail(ProductID)
GO
IF INDEXPROPERTY(OBJECT_ID('Sales.Customer'), 'AK_Customer_AccountNumber', 'IndexID') IS NOT NULL
DROP INDEX AK_Customer_AccountNumber ON Sales.Customer
GO
CREATE NONCLUSTERED INDEX AK_Customer_AccountNumber 
ON Sales.Customer(AccountNumber)
GO
IF INDEXPROPERTY(OBJECT_ID('Production.Product'), 'AK_Product_Name', 'IndexID') IS NOT NULL
DROP INDEX AK_Product_Name ON Production.Product
GO
CREATE NONCLUSTERED INDEX AK_Product_Name 
ON Production.Product(Name)
GO
IF INDEXPROPERTY(OBJECT_ID('Sales.Customer'), 'IX_Customer_ModifiedDate', 'IndexID') IS NOT NULL
DROP INDEX IX_Customer_ModifiedDate ON Sales.Customer
GO
CREATE NONCLUSTERED INDEX IX_Customer_ModifiedDate 
ON Sales.Customer(ModifiedDate)

