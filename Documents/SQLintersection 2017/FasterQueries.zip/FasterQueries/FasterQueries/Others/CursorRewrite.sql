USE AdventureWorks
GO
DECLARE @ServerName SYSNAME

DECLARE ServerCursor 
CURSOR FAST_FORWARD
FOR
SELECT idcol
FROM CursorTest

OPEN ServerCursor
FETCH NEXT FROM ServerCursor
INTO @Variable1

WHILE @@FETCH_STATUS = 0

BEGIN

FETCH NEXT FROM ServerCursor
INTO @Variable1

END

CLOSE ServerCursor
DEALLOCATE ServerCursor