USE AdventureWorks
GO

SELECT EmailAddress, RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM Person.Contact
WHERE EmailAddress =  'dalton90@adventure-works.com'
GO
----------------------------------------------------------------------
WITH CTE
AS
(
SELECT EmailAddress, RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM Person.Contact
) 
SELECT EmailAddress, RowNo 
FROM CTE
WHERE EmailAddress =  'dalton90@adventure-works.com'
GO
----------------------------------------------------------------------
WITH CTE
AS
(
SELECT EmailAddress, RowCnt = COUNT(*) 
FROM Person.Contact
GROUP BY EmailAddress 
) 
SELECT EmailAddress, RowCnt 
FROM CTE
WHERE EmailAddress =  'dalton90@adventure-works.com'
----------------------------------------------------------------------
WITH CTE
AS
(
SELECT EmailAddress, RowCnt = COUNT(*), RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM Person.Contact
GROUP BY EmailAddress 
) 
SELECT EmailAddress, RowCnt, RowNo
FROM CTE
WHERE EmailAddress =  'dalton90@adventure-works.com'
----------------------------------------------------------------------
WITH CTE
AS
(
SELECT EmailAddress, RowCnt = COUNT(*), RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM Person.Contact
GROUP BY EmailAddress 
) 
SELECT EmailAddress, RowCnt, RowNo
FROM CTE
WHERE EmailAddress =  'dalton90@adventure-works.com'
----------------------------------------------------------------------
IF OBJECT_ID('Person.People') IS NOT NULL
DROP VIEW Person.People
GO
CREATE VIEW Person.People
AS
SELECT EmailAddress, RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM Person.Contact
GO
SELECT EmailAddress, RowNo 
FROM Person.People
WHERE EmailAddress =  'dalton90@adventure-works.com'
----------------------------------------------------------------------
IF OBJECT_ID('Person.People') IS NOT NULL
DROP VIEW Person.People
GO
CREATE VIEW Person.People
AS
SELECT EmailAddress, RowCnt = COUNT(*), RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM Person.Contact
GROUP BY EmailAddress 
GO
SELECT EmailAddress, RowCnt, RowNo
FROM Person.People
WHERE EmailAddress =  'dalton90@adventure-works.com'
----------------------------------------------------------------------
WITH CTE
AS
(
SELECT EmailAddress 
FROM Person.Contact
) 
SELECT EmailAddress, RowNo = ROW_NUMBER() OVER(ORDER BY emailaddress)  
FROM CTE
WHERE EmailAddress =  'dalton90@adventure-works.com'
GO
----------------------------------------------------------------------
IF OBJECT_ID('Person.GetEmails') IS NOT NULL
DROP FUNCTION Person.GetEmails
GO
CREATE FUNCTION Person.GetEmails
(
@EmailAddress NVARCHAR(50)
)
RETURNS TABLE
AS RETURN(
SELECT EmailAddress, RowNo = ROW_NUMBER() OVER(ORDER BY EmailAddress)  
FROM Person.Contact
WHERE EmailAddress = @EmailAddress 
)
GO
SELECT *
FROM Person.GetEmails('dalton90@adventure-works.com')
GO
----------------------------------------------------------------------
IF INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderHeader'), 'IX_SalesOrderHeader_ContactID', 'IndexID') IS NOT NULL
DROP INDEX IX_SalesOrderHeader_ContactID ON Sales.SalesOrderHeader
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderHeader_ContactID ON Sales.SalesOrderHeader(ContactID)
GO
----------------------------------------------------------------------
IF OBJECT_ID('Person.EmailCounts') IS NOT NULL
DROP VIEW Person.EmailCounts
GO
CREATE VIEW Person.EmailCounts
AS
SELECT c.ContactID, c.EmailAddress, RowCnt = COUNT(*)
FROM Person.Contact c 
GROUP BY c.ContactID, c.EmailAddress
Go

SELECT *
FROM Person.EmailCounts
WHERE EmailAddress = 'dalton90@adventure-works.com'
----------------------------------------------------------------------
IF OBJECT_ID('Person.EmailCounts') IS NOT NULL
DROP VIEW Person.EmailCounts
GO
CREATE VIEW Person.EmailCounts
AS
SELECT c.ContactID, c.EmailAddress, RowCnt = COUNT(*)
FROM Person.Contact c 
JOIN Sales.SalesOrderHeader h ON c.ContactID = h.ContactID 
GROUP BY c.ContactID, c.EmailAddress
HAVING COUNT(EmailAddress) > 2
Go
SELECT *
FROM Person.EmailCounts 
WHERE ContactID = 6341
GO
----------------------------------------------------------------------
SELECT c.ContactID, c.EmailAddress, RowCnt = COUNT(*)
FROM Person.Contact c 
JOIN Sales.SalesOrderHeader h ON c.ContactID = h.ContactID 
WHERE c.ContactID = 6341
GROUP BY c.ContactID, c.EmailAddress
HAVING COUNT(EmailAddress) > 2
----------------------------------------------------------------------
----no pushing on this join
--SELECT *
--FROM Person.EmailCounts e
--JOIN Sales.StoreContact s on e.ContactID = s.ContactID 
--WHERE EmailAddress = 'aaron0@adventure-works.com'
----------------------------------------------------------------------

IF OBJECT_ID('Person.EmailCounts') IS NOT NULL
DROP VIEW Person.EmailCounts
GO
CREATE VIEW Person.EmailCounts
AS
SELECT c.ContactID, c.EmailAddress, RowCnt = COUNT(*), RowNo = ROW_NUMBER() OVER(ORDER BY NEWID())
FROM Person.Contact c 
JOIN Sales.SalesOrderHeader h ON c.ContactID = h.ContactID 
GROUP BY c.ContactID, c.EmailAddress
HAVING COUNT(EmailAddress) > 2
Go

SELECT *
FROM Person.EmailCounts 
WHERE ContactID = 6341
GO
----------------------------------------------------------------------
IF OBJECT_ID('Person.EmailCounts') IS NOT NULL
DROP VIEW Person.EmailCounts
GO
CREATE VIEW Person.EmailCounts
AS
SELECT c.ContactID, c.EmailAddress, RowCnt = COUNT(*),MaxSalesOrderNo = MAX(SalesOrderNumber) 
FROM Person.Contact c 
JOIN Sales.SalesOrderHeader h ON c.ContactID = h.ContactID 
GROUP BY c.ContactID, c.EmailAddress
HAVING COUNT(EmailAddress) > 2
Go
SELECT *
FROM Person.EmailCounts
WHERE EmailAddress = 'aaron0@adventure-works.com'
----------------------------------------------------------------------



