USE AdventureWorks
GO
--UPDATE c
--SET ModifiedDate = DATEADD(HOUR, CustomerID, ModifiedDate)
--from Sales.Customer c

UPDATE TOP(15) c
SET ModifiedDate = CAST('2/23/2007 11:25:00' AS DATETIME)
FROM Sales.Customer c
WHERE YEAR(modifieddate) = 2004

IF INDEXPROPERTY(OBJECT_ID('Sales.Customer'),'IX_Customer_ModifiedDate','IndexID') IS NOT NULL
DROP INDEX IX_Customer_ModifiedDate ON Sales.Customer
GO
CREATE NONCLUSTERED INDEX IX_Customer_ModifiedDate ON Sales.Customer(ModifiedDate ASC)
----------------------------------------------------------------------------------------
UPDATE TOP(1) c
SET ModifiedDate = CAST('2/24/2007' AS DATETIME)
FROM Sales.Customer c
WHERE YEAR(modifieddate) = 2004
----------------------------------------------------------------------------------------
--extra record.
SELECT ModifiedDate
FROM Sales.Customer c
WHERE ModifiedDate BETWEEN '2/23/2007' AND CAST('2/23/2007' AS DATETIME) + 1
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE CONVERT(VARCHAR(10), ModifiedDate, 101) BETWEEN '2/23/2007' AND '2/23/2007' 
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE CAST(ModifiedDate AS DATE)= CAST('2/23/2007' AS DATE)
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE ModifiedDate >= '2/23/2007' AND
	ModifiedDate < DATEADD(DAY, 1, '2/23/2007')
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE YEAR(ModifiedDate) = 2007
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE ModifiedDate BETWEEN '1/1/2007' AND '12/31/2007 23:59:59'


SELECT ModifiedDate
FROM Sales.Customer c
WHERE ModifiedDate >= '1/1/2007' AND ModifiedDate < '1/1/2008'
----------------------------------------------------------------------------------------
IF INDEXPROPERTY(OBJECT_ID('Person.Contact'),'IX_Contact_LastName','IndexID') IS NOT NULL
DROP INDEX IX_Contact_LastName ON Person.Contact
GO
CREATE NONCLUSTERED INDEX IX_Contact_LastName ON Person.Contact(LastName ASC)

SELECT LastName FROM Person.Contact
WHERE LastName =  'Chapman'

SELECT LastName FROM Person.Contact
WHERE LastName LIKE '%man'

----------------------------------------------------------------------------------------

