USE AdventureWorks
GO
IF OBJECT_ID('tempdb..#CarrierNumbers') IS NOT NULL
DROP TABLE #CarrierNumbers
GO
CREATE TABLE #CarrierNumbers(CarrierTrackingNumber NVARCHAR(25) NULL)
GO
INSERT INTO #CarrierNumbers (CarrierTrackingNumber)
SELECT DISTINCT TOP 1000 CarrierTrackingNumber
FROM Sales.SalesOrderDetail 
UNION ALL
SELECT NULL

CREATE NONCLUSTERED INDEX IX_#CarrierNumbers_CarrierTrackingNumber 
ON #CarrierNumbers(CarrierTrackingNumber)
GO

SELECT * FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber NOT IN(SELECT CarrierTrackingNumber FROM #CarrierNumbers)
GO
SET ANSI_NULLS ON

SELECT * FROM Sales.SalesOrderDetail d
WHERE NOT EXISTS(SELECT 1 FROM #CarrierNumbers c 
WHERE c.CarrierTrackingNumber = d.CarrierTrackingNumber)

SELECT * 
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber NOT IN(SELECT CarrierTrackingNumber FROM #CarrierNumbers WHERE CarrierTrackingNumber IS NOT NULL)
OR CarrierTrackingNumber IS NULL

