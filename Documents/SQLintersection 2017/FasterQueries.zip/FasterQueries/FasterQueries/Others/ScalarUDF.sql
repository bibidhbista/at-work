USE AdventureWorks
GO
CREATE FUNCTION dbo.udf_GetPayHistory
(
    @EmployeeID INT,
    @RateChangeDate DATETIME
)
RETURNS MONEY
AS
BEGIN
    DECLARE @PayHistory MONEY

    SET @PayHistory =
    (
        SELECT    SUM(Rate)
        FROM HumanResources.EmployeePayHistory eh
        WHERE
            eh.EmployeeID = @EmployeeID AND
            eh.RateChangeDate >= @RateChangeDate
    )
    RETURN(@PayHistory)
END  
GO
SET STATISTICS IO ON

SELECT
    EmployeeID,
    LoginID,
    dbo.udf_GetPayHistory(e.EmployeeID,'1/1/1997')
FROM
    HumanResources.Employee e
WHERE
    EmployeeID BETWEEN 100 AND 200  

GO
DECLARE @RateChangeDate DATETIME
SET @RateChangeDate = '1/1/1997'

SELECT
    EmployeeID,
    LoginID,
    PayHistory =
    (
        SELECT    SUM(Rate)
        FROM HumanResources.EmployeePayHistory eh
        WHERE
            e.EmployeeID = eh.EmployeeID AND
            eh.RateChangeDate >= @RateChangeDate
    )
FROM HumanResources.Employee e
WHERE EmployeeID BETWEEN 100 AND 200  
    