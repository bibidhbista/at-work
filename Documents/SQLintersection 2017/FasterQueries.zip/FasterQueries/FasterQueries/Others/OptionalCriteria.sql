USE AdventureWorks
GO
--Remove all cached plans from memory
DBCC FREEPROCCACHE
GO
--------------------------------------------------------------------------------
--Use OR statements to set criteria for our parameters
IF OBJECT_ID('dbo.usp_SearchSalesOrderDetail_ORStatements') IS NOT NULL
DROP PROCEDURE usp_SearchSalesOrderDetail_ORStatements
GO
CREATE PROCEDURE dbo.usp_SearchSalesOrderDetail_ORStatements
(
@rowguid UNIQUEIDENTIFIER = NULL,
@ProductID INT = NULL,
@SalesOrderID INT = NULL
)
AS
BEGIN
	SELECT *
	FROM Sales.SalesOrderDetail 
	WHERE 
	(rowguid = @rowguid OR @rowguid IS NULL) AND
	(ProductID = @ProductID OR @ProductID IS NULL) AND
	(SalesOrderID = @SalesOrderID OR @SalesOrderID IS NULL)
END
GO
--------------------------------------------------------------------------------
--Use ISNULL statements to set criteria for our parameters
IF OBJECT_ID('dbo.usp_SearchSalesOrderDetail_ISNULLStatements') IS NOT NULL
DROP PROCEDURE usp_SearchSalesOrderDetail_ISNULLStatements
GO
CREATE PROCEDURE dbo.usp_SearchSalesOrderDetail_ISNULLStatements
(
@rowguid UNIQUEIDENTIFIER = NULL,
@ProductID INT = NULL,
@SalesOrderID INT = NULL
)
AS
BEGIN

SELECT *
FROM Sales.SalesOrderDetail 
WHERE 
	--if the input parameter is NULL, set the field back to itself
	rowguid = ISNULL(@rowguid, rowguid) AND
	ProductID = ISNULL(@ProductID, ProductID) AND
	SalesOrderID = ISNULL(@SalesOrderID, SalesOrderID)
END
GO
--------------------------------------------------------------------------------
IF OBJECT_ID('dbo.usp_SearchSalesOrderDetail_DynamicSQL') IS NOT NULL
DROP PROCEDURE usp_SearchSalesOrderDetail_DynamicSQL
GO
CREATE PROCEDURE dbo.usp_SearchSalesOrderDetail_DynamicSQL
(
@rowguid UNIQUEIDENTIFIER = NULL,
@ProductID INT = NULL,
@SalesOrderID INT = NULL
)
AS
BEGIN
DECLARE @SQL NVARCHAR(2000)
SET @SQL = N'SELECT *
FROM Sales.SalesOrderDetail WHERE 1 = 1 ' --little trick; we don't know if we have additional criteria
SET @SQL = @SQL + CASE WHEN @rowguid IS NOT NULL THEN ' AND rowguid = ' + CAST(@rowguid AS NVARCHAR(40)) ELSE '' END
SET @SQL = @SQL + CASE WHEN @ProductID IS NOT NULL THEN ' AND ProductID = ' + CAST(@ProductID AS NVARCHAR(10)) ELSE '' END
SET @SQL = @SQL + CASE WHEN @SalesOrderID IS NOT NULL THEN ' AND SalesOrderID = ' + CAST(@SalesOrderID AS NVARCHAR(10)) ELSE '' END
PRINT @SQL

EXECUTE (@SQL)
END
GO

--------------------------------------------------------------------------------
--Construct the SQL string based on parameter values existing
DECLARE @SalesOrderID INT, @ProductID INT
SELECT @SalesOrderID = 57149, @ProductID = 715

EXECUTE dbo.usp_SearchSalesOrderDetail_ORStatements 
@SalesOrderID = @SalesOrderID, @ProductID = @ProductID

EXECUTE dbo.usp_SearchSalesOrderDetail_COALESCEStatements 
@SalesOrderID = @SalesOrderID, @ProductID = @ProductID

EXECUTE dbo.usp_SearchSalesOrderDetail_DynamicSQL 
@SalesOrderID = @SalesOrderID, @ProductID = @ProductID
