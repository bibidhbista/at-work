USE AdventureWorks
GO
SET STATISTICS IO ON
GO
WITH Pager
AS
(
	SELECT RowNumber = ROW_NUMBER() OVER(ORDER BY SalesOrderID ASC) 
	FROM Sales.SalesOrderDetail
)
SELECT * FROM Pager
WHERE RowNumber BETWEEN 1 AND 1000
GO
------------------------------------------------------------------------------
WITH Pager
AS
(
	SELECT RowNumber = ROW_NUMBER() OVER(ORDER BY SalesOrderID ASC) 
	FROM Sales.SalesOrderDetail
)
SELECT * FROM Pager
WHERE RowNumber BETWEEN 100000 AND 101000