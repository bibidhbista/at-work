USE AdventureWorks
GO
IF INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'),'IX_SalesOrderDetail_CarrierTrackingNumber','IndexID') IS NOT NULL
DROP INDEX IX_SalesOrderDetail_CarrierTrackingNumber ON Sales.SalesOrderDetail
GO
CREATE INDEX IX_SalesOrderDetail_CarrierTrackingNumber ON Sales.SalesOrderDetail(CarrierTrackingNumber)
GO
----------------------------------------------------------------------------------------------------------------
SELECT COUNT(*)
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber = '0097-43FD-B7' OR CarrierTrackingNumber IS NULL

SELECT COUNT(*)
FROM Sales.SalesOrderDetail
WHERE ISNULL(CarrierTrackingNumber, '0097-43FD-B7') = '0097-43FD-B7' 

SELECT COUNT(*)
FROM Sales.SalesOrderDetail
WHERE 
	CASE 
		WHEN CarrierTrackingNumber = '0097-43FD-B7' THEN 1
		WHEN CarrierTrackingNumber IS NULL THEN 1 
		ELSE 0 
	END = 1
GO
----------------------------------------------------------------------------------------------------------------
SET ANSI_NULLS OFF

SELECT COUNT(*)
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber IN('0097-43FD-B7', NULL )
GO
SET ANSI_NULLS ON