USE AdventureWorks
go
--SEEK ON AN NVARCHAR COLUMN WITH A VARCHAR PARAM
SELECT Name   --NVARCHAR(50)
FROM production.product 
WHERE Name = CAST('HL Crankarm' AS VARCHAR(50))
GO
---------------------------------------------------------------
--SCAN ON A VARCHAR column with nvarchar variable.
SELECT AccountNumber --varchar(10) column
FROM Sales.Customer
WHERE AccountNumber = CAST(N'AW00020720' AS NVARCHAR(10))

--data type precedence.  nvarchar is higher precedence than the varchar column, so a 
--seek is possible.
