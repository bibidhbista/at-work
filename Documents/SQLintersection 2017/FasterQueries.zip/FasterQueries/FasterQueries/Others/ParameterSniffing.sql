USE AdventureWorks
GO

DBCC FREEPROCCACHE

IF INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'), 'IX_SalesOrderDetail_CarrierTrackingNumber', 'IndexID') IS NOT NULL
DROP INDEX IX_SalesOrderDetail_CarrierTrackingNumber ON Sales.SalesOrderDetail
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_CarrierTrackingNumber 
ON Sales.SalesOrderDetail(CarrierTrackingNumber)
GO
IF INDEXPROPERTY(OBJECT_ID('Sales.SalesOrderDetail'), 'IX_SalesOrderDetail_ProductID', 'IndexID') IS NOT NULL
DROP INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail
GO
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_ProductID 
ON Sales.SalesOrderDetail(ProductID)
GO
----------------------------------------------------------------------
--explicit value supplied to predicate
SELECT *
FROM Sales.SalesOrderDetail
WHERE ProductID = 897
GO
----------------------------------------------------------------------
SELECT *
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber = N'A643-4938-95'
----------------------------------------------------------------------
--use local variables rather than explicit values
DECLARE @ProductID INT
SET @ProductID = 897

SELECT *
FROM Sales.SalesOrderDetail
WHERE ProductID = @ProductID
GO
----------------------------------------------------------------------
DECLARE @CarrierTrackingNumber NVARCHAR(25)
SET @CarrierTrackingNumber = N'A643-4938-95'

SELECT *
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber = @CarrierTrackingNumber
----------------------------------------------------------------------
SELECT 
	DistinctProductCount = COUNT(DISTINCT ProductID), 
	DistinctCarrierCount = COUNT(DISTINCT CarrierTrackingNumber), 
	TotalCount = COUNT(*), 
	ProductDensity = 1.000/COUNT(DISTINCT ProductID),
	CarrierDensity = 1.000/COUNT(DISTINCT CarrierTrackingNumber)
FROM Sales.SalesOrderDetail

----------------------------------------------------------------------
--use a stored procedure with parameters in place of 
--using local variables
IF OBJECT_ID('Sales.usp_GetSalesOrders') IS NOT NULL
DROP PROCEDURE Sales.usp_GetSalesOrders
GO
CREATE PROCEDURE Sales.usp_GetSalesOrders
(
	@ProductID INT
)
AS
BEGIN
	SELECT *
	FROM Sales.SalesOrderDetail
	WHERE ProductID = @ProductID
END
GO
EXECUTE Sales.usp_GetSalesOrders 
@ProductID = 897
GO
----------------------------------------------------------------------
--peform a key lookup of the ProductID.  Store this value in a 
--local variable.  Use the local variable as criteria.
IF OBJECT_ID('dbo.usp_GetSalesOrders') IS NOT NULL
DROP PROCEDURE usp_GetSalesOrders
GO
CREATE PROCEDURE usp_GetSalesOrders
(
@ProductNumber NVARCHAR(50)
)
AS
BEGIN
	DECLARE @ProductID INT
	SET @ProductID = 
	(
		SELECT ProductID
		FROM Production.Product
		WHERE ProductNumber = @ProductNumber
	)
	
	SELECT *
	FROM Sales.SalesOrderDetail
	WHERE ProductID = @ProductID
END
GO

EXECUTE usp_GetSalesOrders 
@ProductNumber = 'FR-T67U-58'
GO
----------------------------------------------------------------------
--Use a local variable and pass in as a parameter to sp_executesql.
BEGIN
	DECLARE @SQL NVARCHAR(500), @ProductID INT, @Parameters NVARCHAR(1000)
	SET @Parameters = N'@ProductID INT'
	SET @ProductID = 897

	SET @SQL = N'SELECT * 
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = @ProductID'

	EXECUTE sp_executesql 
	@stmt = @SQL, 
	@params = @Parameters,
	@ProductID = @ProductID
END




