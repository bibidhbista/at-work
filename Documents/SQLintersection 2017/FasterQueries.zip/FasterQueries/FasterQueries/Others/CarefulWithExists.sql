USE AdventureWorks
GO
SET NOCOUNT ON
GO

