USE AdventureWorks
GO
SELECT 
	soh.SalesOrderID, 
	Quantity =	(
				SELECT SUM(OrderQty)
				FROM Sales.SalesOrderDetail sd1
				WHERE sd1.SalesOrderID = soh.SalesOrderID
				),
	UnitPrice =	(
				SELECT SUM(UnitPrice)
				FROM Sales.SalesOrderDetail sd2
				WHERE sd2.SalesOrderID = soh.SalesOrderID
				)
FROM Sales.SalesOrderHeader soh
GO
--------------------------------------------------------------------
SELECT soh.SalesOrderID, soh.OrderDate, A.*
FROM Sales.SalesOrderHeader soh
CROSS APPLY 
(
   SELECT SUM(sod.UnitPrice) AS UnitPrice, SUM(sod.OrderQty) AS Quantity
   FROM Sales.SalesOrderDetail sod
   WHERE sod.SalesOrderId = soh.SalesOrderId
) A
--------------------------------------------------------------------
DROP FUNCTION SalesFunction
GO
CREATE FUNCTION SalesFunction(@SalesOrderID INT)
RETURNS TABLE
AS RETURN
(
   SELECT SUM(sod.UnitPrice) AS UnitPrice, SUM(sod.OrderQty) AS Quantity
   FROM Sales.SalesOrderDetail sod
   WHERE sod.SalesOrderId = @SalesOrderID
)
GO
SELECT soh.SalesOrderID, soh.OrderDate, a.*
FROM Sales.SalesOrderHeader soh
CROSS APPLY SalesFunction(soh.SalesOrderID) a 
--------------------------------------------------------------------
SELECT soh.SalesOrderID, soh.OrderDate, a.*
FROM Sales.SalesOrderHeader soh
JOIN (
   SELECT SalesOrderId, SUM(sod.UnitPrice) AS UnitPrice, SUM(sod.OrderQty) AS Quantity
   FROM Sales.SalesOrderDetail sod
   GROUP BY SalesOrderID
) a ON soh.SalesOrderID = a.SalesOrderID 
--------------------------------------------------------------------
SELECT soh.SalesOrderID, soh.OrderDate, SUM(sod.UnitPrice) AS UnitPrice, SUM(sod.OrderQty) AS Quantity
FROM Sales.SalesOrderHeader soh
JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID 
GROUP BY soh.SalesOrderID, soh.OrderDate
