select EmailAddress, ROW_NUMBER() over(order by emailaddress)  
from Person.Contact
where EmailAddress =  'dalton90@adventure-works.com'

create view personview
as
select EmailAddress, RowNo = ROW_NUMBER() over(order by emailaddress)  
from Person.Contact

ALTER view personview
as
select *
from Person.Contact c join Sales.Individual i on c.ContactID = i.ContactID 


create index idx_Individual_contactID on Sales.Individual(ContactID)




select *
from personview 
where EmailAddress =  'dalton90@adventure-works.com'


ALTER view personview
as
select c.ContactID, c.EmailAddress, COUNT(*) as RowCounter
from Person.Contact c join Sales.SalesOrderHeader i on c.ContactID = i.ContactID 
group by c.ContactID, c.EmailAddress 


select *
from personview 
where EmailAddress =  'dalton90@adventure-works.com'

sp_helpindex 'sales.salesorderheader'

select * from INFORMATION_SCHEMA.COLUMNS where COLUMN_NAME =  'contactid'
ALTER view personview
as
select i.ContactID, c.EmailAddress, COUNT(*) as RowCounter
from Person.Contact c join Sales.SalesOrderHeader  i on c.ContactID = i.ContactID 
group by i.ContactID, c.EmailAddress 
having COUNT(*) > 1

select * from Sales.Customer

select * from (
select EmailAddress, RowNo = ROW_NUMBER() over(order by emailaddress)  
from Person.Contact
) a where EmailAddress =  'dalton90@adventure-works.com'

select * from (
select EmailAddress, RowNo = ROW_NUMBER() over(order by newid())  
from Person.Contact
) a where EmailAddress =  'dalton90@adventure-works.com'

select * from (
select EmailAddress
from Person.Contact
group by EmailAddress 
) a 
where EmailAddress =  'dalton90@adventure-works.com'

select * from (
select EmailAddress
from Person.Contact
group by EmailAddress 
) a 
where EmailAddress =  'dalton90@adventure-works.com'

update Person.Contact
set EmailAddress = LTRIM(rtrim(emailaddress)) + ' '
where EmailAddress = 'jackson32@adventure-works.com'

select * from (
select EmailAddress
from Person.Contact
group by EmailAddress 
) a 
where EmailAddress =  'jackson32@adventure-works.com'

select * from (
select EmailAddress
from Person.Contact
group by EmailAddress 
) a 
where EmailAddress LIKE 'jackson32@adventure-works.com'