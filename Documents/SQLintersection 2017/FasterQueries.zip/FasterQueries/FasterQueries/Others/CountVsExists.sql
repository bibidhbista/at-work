USE AdventureWorks
GO
IF EXISTS
(
	SELECT 1
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 870
)
PRINT 'Exists = True'

IF 
(
	SELECT COUNT(*) 
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 870
) >0
PRINT 'Exists = True'
