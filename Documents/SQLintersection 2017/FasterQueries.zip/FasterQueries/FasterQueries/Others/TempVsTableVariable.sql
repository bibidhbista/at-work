USE AdventureWorks
GO
DECLARE @Carriers TABLE
(
	CarrierTrackingNumber NVARCHAR(25) PRIMARY KEY CLUSTERED
)
INSERT INTO @Carriers (CarrierTrackingNumber)
SELECT DISTINCT TOP 1000 CarrierTrackingNumber
FROM Sales.SalesOrderDetail 
WHERE CarrierTrackingNumber IS NOT NULL

SELECT d.CarrierTrackingNumber 
FROM Sales.SalesOrderDetail d
JOIN @Carriers c ON d.CarrierTrackingNumber = c.CarrierTrackingNumber 
WHERE d.ProductID = 776
--------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb..#Carriers') IS NOT NULL
DROP TABLE #Carriers
GO
CREATE TABLE #Carriers(CarrierTrackingNumber NVARCHAR(25) PRIMARY KEY CLUSTERED)

INSERT INTO #Carriers(CarrierTrackingNumber)
SELECT DISTINCT TOP 1000 CarrierTrackingNumber
FROM Sales.SalesOrderDetail 
WHERE CarrierTrackingNumber IS NOT NULL

SELECT d.CarrierTrackingNumber 
FROM Sales.SalesOrderDetail d
JOIN #Carriers c ON d.CarrierTrackingNumber = c.CarrierTrackingNumber 
WHERE d.ProductID = 776
