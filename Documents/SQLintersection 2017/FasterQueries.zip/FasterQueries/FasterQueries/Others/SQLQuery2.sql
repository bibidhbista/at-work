USE AdventureWorks
GO
CREATE VIEW Sales.SalesView
AS
SELECT * FROM Sales.SalesOrderDetail
