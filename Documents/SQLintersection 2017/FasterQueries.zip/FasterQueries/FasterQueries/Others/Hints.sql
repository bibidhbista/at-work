fastfirstrow

readpast