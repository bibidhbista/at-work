set statistics io on


-- Three versions.  NOT IN, NOT EXISTS, LEFT JOIN

Select * 
	from Person.Person PP
	where PP.BusinessEntityID NOT IN (Select Ph.BusinessEntityID
		from Person.PersonPhone PH
		where PH.BusinessEntityID = PP.BusinessEntityID
			and PH.PhoneNumber like '404%')
	And PP.LastName = 'Brooks'
			
			
Select * 

	from Person.Person PP
	where NOT EXISTS (Select PH.PhoneNumber
		from Person.PersonPhone PH
		where PH.BusinessEntityID = PP.BusinessEntityID
			and PH.PhoneNumber like '404%')
	and PP.LastName = 'Brooks'
		
		
		
Select * from Sales.SalesPerson PP
	left join Person.Contact PH
		on PH.BusinessEntityID = PP.BusinessEntityID
		and PH.PhoneNumber like '404%'
	where PH.BusinessEntityID IS NULL
			and PP.LastName = 'Brooks'
 
 
 select * from INFORMATION_SCHEMA.COLUMNS where table_name like '%person%'