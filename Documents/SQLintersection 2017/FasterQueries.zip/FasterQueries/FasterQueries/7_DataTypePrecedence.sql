USE AdventureWorks
GO
--Comparions of columns of different data types
--lower precedence data types are converted to higher precedence data types
--SEEK ON AN NVARCHAR COLUMN WITH A VARCHAR PREDICATE VALUE

SELECT Name   --NVARCHAR(50)
FROM Production.Product 
WHERE Name = CAST('HL Crankarm' AS VARCHAR(50))
GO
---------------------------------------------------------------
--SCAN ON A VARCHAR COLUMN WITH NVARCHAR PREDICATE VALUE.
SELECT AccountNumber --varchar(10) column
FROM Sales.Customer
WHERE AccountNumber = CAST(N'AW00020720' AS NVARCHAR(10))
