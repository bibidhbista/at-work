USE AdventureWorks2016
GO
DBCC FREEPROCCACHE
GO
IF OBJECT_ID('tempdb..#ShowPlanCache') IS NOT NULL
DROP PROCEDURE #ShowPlanCache
GO
CREATE PROCEDURE #ShowPlanCache
AS
SELECT p.cacheobjtype, p.objtype, usecounts, text
FROM sys.dm_exec_cached_plans p
	CROSS APPLY sys.dm_exec_sql_text(plan_handle)
WHERE 
	cacheobjtype = 'Compiled Plan' AND
	text NOT LIKE '%sys.dm_exec_sql_text%' AND
	text NOT LIKE '%statistics%' AND
	text NOT LIKE '%sys.databases%'
GO
----------------------------------------------------------------------
--explicit value supplied to predicate
SElECT *
FROM Sales.SalesOrderDetail
WHERE ProductID = 897
GO
----------------------------------------------------------------------
SELECT *
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber = N'A643-4938-95'
----------------------------------------------------------------------
--use local variables rather than explicit values
DECLARE @ProductID INT
SET @ProductID = 897

SELECT *
FROM Sales.SalesOrderDetail
WHERE ProductID = @ProductID
GO

DECLARE @ProductID INT
SET @ProductID = 897

SELECT ProductID
FROM Sales.SalesOrderDetail
WHERE ProductID = @ProductID
GO
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)
GO
----------------------------------------------------------------------
DECLARE @CarrierTrackingNumber NVARCHAR(25)
SET @CarrierTrackingNumber = N'A643-4938-95'

SELECT *
FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber = @CarrierTrackingNumber
----------------------------------------------------------------------
SELECT 
	DistinctProductCount = COUNT(DISTINCT ProductID), 
	DistinctCarrierCount = COUNT(DISTINCT CarrierTrackingNumber), 
	TotalCount = COUNT(*), 
	ProductDensity = 1.000/COUNT(DISTINCT ProductID),
	CarrierDensity = 1.000/COUNT(DISTINCT CarrierTrackingNumber)
FROM Sales.SalesOrderDetail
----------------------------------------------------------------------


DECLARE @ProductID INT
SET @ProductID = 897

SELECT ProductID
FROM Sales.SalesOrderDetail
WHERE ProductID > @ProductID
GO
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', IX_SalesOrderDetail_ProductID)
GO
SELECT 121317 * .3
----------------------------------------------------------------------

--use a stored procedure with parameters in place of 
--using local variables
IF OBJECT_ID('Sales.usp_GetSalesOrders') IS NOT NULL
DROP PROCEDURE Sales.usp_GetSalesOrders
GO
CREATE PROCEDURE Sales.usp_GetSalesOrders
(
	@ProductID INT
)
AS
BEGIN
	SELECT *
	FROM Sales.SalesOrderDetail
	WHERE ProductID = @ProductID
END
GO
----------------------------------------------------------------------
DBCC FREEPROCCACHE

--run the temp proc to show whats in the plan cache.
EXECUTE #ShowPlanCache
GO
EXECUTE Sales.usp_GetSalesOrders 
@ProductID = 897
GO
EXECUTE Sales.usp_GetSalesOrderS 
@ProductID = 870
GO
EXECUTE #ShowPlanCache
GO
DBCC FREEPROCCACHE
GO
EXECUTE Sales.usp_GetSalesOrders 
@ProductID = 870
GO
EXECUTE Sales.usp_GetSalesOrders 
@ProductID = 897

GO




