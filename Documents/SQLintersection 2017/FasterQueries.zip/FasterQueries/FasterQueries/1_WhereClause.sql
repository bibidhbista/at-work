USE AdventureWorks2016
GO
SET STATISTICS IO ON
GO
SELECT ModifiedDate
FROM Sales.Customer c
WHERE CAST(CONVERT(VARCHAR(10), ModifiedDate, 101) AS DATETIME) = '2/23/2007'
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE ModifiedDate >= '2/23/2007' AND ModifiedDate < '2/24/2007'
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE DATEADD(YEAR, 6, ModifiedDate) < '12/16/2010'

SELECT ModifiedDate
FROM Sales.Customer c 
WHERE ModifiedDate < DATEADD(YEAR, -6, '12/16/2010')
----------------------------------------------------------------------------------------
SELECT ModifiedDate
FROM Sales.Customer c
WHERE YEAR(ModifiedDate) = 2005

SELECT ModifiedDate
FROM Sales.Customer c
WHERE ModifiedDate >= '1/1/2005' AND ModifiedDate < '1/1/2006'
----------------------------------------------------------------------------------------
SELECT COUNT(ProductID)
FROM Sales.SalesOrderDetail 
WHERE ProductID = 710

SELECT COUNT(ProductID)
FROM Sales.SalesOrderDetail 
WHERE (ProductID * 2) = 1420