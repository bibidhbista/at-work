USE AdventureWorks2016
GO
IF EXISTS
(
	SELECT 1
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 870
)
PRINT 'Exists = True'

DECLARE @RowCount INT
SET @RowCount = 
(	
	SELECT COUNT(*) 
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 870
)
IF @RowCount > 0
PRINT 'Exists = True'
--------------------------------------------------------------------------
IF EXISTS
(
	SELECT 1
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 870
)
PRINT 'Exists = True'
GO


	SELECT *
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 8700

IF 
(
	SELECT COUNT(*) 
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = 8700
) > 1
PRINT 'Exists = True'
--------------------------------------------------------------------------

























--IF EXISTS
--(
--	SELECT COUNT(*) 
--	FROM Sales.SalesOrderDetail 
--	WHERE ProductID = -715
--	GROUP BY SalesOrderID
--)
--PRINT 'Exists = True'
--GO
--IF EXISTS
--(
--	SELECT COUNT(*) 
--	FROM Sales.SalesOrderDetail 
--	WHERE ProductID = -715
--)
--PRINT 'Exists = True'
--GO
