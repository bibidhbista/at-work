USE AdventureWorks2016
GO
--CLEANUP
IF OBJECT_ID('Sales.GetOrderDate') IS NOT NULL
DROP FUNCTION Sales.GetOrderDate
GO
--START PROFILER TO SHOW ACTIVITY
CREATE FUNCTION Sales.GetOrderDate
(
	@SalesOrderID INT
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @OrderDate DATETIME
	
	SELECT @OrderDate = OrderDate
	FROM Sales.SalesOrderHeader 
	WHERE SalesOrderID = @SalesOrderID
	
	RETURN(@OrderDate)
	
END
GO
SELECT ProductID, Sales.GetOrderDate(SalesOrderID)
FROM Sales.SalesOrderDetail
WHERE ProductID = 708
GO
--------------------------------------------------------------------------------------
IF OBJECT_ID('Sales.GetOrderDate') IS NOT NULL
DROP FUNCTION Sales.GetOrderDate
GO
CREATE FUNCTION Sales.GetOrderDate
(
	@SalesOrderID INT
)
RETURNS TABLE
AS RETURN
(	
	SELECT OrderDate
	FROM Sales.SalesOrderHeader 
	WHERE SalesOrderID = @SalesOrderID
)
	
GO
--------------------------------------------------------------------------------------
SELECT sd.ProductID, x.*
FROM Sales.SalesOrderDetail sd
CROSS APPLY Sales.GetOrderDate(sd.SalesOrderID) AS x
WHERE sd.ProductID = 708
GO
---------------------------------------------------------------------------
IF OBJECT_ID('Sales.GetOrderDate') IS NOT NULL
DROP FUNCTION Sales.GetOrderDate
GO
CREATE FUNCTION Sales.GetOrderDate
(
	@SalesOrderID INT
)
RETURNS @TableVariable TABLE
(
	OrderDate DATETIME
)
AS
BEGIN
	INSERT INTO @TableVariable(OrderDate)
	SELECT OrderDate
	FROM Sales.SalesOrderHeader 
	WHERE SalesOrderID = @SalesOrderID
	
	RETURN
END
GO

SELECT ProductID, x.*
FROM Sales.SalesOrderDetail
CROSS APPLY Sales.GetOrderDate(SalesOrderID) AS x
WHERE ProductID = 708
--------------------------------------------------------------------------------------
SELECT sd.ProductID, sh.OrderDate
FROM Sales.SalesOrderHeader sh
JOIN Sales.SalesOrderDetail sd ON sh.SalesOrderID = sd.SalesOrderID 
WHERE sd.ProductID = 708
