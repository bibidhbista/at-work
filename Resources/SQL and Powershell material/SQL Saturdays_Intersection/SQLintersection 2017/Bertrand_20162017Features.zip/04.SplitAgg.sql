-- split - 2016 RTM


USE tempdb;
GO

-- simple:
DECLARE @s VARCHAR(MAX) = 'foo,bar', @d CHAR(1) = ',';

SELECT *
FROM STRING_SPLIT(@s, @d);
GO


-- what if I need the output in the same order as input?

DECLARE @s VARCHAR(MAX) = 'foo,bar,blat,x,blat', @d CHAR(1) = ',';

SELECT [value]
FROM STRING_SPLIT(@s, @d)
GROUP BY [value] -- remove duplicates
ORDER BY ROW_NUMBER() OVER 
(
  ORDER BY CHARINDEX(@d + [value] + @d, @d + @s + @d)
);
GO
-- WARNING! This is a very expensive sort!
-- And it only works if there are no duplicates


-- what if my string has multi-character delimiters?

DECLARE @s nvarchar(MAX) = N'foo|||bar', @od nchar(3) = N'|||',
@rd nchar(1) = N'~'; -- pick something that can't occur in data

SELECT [value]
FROM STRING_SPLIT(REPLACE(@s, @od, @rd), @rd);
GO
-- this is not cheap either!


-- what if I upgrade to SQL Server 2016 but already have
-- a function called string_split?

CREATE FUNCTION dbo.string_split
(
  @list nvarchar(max), 
  @delim nchar(1)
)
RETURNS TABLE 
AS RETURN (SELECT [value] = 'hard-coded for emphasis');
GO


-- SQL Server will only use the built-in function if you
-- forget to use the schema prefix. ALWAYS use schema!

DECLARE @s nvarchar(MAX) = N'a,b';

SELECT [value] FROM dbo.string_split(@s, N',');

SELECT [value] FROM STRING_SPLIT(@s, N',');
GO

-- in a case-sensitive database you might have 
-- a slightly different problem here

DROP FUNCTION dbo.string_split;
GO


-- agg - 2016 SP1

-- before:

SELECT /*DISTINCT*/ SalesOrderID, ProductIDs = STUFF(
  (SELECT N',' + RTRIM(ProductID) 
     FROM Sales.SalesOrderDetail AS d
     WHERE d.SalesOrderID = o.SalesOrderID
     FOR XML PATH, type).value(N'.[1]', 'nvarchar(max)')
     ,1,1,'')
   FROM Sales.SalesOrderDetail AS o
   GROUP BY SalesOrderID
   ORDER BY SalesOrderID;

SELECT SalesOrderID, ProductIDs = STUFF(
  (SELECT N',' + RTRIM(ProductID) 
     FROM Sales.SalesOrderDetail AS d
     WHERE d.SalesOrderID = o.SalesOrderID
     ORDER BY ProductID
     FOR XML PATH, type).value(N'.[1]', 'nvarchar(max)')
     ,1,1,'')
   FROM Sales.SalesOrderDetail AS o
   GROUP BY SalesOrderID
   ORDER BY SalesOrderID;

-- now:

SELECT SalesOrderID, STRING_AGG(ProductID,N',')
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID
ORDER BY SalesOrderID;

SELECT SalesOrderID, STRING_AGG(ProductID,N',')
                     WITHIN GROUP (ORDER BY ProductID)
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID
ORDER BY SalesOrderID;

