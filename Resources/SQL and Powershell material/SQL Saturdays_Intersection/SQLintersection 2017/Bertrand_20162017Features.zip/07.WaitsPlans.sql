USE WideWorldImporters;
GO

-- sys.dm_exec_session_wait_stats

WAITFOR DELAY '00:00:02';
SELECT * FROM sys.dm_exec_session_wait_stats
  WHERE session_id = @@SPID;

-- showplan improvements

UPDATE STATISTICS Warehouse.ColdRoomTemperatures_Archive 
WITH ROWCOUNT = 5;
GO
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
DBCC DROPCLEANBUFFERS;
GO

-- function from Adam Machanic
-- http://dataeducation.com/next-level-parallel-plan-
-- forcing-an-alternative-to-8649/
SELECT x.* FROM dbo.make_parallel() AS y
CROSS APPLY
(
  SELECT TOP (90) PERCENT a.ColdRoomSensorNumber, 
    c = COUNT(*) OVER (PARTITION BY a.ColdRoomSensorNumber),
    rn = ROW_NUMBER() OVER (PARTITION BY a.ColdRoomSensorNumber ORDER BY NEWID())
  FROM Warehouse.ColdRoomTemperatures_Archive AS a
  INNER HASH JOIN Warehouse.ColdRoomTemperatures AS c
ON a.ColdRoomTemperatureID = c.ColdRoomTemperatureID
CROSS APPLY sys.dm_db_log_info(NULL)
GROUP BY a.ColdRoomSensorNumber
ORDER BY NEWID() ASC
) x
ORDER BY NEWID()
OPTION (QUERYTRACEON 8649, MAXDOP 3);
-- ShowPlan - see waits, actual metrics

SELECT * FROM sys.dm_exec_session_wait_stats
  WHERE session_id = @@SPID;

-- this does not work:
-- DBCC SQLPERF('sys.dm_exec_session_wait_stats', CLEAR);

DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);