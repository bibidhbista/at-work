-- DROP IF EXISTS

-- before:
IF OBJECT_ID(N'dbo.tablename') IS NOT NULL
BEGIN
    DROP TABLE dbo.tablename;
END

IF OBJECT_ID(N'tempdb.dbo.#tablename') IS NOT NULL
BEGIN
    DROP TABLE #tablename;
END

-- now:
DROP TABLE IF EXISTS dbo.tablename;
DROP TABLE IF EXISTS #tablename;


-- CREATE OR ALTER

-- before:

IF OBJECT_ID(N'dbo.procedurename') IS NULL
BEGIN
  EXEC sys.sp_executesql 
    N'CREATE PROCEDURE dbo.procedurename AS SELECT 1;';
END
GO
ALTER PROCEDURE dbo.procedurename AS SELECT 2;
GO

-- now:

CREATE OR ALTER PROCEDURE dbo.procedurename
AS
  SELECT 2;
GO





