-- CONCAT_WS -- simplify nullable string logic

DECLARE @first  nvarchar(32) = N'Aaron',
        @middle nvarchar(32) = NULL, --N'M',
        @last   nvarchar(32) = N'Bertrand';

SELECT
  @first + ' ' + COALESCE(@middle + ' ', '') + @last,
  CONCAT(@first, @middle, @last), 
  CONCAT_WS(N' ', @first, @middle, @last);



-- TRIM -- simplify LTRIM(RTRIM()) logic

DECLARE @string varchar(255) = '      space space    ';

SELECT 'x' + @string + 'x', 
       'x' + TRIM(@string) + 'x';



-- TRANSLATE -- reduce complexity of nested replace
             -- for single-character replacements

DECLARE @string varchar(255) = 'hello, [foo]{bar}!';
SELECT @string, TRANSLATE(@string, '[]{}', '"  "');

SELECT TRANSLATE (N'r~x', N'rx', N'ab');

-- be careful with Unicode (bugs):
-- let's say someone pooped in your data
-- this will give you a poop emoji to copy:
SELECT TRY_CONVERT(nchar(10), 0x3DD8A9DC);

-- error:
SELECT TRANSLATE (N'r~<put poop emoji here>', N'r<here>', N'ab');
GO
-- no error but no replacement:
SELECT TRANSLATE (N'r~<put poop emoji here>', N'r<here>', N'abc');
GO
-- fix:
SELECT TRANSLATE (N'r~<put poop emoji here>', N'r<here>', 
  N'ab' COLLATE Latin1_General_100_CI_AI_SC);