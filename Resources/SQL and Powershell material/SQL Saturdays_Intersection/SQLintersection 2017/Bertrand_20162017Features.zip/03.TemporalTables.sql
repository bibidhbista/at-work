-- temporal tables
USE [master];
GO
DROP DATABASE IF EXISTS Temporal;
GO
CREATE DATABASE Temporal;
GO
USE Temporal;
GO

CREATE TABLE dbo.Employees
(
    EmployeeID int PRIMARY KEY,
    Salary int,
    ValidStart datetime2(0) GENERATED ALWAYS AS ROW START NOT NULL,
    ValidEnd   datetime2(0) GENERATED ALWAYS AS ROW END   NOT NULL,
    PERIOD FOR SYSTEM_TIME (ValidStart, ValidEnd) 
            -- APPLICATION_TIME: future
) 
WITH 
(
  SYSTEM_VERSIONING = ON 
  (
    HISTORY_TABLE = dbo.EmployeeHistory,
    HISTORY_RETENTION_PERIOD = 3 MONTHS
  )
);

INSERT dbo.Employees(EmployeeID, Salary) VALUES(1,50000);
WAITFOR DELAY '00:00:05';
UPDATE dbo.Employees SET Salary = 70000 WHERE EmployeeID = 1;
WAITFOR DELAY '00:00:05';
UPDATE dbo.Employees SET Salary = 80000 WHERE EmployeeID = 1;
INSERT dbo.Employees(EmployeeID, Salary) VALUES(2, 60000);
WAITFOR DELAY '00:00:05';
DELETE dbo.Employees WHERE EmployeeID = 1;

SELECT * FROM dbo.Employees;
SELECT * FROM dbo.EmployeeHistory;

-- take these timestamps and use them in predicates below

-- AS OF shows the state of the table *at that time*
SELECT * FROM dbo.Employees 
  FOR SYSTEM_TIME AS OF '';

SELECT SUM(Salary) FROM dbo.Employees 
  FOR SYSTEM_TIME AS OF '';

-- from -> to = open-ended range
SELECT * FROM dbo.Employees 
  FOR SYSTEM_TIME FROM '20000101' TO '';

-- between includes data valid from after end boundary
SELECT * FROM dbo.Employees 
  FOR SYSTEM_TIME BETWEEN '20000101' AND '';

-- there's also CONTAINED IN

GO
USE [master];
GO
ALTER DATABASE Temporal SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
DROP DATABASE Temporal;
GO