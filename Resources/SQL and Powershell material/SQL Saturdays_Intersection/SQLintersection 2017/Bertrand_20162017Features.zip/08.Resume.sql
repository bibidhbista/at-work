USE WideWorldImporters;
GO

-- resumable online index rebuild

DROP TABLE IF EXISTS dbo.ColdRoomStuff;
GO

-- create a "big enough" table
SELECT a.* INTO dbo.ColdRoomStuff 
  FROM Warehouse.ColdRoomTemperatures_Archive AS a
  CROSS JOIN 
  (
    SELECT TOP (2) * FROM master.dbo.spt_values
  ) AS b;

CREATE CLUSTERED INDEX cix_crs
  ON dbo.ColdRoomStuff
  (
    [ColdRoomTemperatureID], 
    [RecordedWhen] DESC 
  );

CREATE INDEX nci_crs ON dbo.ColdRoomStuff
(
  [ColdRoomTemperatureID] DESC, 
  [Temperature]
) INCLUDE (ValidFrom, ValidTo);

EXEC sys.sp_spaceused N'dbo.ColdRoomStuff';

SELECT index_id, pages = COUNT(*) 
FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID(N'dbo.ColdRoomStuff'), NULL, NULL, 'LIMITED')
GROUP BY index_id;

-- rebuild 
ALTER INDEX cix_crs ON dbo.ColdRoomStuff
  REBUILD WITH 
  (
    ONLINE = ON, 
    RESUMABLE = ON, 
    MAX_DURATION = 1 MINUTES -- your maintenance window
  );

-- can also pause manually:
ALTER INDEX cix_crs ON dbo.ColdRoomStuff PAUSE;

-- and resume with different options
-- (diferent maxdop, longer duration)
ALTER INDEX cix_crs ON dbo.ColdRoomStuff RESUME
  WITH (MAXDOP = 4, MAX_DURATION = 10 MINUTES);

-- and abort:  
ALTER INDEX cix_crs ON dbo.ColdRoomStuff ABORT;

-- can't check percent_complete in sys.dm_exec_requests
-- new DMV for checking progress:
SELECT t.name, ro.name, ro.state_desc,
  ro.start_time, ro.last_pause_time,
  ro.percent_complete, ro.page_count
FROM sys.tables AS t
INNER JOIN sys.index_resumable_operations AS ro
ON t.[object_id] = ro.[object_id];

-- we can also verify:
SELECT index_id, pages = COUNT(*) 
FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID(N'dbo.ColdRoomStuff'), NULL, NULL, 'LIMITED')
GROUP BY index_id;

-- is it accurate? Pretty close:
;WITH src(i, pages) AS
(
  SELECT index_id / 800000, COUNT(*) 
    FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID(N'dbo.ColdRoomStuff'), NULL, NULL, 'LIMITED')
   GROUP BY index_id / 800000
)
SELECT curr.pages, prev.pages, 
  percent_complete = 100.*curr.pages/prev.pages
FROM src AS curr
INNER JOIN src AS prev
ON curr.i > prev.i;

