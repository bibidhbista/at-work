--SELECT INTO ON filegroup
--#SQLServer 2017
--note file paths are for named instance "SQL2017"

USE [master];
GO
DROP DATABASE IF EXISTS SelectIntoDemo;
GO
CREATE DATABASE SelectIntoDemo;
GO
ALTER DATABASE SelectIntoDemo ADD FILEGROUP SecondaryFG;
GO
USE SelectIntoDemo;
GO

ALTER DATABASE SelectIntoDemo ADD FILE 
(
  name = 'SelectIntoDemoTarget',
  filename = 'C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\DATA\SIDSecondaryFG.ndf',
  size = 1024MB
) TO FILEGROUP SecondaryFG;
GO
 
SELECT * INTO dbo.Try1
  FROM sys.all_objects;

SELECT * INTO dbo.Try2 
  ON [SecondaryFG] 
  FROM sys.all_objects;  


-- what about memory-optimized filegroups?

ALTER DATABASE SelectIntoDemo ADD FILEGROUP MemOptFG 
  CONTAINS MEMORY_OPTIMIZED_DATA;

ALTER DATABASE SelectInto ADD FILE 
(
  name = 'MemOptFile', 
  filename='C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\DATA\MemOptFile'
) TO FILEGROUP MemOptFG;
GO

sp_helpfile

SELECT * INTO dbo.Try3
  ON [MemOptFG] 
  FROM sys.all_objects; 

-- prove that I'm not just horrible at
-- setting up memory-optimized tables:

CREATE TABLE dbo.JustChecking
(
  CheckID int PRIMARY KEY NONCLUSTERED
)
WITH (MEMORY_OPTIMIZED = ON); 

-- confirm there are tables on all FGs:
SELECT 
  [FileGroup] = ds.name,
  [Schema]    = s.name,
  [Table]     = t.name,
  IndexType   = i.type_desc,
  IndexName   = i.name 
FROM sys.data_spaces AS ds 
INNER JOIN sys.allocation_units AS au 
  ON ds.data_space_id = au.data_space_id 
INNER JOIN sys.partitions AS p 
  ON au.container_id = p.hobt_id
INNER JOIN sys.tables AS t 
  ON p.[object_id] = t.[object_id] 
INNER JOIN sys.schemas AS s 
  ON t.[schema_id] = s.[schema_id]
LEFT OUTER JOIN sys.indexes AS i 
  ON p.[object_id] = i.[object_id] 
  AND p.index_id = i.index_id;