-- Limit impact of CHECKDB (2016 RTM)
DBCC CHECKDB() WITH MAXDOP = 1;


-----------------------------------
-- dm_db_log_info/_stats (2017 RTM)

-- before:
DBCC LOGINFO;

-- now:
SELECT * FROM sys.dm_db_log_info(DB_ID());
SELECT * FROM sys.dm_db_log_stats(DB_ID());

SELECT d.name, d.recovery_model_desc,
  s.active_vlf_count, 
  s.current_vlf_size_mb, 
  s.log_since_last_checkpoint_mb, 
  s.log_since_last_log_backup_mb
FROM sys.databases AS d
CROSS APPLY sys.dm_db_log_stats(d.database_id) AS s;


----------------------------------
-- dm_exec_input_buffer (2016 RTM)

-- before:

PRINT N'Hello';
DBCC INPUTBUFFER(@@SPID);

-- now:

SELECT 
  s.session_id, 
  b.event_info, 
  s.[program_name], 
  s.login_name, 
  s.[status], 
  s.memory_usage, 
  s.logical_reads, 
  r.database_id,
  r.last_wait_type
FROM sys.dm_exec_sessions AS s
CROSS APPLY sys.dm_exec_input_buffer(s.session_id, NULL) AS b
LEFT OUTER JOIN sys.dm_exec_requests AS r
  ON s.session_id = r.session_id
WHERE s.is_user_process = 1;


---------------------------------------
-- sys.dm_db_stats_histogram (2017 RTM)

DROP TABLE IF EXISTS dbo.obj;
GO
SELECT name,[object_id] INTO dbo.obj FROM sys.all_objects;
CREATE INDEX ix ON dbo.obj(name);
SELECT TOP (20) name FROM dbo.obj ORDER BY name;

-- before:

DBCC SHOW_STATISTICS(N'dbo.obj', N'ix') WITH HISTOGRAM;

-- try to do this for 10 tables quickly, 
-- you need sysadmin and dynamic SQL.

-- now:

SELECT * 
  FROM sys.dm_db_stats_histogram(OBJECT_ID(N'dbo.obj'), 2);

-- for multiple tables:

SELECT t.name, s.name, h.*
  FROM sys.tables AS t
  INNER JOIN sys.stats AS s
  ON t.[object_id] = s.[object_id]
  CROSS APPLY 
  sys.dm_db_stats_histogram(t.[object_id], s.stats_id) AS h
  -- WHERE table matches some pattern
  ;


--------------------------------------
-- clearing procedure cache (2016 RTM)

-- before:

DBCC FREEPROCCACHE;    -- entire server
DBCC FLUSHPROCINDB(5); -- need to know DB_ID()

-- now, in current database:

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;


---------------------------------
-- option (use hint()) (2016 SP1)

-- before:

SELECT name FROM dbo.obj WHERE name LIKE N'%x%'
  OPTION (QUERYTRACEON 4136);

-- now:

SELECT name FROM dbo.obj WHERE name LIKE N'%x%'
  OPTION (USE HINT('DISABLE_PARAMETER_SNIFFING'));

-- more typing, but no more sysadmin or memory games


-- also for old cardinality estimator:
-- instead of using TF 9481/2312 or compat level
-- you can use this at the query level:

SELECT name FROM dbo.obj WHERE name LIKE N'%x%'
OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'));

SELECT name FROM dbo.obj WHERE name LIKE N'%x%'
OPTION (USE HINT ('FORCE_DEFAULT_CARDINALITY_ESTIMATION'));

-- or this at the database level:
ALTER DATABASE SCOPED CONFIGURATION -- FOR SECONDARY
 SET LEGACY_CARDINALITY_ESTIMATION = ON; --OFF;