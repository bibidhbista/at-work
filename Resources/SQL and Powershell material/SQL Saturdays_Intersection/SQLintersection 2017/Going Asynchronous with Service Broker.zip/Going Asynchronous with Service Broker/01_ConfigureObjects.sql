-- Enable Service Broker and switch to the database
USE master;
GO

IF DB_ID('SingleDB_Broker') IS NOT NULL
BEGIN
	ALTER DATABASE SingleDB_Broker SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE SingleDB_Broker;
END
GO
CREATE DATABASE SingleDB_Broker;
GO

ALTER DATABASE SingleDB_Broker
      SET ENABLE_BROKER;
GO
USE SingleDB_Broker;
GO

-- Create the message types
CREATE MESSAGE TYPE
       [//SingleDB_Broker/RequestMessage]
       VALIDATION = WELL_FORMED_XML;
CREATE MESSAGE TYPE
       [//SingleDB_Broker/ReplyMessage]
       VALIDATION = WELL_FORMED_XML;
GO

-- View the message types we just created
SELECT * 
FROM sys.service_message_types
WHERE message_type_id > 65535;
GO

-- View the system message types
SELECT * 
FROM sys.service_message_types
WHERE message_type_id <= 65535;
GO

-- Create the contract
CREATE CONTRACT [//SingleDB_Broker/SampleContract]
      ([//SingleDB_Broker/RequestMessage]
       SENT BY INITIATOR,
       [//SingleDB_Broker/ReplyMessage]
       SENT BY TARGET
      );
GO

-- View the contract we created
SELECT *
FROM sys.service_contracts
WHERE service_contract_id > 65535;
GO

-- View the system contracts
SELECT *
FROM sys.service_contracts
WHERE service_contract_id <= 65535;
GO


-- Create the target queue and service
CREATE QUEUE SingleDB_Broker_TargetQueue;
GO

-- Check for our queue
SELECT * 
FROM sys.service_queues
WHERE is_ms_shipped = 0;
GO

-- View internal system queues
SELECT * 
FROM sys.service_queues
WHERE is_ms_shipped = 1;
GO

CREATE SERVICE
       [//SingleDB_Broker/TargetService]
       ON QUEUE SingleDB_Broker_TargetQueue
       ([//SingleDB_Broker/SampleContract]);
GO

-- Check our service
SELECT *
FROM sys.services
WHERE service_id > 65535;
GO

-- Show system services
SELECT *
FROM sys.services
WHERE service_id <= 65535;
GO

-- Create the initiator queue and service
CREATE QUEUE SingleDB_Broker_InitiatorQueue;
GO

-- Check for our queue
SELECT * 
FROM sys.service_queues
WHERE is_ms_shipped = 0;
GO


CREATE SERVICE
       [//SingleDB_Broker/InitiatorService]
       ON QUEUE SingleDB_Broker_InitiatorQueue;
GO

-- Check our service
SELECT *
FROM sys.services
WHERE service_id > 65535;
GO