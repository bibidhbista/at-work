-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Drop the conversation objects
IF EXISTS (SELECT * FROM sys.services
           WHERE name =
           N'//SingleDB_Broker/TargetService')
     DROP SERVICE
     [//SingleDB_Broker/TargetService];

IF EXISTS (SELECT * FROM sys.service_queues
           WHERE name = N'TargetQueue1DB')
     DROP QUEUE TargetQueue1DB;

-- Drop the intitator queue and service if they already exist.
IF EXISTS (SELECT * FROM sys.services
           WHERE name =
           N'//SingleDB_Broker/InitiatorService')
     DROP SERVICE
     [//SingleDB_Broker/InitiatorService];

IF EXISTS (SELECT * FROM sys.service_queues
           WHERE name = N'InitiatorQueue1DB')
     DROP QUEUE InitiatorQueue1DB;

IF EXISTS (SELECT * FROM sys.service_contracts
           WHERE name =
           N'//SingleDB_Broker/SampleContract')
     DROP CONTRACT
     [//SingleDB_Broker/SampleContract];

IF EXISTS (SELECT * FROM sys.service_message_types
           WHERE name =
           N'//SingleDB_Broker/RequestMessage')
     DROP MESSAGE TYPE
     [//SingleDB_Broker/RequestMessage];

IF EXISTS (SELECT * FROM sys.service_message_types
           WHERE name =
           N'//SingleDB_Broker/ReplyMessage')
     DROP MESSAGE TYPE
     [//SingleDB_Broker/ReplyMessage];
GO

-- Switch to the master database and drop the sample database
USE master;
GO

IF DB_ID('SingleDB_Broker') IS NOT NULL
BEGIN
	ALTER DATABASE SingleDB_Broker SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE SingleDB_Broker;
END
GO