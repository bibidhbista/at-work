-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Receive the reply and end the conversation
DECLARE @RecvReplyMsg NVARCHAR(100);
DECLARE @RecvReplyDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvReplyMsgName sysname;

BEGIN TRANSACTION;

WAITFOR
( RECEIVE TOP(1)
    @RecvReplyDlgHandle = conversation_handle,
    @RecvReplyMsg = message_body,
	@RecvReplyMsgName = message_type_name
  FROM SingleDB_Broker_InitiatorQueue
), TIMEOUT 1000;

IF @RecvReplyMsgName =
   N'//SingleDB_Broker/ReplyMessage'
BEGIN
	END CONVERSATION @RecvReplyDlgHandle;
END

SELECT @RecvReplyMsg AS ReceivedReplyMsg;

COMMIT TRANSACTION;
GO


-- Check for a message in the targets queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_TargetQueue;
GO

-- Check for a  message in the initiator queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_InitiatorQueue;
GO
