-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Begin a conversation and send a request message
DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
DECLARE @RequestMsg NVARCHAR(100);

BEGIN TRANSACTION;

BEGIN DIALOG @InitDlgHandle
     FROM SERVICE
      [//SingleDB_Broker/InitiatorService]
     TO SERVICE
      N'//SingleDB_Broker/TargetService'
     ON CONTRACT
      [//SingleDB_Broker/SampleContract]
     WITH
         ENCRYPTION = OFF;

SELECT @RequestMsg =
       N'<RequestMsg>Message for Target service.</RequestMsg>';

SEND ON CONVERSATION @InitDlgHandle
     MESSAGE TYPE 
     [//SingleDB_Broker/RequestMessage]
     (@RequestMsg);

SELECT @RequestMsg AS SentRequestMsg;

COMMIT TRANSACTION;
GO

-- View the conversation we created
SELECT *
FROM sys.conversation_groups;
GO

-- View the message in the targets queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_TargetQueue;
GO

-- Check for the reply message in the initiator queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_InitiatorQueue;
GO
