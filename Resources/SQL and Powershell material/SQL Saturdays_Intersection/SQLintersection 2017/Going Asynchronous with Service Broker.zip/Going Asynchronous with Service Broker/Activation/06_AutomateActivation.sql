-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Alter the target queue to specify internal activation
ALTER QUEUE SingleDB_Broker_TargetQueue
    WITH ACTIVATION
    ( STATUS = ON,
      PROCEDURE_NAME = TargetQueue_ActivationProcedure,
      MAX_QUEUE_READERS = 10,
      EXECUTE AS SELF
    );
GO

