-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Test the activation Procedure
EXECUTE dbo.TargetQueue_ActivationProcedure;
GO

-- Check the message in the targets queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_TargetQueue;
GO

-- Check for the reply message in the initiator queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_InitiatorQueue;
GO

