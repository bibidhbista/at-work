-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO


IF OBJECT_ID('InitiatorQueue_ActivationProcedure') IS NOT NULL
BEGIN
	DROP PROCEDURE InitiatorQueue_ActivationProcedure;
END
GO

CREATE PROCEDURE InitiatorQueue_ActivationProcedure
AS

  DECLARE @conversation_handle UNIQUEIDENTIFIER;
  DECLARE @message_body NVARCHAR(100);
  DECLARE @message_type_name sysname;

  WHILE (1=1)
  BEGIN

    BEGIN TRANSACTION;

    WAITFOR
    ( RECEIVE TOP(1)
        @conversation_handle = conversation_handle,
        @message_body = message_body,
        @message_type_name = message_type_name
      FROM SingleDB_Broker_InitiatorQueue
    ), TIMEOUT 5000;

    IF (@@ROWCOUNT = 0)
    BEGIN
      ROLLBACK TRANSACTION;
      BREAK;
    END

    IF @message_type_name = N'//SingleDB_Broker/ReplyMessage'
    BEGIN
       END CONVERSATION @conversation_handle;
    END

	-- If end dialog message, end the dialog
    ELSE IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
    BEGIN
       END CONVERSATION @conversation_handle;
    END

	-- If error message, log and end conversation
    ELSE IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
    BEGIN
		DECLARE @error INT;
		DECLARE @description NVARCHAR(4000);

		-- Pull the error code and description from the doc
		WITH XMLNAMESPACES ('http://schemas.microsoft.com/SQL/ServiceBroker/Error' AS ssb)
		SELECT
			@error = CAST(@message_body AS XML).value('(//ssb:Error/ssb:Code)[1]', 'INT'),
			@description = CAST(@message_body AS XML).value('(//ssb:Error/ssb:Description)[1]', 'NVARCHAR(4000)');
		
		RAISERROR(N'Received error Code:%i Description:"%s"', 16, 1, @error, @description) WITH LOG;

		-- Now that we handled the error logging cleanup
		END CONVERSATION @conversation_handle;
	END
      
    COMMIT TRANSACTION;

  END
GO

-- Alter the target queue to specify internal activation
ALTER QUEUE SingleDB_Broker_InitiatorQueue
    WITH ACTIVATION
    ( STATUS = ON,
      PROCEDURE_NAME = InitiatorQueue_ActivationProcedure,
      MAX_QUEUE_READERS = 10,
      EXECUTE AS SELF
    );
GO