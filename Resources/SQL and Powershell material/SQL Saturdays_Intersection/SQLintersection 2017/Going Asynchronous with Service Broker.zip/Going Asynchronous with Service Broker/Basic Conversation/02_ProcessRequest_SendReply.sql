-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Receive the request and send a reply
DECLARE @RecvReqDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvReqMsg NVARCHAR(100);
DECLARE @RecvReqMsgName sysname;

BEGIN TRANSACTION;

WAITFOR
( RECEIVE TOP(1)
    @RecvReqDlgHandle = conversation_handle,
    @RecvReqMsg = message_body,
    @RecvReqMsgName = message_type_name
  FROM SingleDB_Broker_TargetQueue
), TIMEOUT 1000;

SELECT @RecvReqMsg AS ReceivedRequestMsg;

IF @RecvReqMsgName =
   N'//SingleDB_Broker/RequestMessage'
BEGIN
     DECLARE @ReplyMsg NVARCHAR(100);
     SELECT @ReplyMsg =
     N'<ReplyMsg>Message for Initiator service.</ReplyMsg>';
 
     SEND ON CONVERSATION @RecvReqDlgHandle
          MESSAGE TYPE 
          [//SingleDB_Broker/ReplyMessage]
          (@ReplyMsg);
END

SELECT @ReplyMsg AS SentReplyMsg;

COMMIT TRANSACTION;
GO

-- Check for the message in the targets queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_TargetQueue;
GO

-- Check for the reply message in the initiator queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_InitiatorQueue;
GO
