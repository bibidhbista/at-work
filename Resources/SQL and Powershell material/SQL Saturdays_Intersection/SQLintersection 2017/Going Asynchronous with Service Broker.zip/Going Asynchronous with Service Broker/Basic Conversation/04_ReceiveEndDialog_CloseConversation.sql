-- Switch to the SingleDB_Broker database
USE SingleDB_Broker;
GO

-- Receive the End Dialog and clean up
DECLARE @RecvEndDialogDlgHandle UNIQUEIDENTIFIER;
DECLARE @RecvEndDialogMsg NVARCHAR(100);
DECLARE @RecvEndDialogMsgName sysname;

BEGIN TRANSACTION;

WAITFOR
( RECEIVE TOP(1)
    @RecvEndDialogDlgHandle = conversation_handle,
    @RecvEndDialogMsg = message_body,
    @RecvEndDialogMsgName = message_type_name
  FROM SingleDB_Broker_TargetQueue
), TIMEOUT 1000;


IF @RecvEndDialogMsgName =
   N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
BEGIN
     END CONVERSATION @RecvEndDialogDlgHandle;
END

COMMIT TRANSACTION;
GO

-- Check for a message in the targets queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_TargetQueue;
GO

-- Check for a  message in the initiator queue
SELECT *, 
	CAST(message_body AS XML) AS message_body_xml
FROM SingleDB_Broker_InitiatorQueue;
GO

-- Check the conversation we created
SELECT *
FROM sys.conversation_groups;
GO