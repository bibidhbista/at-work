USE tempdb;
SET NOCOUNT ON;
GO

/* Properly define variable-length data types */

-- demo 1

DECLARE @x nvarchar = N'Aaron';

SELECT x = @x, 
       y = CONVERT(nvarchar, 
                   N'There once was a man from Nantucket');




















-- demo 2 - it gets worse :

CREATE TABLE dbo.oops
(
  c1 nvarchar(max),
  c2 nvarchar(max),
  c3 nvarchar
);
GO

CREATE PROCEDURE dbo.oops_add_row
  @p1 nvarchar,
  @p2 nvarchar(10),
  @p3 nvarchar
AS
BEGIN
  INSERT dbo.oops(c1,c2,c3) 
    VALUES(@p1,@p2,@p3);
END
GO

EXEC dbo.oops_add_row @p1 = N'Here is some data...', 
                      @p2 = N'And more data...',
                      @p3 = N'And even more data...';

SELECT c1, c2, c3 FROM dbo.oops;


-- you've lost data BUT there is no error
-- and it is not logged anywhere
GO
DROP PROCEDURE dbo.oops_add_row;
DROP TABLE dbo.oops;
GO




-- demo 3 -- memory grants and execution times 
          -- for *SAME* data shows proper choice
          -- up front can be very important:

DROP TABLE IF EXISTS dbo.t1, dbo.t2, dbo.t3;
GO

-- create three tables with different column sizes
CREATE TABLE dbo.t1(a nvarchar(32),   b nvarchar(32),   
                    c nvarchar(32),   d nvarchar(32));

CREATE TABLE dbo.t2(a nvarchar(4000), b nvarchar(4000), 
                    c nvarchar(4000), d nvarchar(4000));

CREATE TABLE dbo.t3(a nvarchar(max),  b nvarchar(max),  
                    c nvarchar(max),  d nvarchar(max));
GO

-- populate them with a bunch of rows, 100 times
INSERT dbo.t1(a,b,c,d)
SELECT TOP (250000) LEFT(c1.name,1), RIGHT(c2.name,1), 
  ABS(c1.column_id/10), ABS(c2.column_id%10)
FROM sys.all_columns AS c1
CROSS JOIN sys.all_columns AS c2
ORDER BY c2.[object_id];

INSERT dbo.t2(a,b,c,d) SELECT a,b,c,d FROM dbo.t1;
INSERT dbo.t3(a,b,c,d) SELECT a,b,c,d FROM dbo.t1;
GO

SELECT TOP (10) * FROM dbo.t1;
SELECT TOP (10) * FROM dbo.t2;
SELECT TOP (10) * FROM dbo.t3;

-- no "primed the cache in advance" tricks
DBCC FREEPROCCACHE WITH NO_INFOMSGS;
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
GO

-- run the same query against all three tables
GO
SELECT DISTINCT a,b,c,d, DENSE_RANK() OVER 
  (PARTITION BY b,c ORDER BY d DESC)
FROM dbo.t1 GROUP BY a,b,c,d ORDER BY c,a DESC;
GO
SELECT DISTINCT a,b,c,d, DENSE_RANK() OVER 
  (PARTITION BY b,c ORDER BY d DESC)
FROM dbo.t2 GROUP BY a,b,c,d ORDER BY c,a DESC;
GO
SELECT DISTINCT a,b,c,d, DENSE_RANK() OVER 
  (PARTITION BY b,c ORDER BY d DESC)
FROM dbo.t3 GROUP BY a,b,c,d ORDER BY c,a DESC;
GO

SELECT [table] = SUBSTRING(t.[text], 
  CHARINDEX(N'FROM ', t.[text])+5,6), 
  [How much memory SQL wanted] = s.max_ideal_grant_kb, 
  [How much memory SQL got]    = s.last_grant_kb, 
  [How long the query took]    = s.last_elapsed_time
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(s.[sql_handle]) AS t
WHERE t.[text] LIKE N'%dbo.'+N't[1-3]%'
ORDER BY SUBSTRING(t.[text], 
  CHARINDEX(N'FROM ', t.[text])+5,6);

DROP TABLE dbo.t1, dbo.t2, dbo.t3;














-- demo 4 : 

/*
  Deferred name resolution 
  Lower-case data types 
*/

CREATE DATABASE fail COLLATE Norwegian_100_BIN2; 
GO
USE fail;
GO

-- need to be careful with object/column names:
CREATE TABLE dbo.SalesOrders
(
  SalesOrderID INT
);
GO

SELECT SalesOrderID FROM dbo.SalesOrders;
GO
SELECT SALESORDERID FROM dbo.SalesOrders;
GO

CREATE PROCEDURE dbo.fail
AS
BEGIN
  SELECT salesorderid FROM dbo.salesorders;
END
GO

EXEC dbo.fail;
GO



-- you also need to be careful with data type names.
-- I try to match what's in sys.types because:

SELECT geo 
       = geography::STGeomFromText('LINESTRING(1 5, 2 9)', 4326);
GO
SELECT GEO
       = GEOGRAPHY::STGeomFromText('LINESTRING(1 5, 2 9)', 4326);
GO

USE [tempdb];
GO

ALTER DATABASE fail SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DROP DATABASE fail;








-- demo 5: 

/* 
  Match exact case for entities and columns
  Match white space in query text
  Important even in a case-insensitive database
*/

CREATE TABLE dbo.SalesOrders
(
  SalesOrderID INT
);
GO

DBCC FREEPROCCACHE WITH NO_INFOMSGS;
GO
SELECT TOP (1) SalesOrderID FROM dbo.SalesOrders;
GO
SELECT TOP (1) salesorderid FROM dbo.salesorders;
GO
select top (1) SalesOrderID from dbo.SalesOrders;
GO
select top (1)  SalesOrderID from dbo.SalesOrders;
GO ---- tab --^^

SELECT t.[text], p.size_in_bytes, p.usecounts
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
WHERE LOWER(t.[text]) LIKE N'%sales'+'orders%';
GO

DROP TABLE dbo.SalesOrders;
GO










-- demo 6 :

/* semi-colons */

GO

-- with each new version, more and more syntax requires it
CREATE PROCEDURE dbo.problema
  @i int
AS
BEGIN
  BEGIN TRY
    BEGIN TRANSACTION
    SELECT 1/@i
    COMMIT TRANSACTION
  END TRY
  BEGIN CATCH
    ROLLBACK TRANSACTION; 
    THROW
  END CATCH
END
GO

EXEC dbo.problema @i = 1;
GO
EXEC dbo.problema @i = 0;
GO

-- missing semi-colon before THROW: 
-- SQL Server tries to roll back a tx named "throw"

DROP PROCEDURE dbo.problema;
GO

-- other new syntax - service broker commands, MERGE:

CREATE TABLE #x(i int);
GO

MERGE #x AS x USING (VALUES (1),(2),(3)) AS y(i) 
ON x.i = y.i
WHEN MATCHED THEN
   UPDATE SET i = y.i
WHEN NOT MATCHED THEN
   INSERT (i) VALUES (y.i)

GO
DROP TABLE #x;

-- the "it isn't required yet" excuse doesn't cut it
-- all you're doing is justifying more technical debt
-- let me turn it around - what do you gain by 
-- NOT using semi-colons?










-- demo 7 :

/* schema prefix */

USE tempdb;
GO
CREATE SCHEMA Paul;
GO
CREATE SCHEMA Kim;
GO
CREATE USER Paul WITHOUT LOGIN 
  WITH DEFAULT_SCHEMA = Paul;

CREATE USER Kim WITHOUT LOGIN 
  WITH DEFAULT_SCHEMA = Kim;
GO

CREATE TABLE dbo.SimpleTable(ID int);
GO
GRANT SELECT ON dbo.SimpleTable TO Paul, Kim;
GO

/*
-- run this batch once, then add dbo. prefix
*/
DBCC FREEPROCCACHE WITH NO_INFOMSGS;

EXECUTE AS USER = N'Paul';
GO
SELECT ID FROM SimpleTable;
GO
REVERT;
GO

EXECUTE AS USER = N'Kim';
GO
SELECT ID FROM SimpleTable;
GO
REVERT;
GO


-- now check the plan cache; how many plans? Why?

SELECT t.[text], p.size_in_bytes, p.usecounts
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
WHERE t.[text] LIKE N'%SELECT%identitet%'+N'%DumtBord%';

-- now clean up and run it again

-- why? dig a little deeper

SELECT t.[text], p.size_in_bytes, 
  p.usecounts, [schema_id] = pa.value, [schema] = s.name
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
CROSS APPLY sys.dm_exec_plan_attributes(p.plan_handle) AS pa
LEFT OUTER JOIN sys.schemas AS s
  ON s.[schema_id] = CONVERT(INT, pa.[value])
WHERE t.[text] LIKE N'%SELECT%identitet%'+N'%DumtBord%'
AND pa.attribute = N'user_id';

-- attribute "user_id" actually represents default_schema_id

GO
DROP TABLE dbo.SimpleTable;
DROP USER Paul;
DROP USER Kim;

















-- demo 7.5 - semi-colons

-- copying code like CTEs without semi-colons 
-- leads to angry customers

-- e.g. I would post this answer on Stack Overflow:
WITH x(i) AS (SELECT 1) 
  SELECT i FROM x;

-- they would paste into this procedure:
GO
CREATE PROCEDURE dbo.StackQuestion
AS
BEGIN
  DECLARE @i int

  WITH x(i) AS (SELECT 1) 
  SELECT i FROM x;

END
GO

-- and then I would get blamed!


-- semi-colon to *begin* a statement is legal. So is this:

;; ;;SELECT 1;;;SELECT 2;;; ;;;SELECT 3;; ;

-- very rare that you can have too many semi-colons;
-- quite common that a missing one causes problems.
