USE tempdb;
SET NOCOUNT ON;
GO

/* Date/time shorthand QUIZ */

-- demo 1 :
DECLARE @d date = GETDATE();

SELECT             'DATEPART( Y )', DATEPART( Y , @d ) 
   				  
                    --   (a)  305   (b)  17   (c)  2017
				  
UNION ALL SELECT   'DATEPART( M )', DATEPART( M , @d )    
				  
                    --   (a)  11    (b)  This minute

UNION ALL SELECT   'DATEPART( W )', DATEPART( W , @d )   
				  
                    --   (a)  4     (b)  43   (c)  44;




-- demo 2 :

-- this works ok:
DECLARE @dt datetime = SYSDATETIME();
SELECT @dt + 1;
GO

-- this breaks:
DECLARE @d datetime2 = SYSDATETIME();
SELECT @d + 1;
GO

-- so does this:
DECLARE @d date = SYSDATETIME();
SELECT @d + 1;
GO

-- always use explicit DATEADD













/* Regional formats */

SET LANGUAGE FRENCH;
-- SET LANGUAGE US_ENGLISH;

SELECT CONVERT(datetime, '2017-11-01')
UNION ALL
SELECT CONVERT(datetime, '11/01/2017')
UNION ALL
SELECT CONVERT(datetime, '2017-11-01 12:34:56.789');

-- safe:

SELECT CONVERT(datetime, '20171101')
UNION ALL
SELECT CONVERT(datetime, '2017-11-01T12:34:56.789')
UNION ALL
SELECT CONVERT(datetime, '20171101 12:34:56.789');







/* BETWEEN / "end" of period */

DROP TABLE IF EXISTS dbo.SalesOrders
CREATE TABLE dbo.SalesOrders
(
  OrderDate datetime2
);
GO

INSERT dbo.SalesOrders(OrderDate) VALUES
  ('20170201 00:00'),
  ('20170201 01:00'),
  ('20170219 00:00'),
  ('20170228 04:00'),
  ('20170228 13:27:32.534'),
  ('20170228 23:59:59.9999999'),
  ('20170301 00:00');
GO

SELECT OrderDate 
  FROM dbo.SalesOrders
  ORDER BY OrderDate;
GO

-- parameters are datetime, using old millisecond tricks:
DECLARE 
  @start datetime = '20170201',
  @end   datetime = DATEADD(MILLISECOND, -3, '20170301');

SELECT OrderDate, @start, @end 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND @end;
GO

-- parameters change to smalldatetime:
DECLARE 
 @start smalldatetime = '20170201',
 @end   smalldatetime = DATEADD(MILLISECOND, -3, '20170301');

SELECT OrderDate, @start, @end 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND @end;
GO

-- parameters change to date:
DECLARE 
  @start date = '20170201',
  @end   date = DATEADD(MILLISECOND, -3, '20170301');

SELECT OrderDate, @start, @end 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND @end;
GO

-- how about EOMONTH()?
DECLARE 
  @start date = '20170201';

SELECT OrderDate, @start, EOMONTH(@start) 
  FROM dbo.SalesOrders
  WHERE OrderDate BETWEEN @start AND EOMONTH(@start);
GO

-- Stop using BETWEEN. Open-ended range is safer,
-- and far easier to calculate the "end" of a period
DECLARE 
  @start date = '20170201';

SELECT OrderDate, @start, DATEADD(MONTH, 1, @start)
  FROM dbo.SalesOrders
  WHERE OrderDate >= @start 
    AND OrderDate < DATEADD(MONTH, 1, @start);
GO

DROP TABLE dbo.SalesOrders;
GO