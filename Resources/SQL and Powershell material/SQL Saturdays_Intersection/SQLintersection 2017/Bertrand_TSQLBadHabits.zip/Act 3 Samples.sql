USE tempdb;
SET NOCOUNT ON;
GO

/* ORDER BY myths */

CREATE TABLE dbo.Personnel
(
  ID          int PRIMARY KEY, 
  FirstName   varchar(32)
);
GO

-- purposely out of alphabetical order
INSERT dbo.Personnel(ID, FirstName) 
  VALUES(1,'mike'),(2,'grant'),(3,'aaron');

-- ordered by primary key, since cheapest 
-- method is CI scan
SELECT ID,FirstName FROM dbo.Personnel;

-- now, someone else creates an index
CREATE INDEX IX_MFirstName ON dbo.Personnel(FirstName);

-- cheapest method changed; now index scan is used, 
-- ordered alpha:
SELECT ID,FirstName FROM dbo.Personnel;

-- TOP 100 PERCENT doesn't help:
SELECT ID,FirstName FROM 
(
  SELECT TOP (100) PERCENT ID,FirstName 
  FROM dbo.Personnel ORDER BY ID
) AS m;

-- neither does adding implicit sorting in a CTE:
;WITH cte AS 
(
  SELECT ID,FirstName, 
    rn = ROW_NUMBER() OVER (ORDER BY ID) 
  FROM dbo.Personnel
)
SELECT ID,FirstName FROM cte;

-- unless the window function is materialized (but this still isn't guaranteed):
;WITH cte AS 
(
  SELECT ID,FirstName,
    rn = ROW_NUMBER() OVER (ORDER BY ID) 
  FROM dbo.Personnel
)
SELECT ID,FirstName,rn FROM cte;
-------------------------^^

-- also, don't use this lazy shorthand
----------------------------------------------------v
SELECT ID,FirstName FROM dbo.Personnel ORDER BY 1;

DROP TABLE dbo.Personnel;
GO







/* evaluation order */

CREATE TABLE dbo.Scores
(
  ID int, 
  Score     varchar(12)
);

CREATE TABLE dbo.Related
(
  ID int
);

INSERT dbo.Scores(ID, Score) 
  VALUES(1,'100'),(2,'Aaron'),(5,'45');

INSERT dbo.Related(ID) 
  VALUES(1), (5), (16), (489);
GO

SELECT s.ID, s.Score * 5
  FROM dbo.Scores AS s
  INNER JOIN dbo.Related AS r
  ON s.ID = r.ID;
GO

;WITH OnlyNumbers AS
(
  SELECT ID, Score
  FROM dbo.Scores
  WHERE ISNUMERIC(Score) = 1
  --WHERE Score NOT LIKE '%[^0-9]%' 
)
SELECT ID, Score
  FROM OnlyNumbers
  WHERE Score > 10;
GO

-- how to solve?

SELECT s.ID, 
    [case] = 5 * CASE WHEN ISNUMERIC(s.Score) = 1 
      THEN s.Score 
      ELSE NULL 
      END,
    [try_convert] = 5 * TRY_CONVERT(int, s.Score) 
  FROM dbo.Scores AS s
  INNER JOIN dbo.Related AS r
  ON s.ID = r.ID;
GO

DROP TABLE dbo.Scores, dbo.Related;