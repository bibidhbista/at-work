/*Monitoring performance by using the Query Store
https://docs.microsoft.com/en-us/sql/relational-databases/performance/monitoring-performance-by-using-the-query-store/*
USE [AdventureWorks2014]
GO

-- 2.0 The following query returns information about queries and plans in the query store.
SELECT Txt.query_text_id, Txt.query_sql_text, Pl.plan_id, Qry.*
FROM sys.query_store_plan AS Pl
JOIN sys.query_store_query AS Qry
    ON Pl.query_id = Qry.query_id
JOIN sys.query_store_query_text AS Txt
    ON Qry.query_text_id = Txt.query_text_id ;
-- 2.1 Last N queries that were executed on the database, last 5 minutes
SELECT TOP 20 qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id, rs.last_execution_time
FROM
	sys.query_store_query_text qt JOIN 
	sys.query_store_query q ON qt.query_text_id = q.query_text_id JOIN
	sys.query_store_plan p ON q.query_id = p.query_id JOIN
	sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time > dateadd(MINUTE, -5, getutcdate())
ORDER BY rs.last_execution_time DESC
GO

-- 2.2 Count of executions for each query within last hour
SELECT q.query_id, qt.query_text_id, qt.query_sql_text, 
SUM(rs.count_executions) AS total_execution_count
FROM
	sys.query_store_query_text qt JOIN 
	sys.query_store_query q ON qt.query_text_id = q.query_text_id JOIN
	sys.query_store_plan p ON q.query_id = p.query_id JOIN
	sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time > dateadd(hour, -1, getutcdate())
GROUP BY q.query_id, qt.query_text_id, qt.query_sql_text
ORDER BY total_execution_count DESC
GO

-- 2.3 N queries with longest average execution time within last hour
SELECT TOP 10 qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id, 
getutcdate() as CurrentUTCTime, rs.last_execution_time, rs.avg_duration
FROM
	sys.query_store_query_text qt JOIN 
	sys.query_store_query q ON qt.query_text_id = q.query_text_id JOIN
	sys.query_store_plan p ON q.query_id = p.query_id JOIN
	sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time > dateadd(hour, -1, getutcdate())
ORDER BY rs.avg_duration DESC
GO

-- 2.4 N queries that had the biggest average physical IO reads in last 24 hours, 
--    with corresponding average row count and execution count
SELECT TOP 10 qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id, 
rs.runtime_stats_id, rsi.start_time, rsi.end_time, rs.avg_physical_io_reads, 
rs.avg_rowcount, rs.count_executions
FROM
	sys.query_store_query_text qt JOIN 
	sys.query_store_query q ON qt.query_text_id = q.query_text_id JOIN
	sys.query_store_plan p ON q.query_id = p.query_id JOIN
	sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id JOIN
	sys.query_store_runtime_stats_interval rsi ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id
WHERE rsi.start_time >= dateadd(hour, -24, getutcdate()) 
ORDER BY rs.avg_physical_io_reads DESC
GO

-- 2.5 Queries that recently regressed in performance
--  The following query example returns all queries which execution time was 
--   doubled in last 2 weeks.
SELECT 
	qt.query_sql_text, 
	q.query_id, 
	qt.query_text_id, 
	p1.plan_id AS plan1_id, 
	rsi1.start_time AS runtime_stats_interval_1, 
	rs1.runtime_stats_id AS runtime_stats_id_1,
	rs1.avg_duration AS avg_duration_plan1, 
	p2.plan_id AS plan2_id, 
	rsi2.start_time AS runtime_stats_interval_2, 
	rs2.runtime_stats_id AS runtime_stats_id_2,
	rs2.avg_duration AS avg_duration_plan2
FROM
	sys.query_store_query_text qt JOIN 
	sys.query_store_query q ON qt.query_text_id = q.query_text_id JOIN
	sys.query_store_plan p1 ON q.query_id = p1.query_id JOIN
	sys.query_store_runtime_stats rs1 ON p1.plan_id = rs1.plan_id JOIN
	sys.query_store_runtime_stats_interval rsi1 ON rsi1.runtime_stats_interval_id = rs1.runtime_stats_interval_id JOIN
	sys.query_store_plan p2 ON q.query_id = p2.query_id JOIN
	sys.query_store_runtime_stats rs2 ON p2.plan_id = rs2.plan_id JOIN
	sys.query_store_runtime_stats_interval rsi2 ON rsi2.runtime_stats_interval_id = rs2.runtime_stats_interval_id
WHERE
	rsi1.start_time > dateadd(day, -14, getutcdate()) AND
	rsi2.start_time > rsi1.start_time AND
	rs2.avg_duration > 2*rs1.avg_duration


-- 2.6 Queries with multiple plans. These queries are especially interesting 
--because they are candidates for regressions due to plan choice change. 
--The following query identifies these queries along with all plans:
WITH Query_MultPlans
AS
(
SELECT COUNT(*) AS cnt, q.query_id 
FROM sys.query_store_query_text AS qt
JOIN sys.query_store_query AS q
    ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan AS p
    ON p.query_id = q.query_id
GROUP BY q.query_id
HAVING COUNT(distinct plan_id) > 1
)
SELECT q.query_id, object_name(object_id) AS ContainingObject, query_sql_text,
plan_id, p.query_plan AS plan_xml,
p.last_compile_start_time, p.last_execution_time
FROM Query_MultPlans AS qm
JOIN sys.query_store_query AS q
    ON qm.query_id = q.query_id
JOIN sys.query_store_plan AS p
    ON q.query_id = p.query_id
JOIN sys.query_store_query_text qt 
    ON qt.query_text_id = q.query_text_id
ORDER BY query_id, plan_id;

-- 2.7 Queries that recently regressed in performance (comparing different point in time). 
--The following query example returns all queries for which execution time doubled in 
--last 48 hours due to a plan choice change. Query compares all runtime stat intervals side by side.
SELECT 
    qt.query_sql_text, 
    q.query_id, 
    qt.query_text_id, 
    rs1.runtime_stats_id AS runtime_stats_id_1,
    rsi1.start_time AS interval_1, 
    p1.plan_id AS plan_1, 
    rs1.avg_duration AS avg_duration_1, 
    rs2.avg_duration AS avg_duration_2,
    p2.plan_id AS plan_2, 
    rsi2.start_time AS interval_2, 
    rs2.runtime_stats_id AS runtime_stats_id_2
FROM sys.query_store_query_text AS qt 
JOIN sys.query_store_query AS q 
    ON qt.query_text_id = q.query_text_id 
JOIN sys.query_store_plan AS p1 
    ON q.query_id = p1.query_id 
JOIN sys.query_store_runtime_stats AS rs1 
    ON p1.plan_id = rs1.plan_id 
JOIN sys.query_store_runtime_stats_interval AS rsi1 
    ON rsi1.runtime_stats_interval_id = rs1.runtime_stats_interval_id 
JOIN sys.query_store_plan AS p2 
    ON q.query_id = p2.query_id 
JOIN sys.query_store_runtime_stats AS rs2 
    ON p2.plan_id = rs2.plan_id 
JOIN sys.query_store_runtime_stats_interval AS rsi2 
    ON rsi2.runtime_stats_interval_id = rs2.runtime_stats_interval_id
WHERE rsi1.start_time > DATEADD(hour, -48, GETUTCDATE()) 
    AND rsi2.start_time > rsi1.start_time 
--If you want to see performance all regressions (not only those related to 
--plan choice change) than just remove condition AND p1.plan_id <> p2.plan_id    
	AND p1.plan_id <> p2.plan_id
    AND rs2.avg_duration > 2*rs1.avg_duration
ORDER BY q.query_id, rsi1.start_time, rsi2.start_time;

--If you want to see performance all regressions (not only those 
--related to plan choice change) than just remove condition AND p1.plan_id <> p2.plan_id from the previous query.
