USE AdventureWorks2016
GO

--USE QUERY STORE TO SEE WHAT WE HAVE BEEN WAITING ON
select wait_category_desc, count(*) as wait_category, 
avg(avg_query_wait_time_ms) avg_wait_time_ms
from sys.query_store_wait_stats
group by wait_category_desc
order by wait_category DESC
go


-- Show me which queries waited on PAGEIOLATCH and how much average wait time
-- was on the latch vs overal duration
select qt.query_sql_text, qrs.avg_duration, qws.avg_query_wait_time_ms
from sys.query_store_query_text qt
join sys.query_store_query qq
on qt.query_text_id = qq.query_text_id
join sys.query_store_plan qsp
on qsp.query_id = qq.query_id
join sys.query_store_runtime_stats qrs
on qrs.plan_id = qsp.plan_id
join sys.query_store_wait_stats qws
on qws.plan_id = qsp.plan_id
WHERE 
qws.wait_category IN (6) AND
qws.execution_type = 0
go


/*execution_type_desc - description of the execution type field:
0 � Regular
3 � Aborted
4 - Exception*/

--Wait Category Table:
/*0	Unknown	Unknown
1	CPU	SOS_SCHEDULER_YIELD
2	Worker Thread	THREADPOOL
3	Lock	LCK_M_%
4	Latch	LATCH_%
5	Buffer Latch	PAGELATCH_%
6	Buffer IO	PAGEIOLATCH_%
7	Compilation*	RESOURCE_SEMAPHORE_QUERY_COMPILE
8	SQL CLR	CLR%, SQLCLR%
9	Mirroring	DBMIRROR%
10	Transaction	XACT%, DTC%, TRAN_MARKLATCH_%, MSQL_XACT_%, TRANSACTION_MUTEX
11	Idle	SLEEP_%, LAZYWRITER_SLEEP, SQLTRACE_BUFFER_FLUSH, SQLTRACE_INCREMENTAL_FLUSH_SLEEP, SQLTRACE_WAIT_ENTRIES, FT_IFTS_SCHEDULER_IDLE_WAIT, XE_DISPATCHER_WAIT, REQUEST_FOR_DEADLOCK_SEARCH, LOGMGR_QUEUE, ONDEMAND_TASK_QUEUE, CHECKPOINT_QUEUE, XE_TIMER_EVENT
12	Preemptive	PREEMPTIVE_%
13	Service Broker	BROKER_% (but not BROKER_RECEIVE_WAITFOR)
14	Tran Log IO	LOGMGR, LOGBUFFER, LOGMGR_RESERVE_APPEND, LOGMGR_FLUSH, LOGMGR_PMM_LOG, CHKPT, WRITELOGF
15	Network IO	ASYNC_NETWORK_IO, NET_WAITFOR_PACKET, PROXY_NETWORK_IO, EXTERNAL_SCRIPT_NETWORK_IOF
16	Parallelism	CXPACKET, EXCHANGE
17	Memory	RESOURCE_SEMAPHORE, CMEMTHREAD, CMEMPARTITIONED, EE_PMOLOCK, MEMORY_ALLOCATION_EXT, RESERVED_MEMORY_ALLOCATION_EXT, MEMORY_GRANT_UPDATE
18	User Wait	WAITFOR, WAIT_FOR_RESULTS, BROKER_RECEIVE_WAITFOR
19	Tracing	TRACEWRITE, SQLTRACE_LOCK, SQLTRACE_FILE_BUFFER, SQLTRACE_FILE_WRITE_IO_COMPLETION, SQLTRACE_FILE_READ_IO_COMPLETION, SQLTRACE_PENDING_BUFFER_WRITERS, SQLTRACE_SHUTDOWN, QUERY_TRACEOUT, TRACE_EVTNOTIFF
20	Full Text Search	FT_RESTART_CRAWL, FULLTEXT GATHERER, MSSEARCH, FT_METADATA_MUTEX, FT_IFTSHC_MUTEX, FT_IFTSISM_MUTEX, FT_IFTS_RWLOCK, FT_COMPROWSET_RWLOCK, FT_MASTER_MERGE, FT_PROPERTYLIST_CACHE, FT_MASTER_MERGE_COORDINATOR, PWAIT_RESOURCE_SEMAPHORE_FT_PARALLEL_QUERY_SYNC
21	Other Disk IO	ASYNC_IO_COMPLETION, IO_COMPLETION, BACKUPIO, WRITE_COMPLETION, IO_QUEUE_LIMIT, IO_RETRY
22	Replication	SE_REPL_%, REPL_%, HADR_% (but not HADR_THROTTLE_LOG_RATE_GOVERNOR), PWAIT_HADR_%, REPLICA_WRITES, FCB_REPLICA_WRITE, FCB_REPLICA_READ, PWAIT_HADRSIM
23	Log Rate Governor	LOG_RATE_GOVERNOR, POOL_LOG_RATE_GOVERNOR, HADR_THROTTLE_LOG_RATE_GOVERNOR, INSTANCE_LOG_RATE_GOVERNOR
*/

--Reference:
--https://docs.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-query-store-wait-stats-transact-sql
