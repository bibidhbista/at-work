--1.0 The following query returns information about queries and plans in the query store. 

USE [AdventureWorks2014]
GO

SELECT Txt.query_text_id, Txt.query_sql_text, Pl.plan_id, Qry.*  
FROM sys.query_store_plan AS Pl  
JOIN sys.query_store_query AS Qry  
    ON Pl.query_id = Qry.query_id  
JOIN sys.query_store_query_text AS Txt  
    ON Qry.query_text_id = Txt.query_text_id ;  

--Examine all of the Query Store configuration options: 
--Reference: (https://docs.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-database-query-store-options-transact-sql)
SELECT * FROM sys.database_query_store_options

SELECT actual_state, actual_state_desc, readonly_reason,   
    current_storage_size_mb, max_storage_size_mb  
FROM sys.database_query_store_options;

--1.1 Determine if Query Store is currently active, and whether it is currently collects runtime stats or not.
SELECT actual_state, actual_state_desc, readonly_reason,   
    current_storage_size_mb, max_storage_size_mb  
FROM sys.database_query_store_options;  

--1.2 Get Query Store options, To find out detailed information about Query Store status, execute following in a user database.
SELECT * FROM sys.database_query_store_options;  

SELECT actual_state, actual_state_desc, readonly_reason, 
current_storage_size_mb, max_storage_size_mb
FROM sys.database_query_store_options;