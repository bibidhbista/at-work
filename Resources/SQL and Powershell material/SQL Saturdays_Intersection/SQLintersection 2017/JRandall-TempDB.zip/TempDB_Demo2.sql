-- basic tempdb facts
SELECT 
    cast(name as char(10)) AS FileName, 
    CAST(CAST(size*1.0/128 as decimal(10,2)) AS char(10)) AS FileSizeinMB,
    CASE max_size 
        WHEN 0 THEN 'Autogrowth is off.'
        WHEN -1 THEN 'Autogrowth is on.'
        ELSE 'Log file will grow to a maximum size of 2 TB.'
    END AS Autogrow,
    growth AS 'GrowthValue',
    'GrowthIncrement' = 
        CASE
            WHEN growth = 0 THEN 'Size is fixed and will not grow.'
            WHEN growth > 0 AND is_percent_growth = 0 
                THEN 'Growth value is in 8-KB pages.'
            ELSE 'Growth value is a percentage.'
        END
FROM tempdb.sys.database_files;


-- =======================================
-- create temp tables
-- =======================================
CREATE TABLE #TemporaryTable -- Local temporary table
	(
    Col1 int,
    Col2 varchar(500)
	);

insert #TemporaryTable
SELECT top(10000) a.id, a.name 
from sysobjects A
 CROSS JOIN sysobjects B CROSS JOIN sysobjects C

CREATE TABLE ##GlobalTemporaryTable -- Gloabl temporary table - note it starts with ##.
	(
    Col1 int,
    Col2 varchar(500)
	);

insert ##GlobalTemporaryTable
SELECT top(10000) a.id, a.name 
from sysobjects A
 CROSS JOIN sysobjects B CROSS JOIN sysobjects C

 -- what tables are in tempdb
 SELECT name, create_date FROM TempDB.sys.tables WHERE name LIKE '#%'

 -- find table name, rowcount, page count, and size
 USE TempTests;

SELECT 
	tb.name AS [Temporary table name],
	stt.row_count AS [Number of rows], 
	stt.used_page_count * 8 AS [Used space (KB)], 
	stt.reserved_page_count * 8 AS [Reserved space (KB)] FROM tempdb.sys.partitions AS prt 
INNER JOIN tempdb.sys.dm_db_partition_stats AS stt 
   ON prt.partition_id = stt.partition_id 
   AND prt.partition_number = stt.partition_number 
INNER JOIN tempdb.sys.tables AS tb 
   ON stt.object_id = tb.object_id 
ORDER BY tb.name


-- =============================
-- contention
-- ============================
--1. start by creating a procedure in tempdb that will generate a load

use tempdb;
GO
CREATE PROCEDURE dbo.contention
AS
SET NOCOUNT ON;
SELECT TOP(5000) a.name, replicate(a.status,4000) as col2
into #t1
FROM master..spt_values a
CROSS JOIN master..spt_values b OPTION (MAXDOP 1);
GO

--2. run ostress via command line to run proc
-- c:\Program Files\RMLUtils>ostress.exe -E -d"tempdb" -Q"exec dbo.contention" -n10 -r300 -b -q

--3. Check for contention
--3a Use this script
SELECT  session_id
       ,wait_type
       ,wait_duration_ms
       ,blocking_session_id
       ,resource_description
       ,ResourceType = 
		CASE WHEN CAST(RIGHT(resource_description,
                       LEN(resource_description) - CHARINDEX(':', resource_description, 3)) AS int)
                       - 1 % 8088 = 0 THEN 'Is PFS Page'
             WHEN CAST(RIGHT(resource_description,
                       LEN(resource_description) - CHARINDEX(':', resource_description, 3)) AS int)
                       - 2 % 511232 = 0 THEN 'Is GAM Page'
             WHEN CAST(RIGHT(resource_description,
                       LEN(resource_description) - CHARINDEX(':', resource_description, 3)) AS int)
                       - 3 % 511232 = 0 THEN 'Is SGAM Page'
             ELSE 'Is Not PFS, GAM, or SGAM page'
         END
FROM    sys.dm_os_waiting_tasks
WHERE   wait_type LIKE 'PAGE%LATCH_%'
  AND resource_description LIKE '2:%';

  --3b. Run sp_WhoIsActive
EXEC sp_WhoIsActive
    @filter = ''
   ,@filter_type = 'session'
   ,@output_column_list = '[dd%][session_id][sql_text][sql_command][wait_info][tasks][tran_log%][cpu%][temp%][block%][reads%][writes%][context%][physical%][query_plan][locks][%]'
   ,@sort_order = '[start_time] ASC'
   ,@format_output = 1
   ,@destination_table = ''
   ,@return_schema = 0
   ,@schema = NULL
   ,@help = 0;