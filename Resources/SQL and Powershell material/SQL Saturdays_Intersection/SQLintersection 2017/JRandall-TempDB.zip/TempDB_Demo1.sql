-- =======================================
-- 1. Query Plan Spill Operations
-- =======================================

SET NOCOUNT ON
USE TempTests;
GO
�
--query that forces a sort operation
DECLARE @v1 Char(500), @v2 Int
SELECT @v1 = ColChar, @v2 = OrderID
FROM dbo.Spill
ORDER BY CONVERT(VarChar(5000), ColChar) + '' --the convert function results in a larger memory grant
OPTION (MAXDOP 1, RECOMPILE);
GO

--Create the spill
DECLARE @v1 Char(500), @v2 Int
SELECT @v1 = ColChar, @v2 = OrderID
FROM dbo.Spill
ORDER BY ColChar
OPTION (MAXDOP 1, RECOMPILE);

-- make the sort go away
CREATE NONCLUSTERED INDEX ix2 ON dbo.Spill (ColChar);
GO
DECLARE @v1 Char(500), @v2 Int
SELECT @v1 = ColChar, @v2 = OrderID
FROM dbo.Spill
ORDER BY ColChar
OPTION (MAXDOP 1, RECOMPILE);

-- =======================================
--2. Cursors
-- =======================================
USE TempTests
GO

--we will use a table named cursors for this example. let�s check the table size:

SELECT SUM(stat.used_page_count) * 8 / 1024 MBs
FROM sys.dm_db_partition_stats stat
WHERE stat.[object_id] = object_id('dbo.cursors')

--This query will check tempdb size, declare a static cursor, 
--then check tempdb size again to see what we caused:

SET NOCOUNT ON
USE tempdb
�
GO
�
SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2
�
DECLARE c CURSOR STATIC FOR SELECT [data] FROM TempTests.dbo.cursors
OPEN c
�
SELECT internal_objects_alloc_page_count * 8 / 1024 [After MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2
�
CLOSE c
DEALLOCATE c
�
SELECT internal_objects_dealloc_page_count * 8 / 1024 [Deallocate MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2

-- =======================================
--3. Triggers
-- =======================================
use TempTests
go

-- create a trigger that will access the DELETED table in tempdb, 
-- and check tempdb internal objects allocation inside the trigger.
create trigger tUpdateTest on dbo.triggers for update as
�    declare @var nvarchar(max)
�    declare @pages int
�
    SELECT @pages = internal_objects_alloc_page_count * 8 / 1024
    FROM sys.dm_db_task_space_usage 
    WHERE session_id = @@SPID and database_id = 2
�
    print '[During MBs] ' + cast(@pages as varchar)
�
    select @var = deleted.[data] from deleted

--For our test, check tempdb allocation,
--then run an update against every row in the triggers table 
--Our results will have the starting tempdb allocation size, and the print statement from the trigger. 

--check tempdb allocation
SET NOCOUNT ON;

SELECT internal_objects_alloc_page_count * 8 / 1024 [Before MBs] 
FROM sys.dm_db_task_space_usage 
WHERE session_id = @@SPID and database_id = 2;

--update every row in the table. This will cause the trigger to fire
update TempTests.dbo.triggers set [data] = [data] + 'x'

--check results�

--drop trigger
DROP TRIGGER [dbo].[tUpdateTest]
GO

-- =======================================
--4. LOB Variables
-- =======================================
-- If you have a variable holding a big XML document or maybe a parameter holding a large nvarchar(max), 
-- they can get stored as internal objects in tempdb. Let�s see what impact this might have.
-- We'll use a variable and a loop. Each loop we will add another 100000 characters to the string, 
-- and check out tempdb usage for this task, along with the length of the variable. 
-- This will let us see at what point the variable goes to tempdb.

DECLARE @bigVar nvarchar(max) = '';
�
WHILE(LEN(@bigVar) < 1000000)
BEGIN
    SELECT @bigVar = @bigVar + REPLICATE(CONVERT(nvarchar(max), 'x'), 100000);
�
    SELECT LEN(@bigVar) [Variable Length], internal_objects_alloc_page_count * 8 / 1024 [TempDB MBs] 
    FROM sys.dm_db_task_space_usage 
    WHERE session_id = @@SPID and database_id = 2
END

